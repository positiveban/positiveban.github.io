function [ep,t_elapsed]= l_inf_func(e,xc,Gm,constraint_d,u_lb,u_ub,Cc,Dc,V,Qe,Qu,l2linf)

    xc=xc';

    C_u = [1 -1 0 0 0 0 0 0 0 
        0 1 -1 0 0 0 0 0 0 
        0 0 1 -1 0 0 0 0 0 
        0 0 0 1 -1 0 0 0 0 
        0 0 0 0 1 -1 0 0 0 
        0 0 0 0 0 1 -1 0 0];

    C_u = [C_u; -1*C_u];

    d = constraint_d;
    C_ieq = C_u*Dc;
    d = d - C_u*Cc*xc;
    % upper lower bound

    lb = (Dc)\(u_lb-Cc*xc);
    ub = (Dc)\(u_ub-Cc*xc);
    
    if l2linf ==1
        a=tic;
        
        Qe=diag(Qe);
        Qu=diag(Qu);
        
        Q1 = Gm'*Gm + V*Qe*V' + Dc'*V*Qu*V'*Dc;
        Q2 = xc'*Cc'*V*Qu*V'*Dc - e'*Gm;
        Q1=(Q1+Q1')/2;
        Q1= (Q1+Q1')/2;
        
        ep = quadprog(Q1,Q2',C_ieq,d,[],[],lb,ub);
        t_elapsed=toc(a);
        %     ep = quadprog(Q1,Q2',[],[],[],[],[],[]);
    elseif l2linf==2
        % l inf norm minimization
        a=tic;
        C_ieq_linf = [C_ieq, zeros(size(C_ieq,1),38);
                      Gm, -1*ones(38,38)
                     -Gm, -1*ones(38,38)];
        d_linf = [d; e; -e];
        lb_linf = [lb; -1e10*ones(38,1) ];
        ub_linf = [ub; 1e10*ones(38,1) ];
        f = [zeros(9,1); ones(38,1)];
        
        optimal_cost = linprog(f,C_ieq_linf,d_linf,[],[],lb_linf,ub_linf);
        t_elapsed=toc(a);
        ep = optimal_cost(1:9);
    else % peka to peak minimization
        a=tic;
        alpha = 1;%abs(1/max(e));
        beta = 1;%abs(1/min(e));
        f = [zeros(9,1); alpha*ones(38,1);beta*ones(38,1)];
        C_ieq_linf = [C_ieq, zeros(size(C_ieq,1),38), zeros(size(C_ieq,1),38);
                      Gm, -1*ones(38,38), zeros(38,38);
                      -Gm, zeros(38,38), -1*ones(38,38)];
        d_linf = [d; e; -e];
        lb_linf = [lb; -1e10*ones(38,1); -1e10*ones(38,1) ];
        ub_linf = [ub; 1e10*ones(38,1) ;1e10*ones(38,1) ];
        
        optimal_cost2 = linprog(f,C_ieq_linf,d_linf,[],[],lb_linf,ub_linf);
        t_elapsed=toc(a);
        ep = optimal_cost2(1:9);
    end
end