%%
figure(1)
subplot(211)
bar(Ly_infty(1:265))
ylabel('Infinity norm of yf (I-Unit)')
ylim([0 50])
subplot(212)
bar(Ly_mse(1:265))
ylim([0 100])
ylabel('MSE of yf (I-Unit)')
xlabel('# of coil data')
% subplot(313)
% bar(violate_flag(1:result_indices-1))
mean(Ly_infty(1:result_indices-1))
mean(Ly_mse(1:result_indices-1))

%%
index=5;

data(index).coilname
d=data(index).d;
u0=data(index).u0;
y=data(index).y;
u=data(index).u;
flags=data(index).flags;

% plot results
t=0:Ts:Tf;
figure(2)
subplot(411)
plot(t,u),xlabel('Time (s)'),ylabel('mm')
ylim([0 160])
subplot(412)
bar(u0),xlabel('Actuators'),ylabel('mm')
% ylim([0 160])
ylabel('u0')
subplot(413)
bar(u(end,:)),xlabel('Actuators'),ylabel('mm')
ylabel('uf')
% ylim([0 160])
subplot(414)
bar(u(end,:)-u(1,:)),xlabel('Time (s)'),ylabel('mm')
ylabel('uf-u0')
% ylim([-20 20])


figure(3)
subplot(211)
plot(t,y(:,7:32)),xlabel('Time (s)'),ylabel('I-Unit')
ylim([-100 100])
subplot(212)
plot(7:32,y(1,7:32)),hold on
plot(7:32,y(end,7:32)),hold off
ylim([-100 100])
xlabel('Zone'),ylabel('I-Unit')
legend('y(0)','y(Tf)','Location','Best')

figure(4) % a flag: upper/lower bound ���� �� on, d flag: ������ �� ASU ���� �Ÿ��� u_diff �̻��� ��� on
stairs(t,flags(:,1)),hold on,stairs(t,flags(:,2)),hold off,legend('a flag','d flag'),ylim([-0.2 1.2])