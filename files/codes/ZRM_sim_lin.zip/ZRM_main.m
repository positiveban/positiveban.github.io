%-------------------------------------------%
%   Sendzimir mill m-file simulator         %
%                    POSCO x POSETCH        %
%                       2017~2018           %
%-------------------------------------------%

clearvars
% close all
clc

% load('GM1257')
load('GM1055')

Gm=PolyGm(:,1:9);
[U,S,V]=svd(Gm);

%% Dynamic model in the paper of 1982
tau0=0.74;
tau=0.582;
tau1=1.064;

s=tf('s');
Ta=1/(1+.2*s)^2;                             % actuator transfer function
Ts=(1-s*tau/2)/(1+s*tau/2)/(1+s*tau1);       % strip dynamics transfer function
Tm=1/(1+s*tau0)/(1+0.01*s);                  % shapemeter dynamics transfer function
W=Ta.*Ts.*Tm;                                % Dynamic model

sys=ss(W);                                   % Plant dynamics for simulink
sys_=ss(Gm*W);
%% Controller dynamics for SVD and ESVD
SV=6;                                        % Singular value used for SVD control
C0=(.4*s+.28)/(s+.001);
csys=ss(C0);                                 % Controller dynamics for Simulink

%% Load Coil data
load('CoilNo=EAX0091  Pass=6--0','ShapeProfile','MillSpeed','UpIMRSHFT_Ref','LoIMRSHFT_Ref','ASU_R_Ref')

if norm(ShapeProfile(end/2,1:5))<1E-3
    width=1055;
    flag_sim=1;
else
    width=1257;
    flag_sim=0;
end

u0=[ASU_R_Ref(2000,:)*0.01,UpIMRSHFT_Ref(2000,:)*0.1,LoIMRSHFT_Ref(2000,:)*0.1]; % for ESVD
d=ShapeProfile(2000,:)*0.01;                 % Initial shapeprofile

% Polynomial representation of initial shape profile
if width==1055
    x=((0:25)/12.5)-1;
    P = polyfit(x,d(7:32),8);
    d=[zeros(1,6),polyval(P,x),zeros(1,6)];
else
    x=((0:33)/16.5)-1;
    P = polyfit(x,d(3:36),8);
    d=[zeros(1,2),polyval(P,x),zeros(1,2)];
end
%% Input constraints
ub = [100 160];                         % upper bounds [ASU, IMR]
lb = [0 0];                             % lower bounds [ASU, IMR]

simpar.con.u_d=25;                      % ������ �� ASU ���� ����
simpar.con.u_min_asu=lb(1);
simpar.con.u_min_imr=lb(2);
simpar.con.u_max_asu=ub(1);
simpar.con.u_max_imr=ub(2);
    
%% Simulation parameters
Ts=.5;                                  % sampling time
Tf=200;                                 % termination time of simulation

% Select static model
simsel.smodel=3;                        % 1: IFM, 2: CEM, 3: Gm

% select controller 
simsel.cmodel=3;                        % 1: svd, 2: esvd, 3: neuro-fuzzy

% NMF-fuzzy parameter
simpar.tune_par=0.0005*ones(1,3);

simpar.Ts=Ts;
simpar.Tf=Tf;
simpar.con.sv=SV;
simpar.con.Qe=[1E-7,1E-7,1E-7,1E-7,20,6.3,5,0.1,0.1];
simpar.con.Qu=[0,0,0,0,1E-6,1E-6,1.5E-4,0.26,0.6];
simpar.width=1055;

% weights for ESVD
par=[1.13806822080615,1.49258118719420,0.0166583642415814,0.00233094439463886,0.000175614013359093,0.000413637839768631,0.000259379787410719,0.000161430858230764,0.000279945097805667,9.49179484782757e-05];
simpar.con.Qe(5:9)=par(1:5);
simpar.con.Qu(5:9)=par(6:10);

%% Run simulation
[y,u,flags]=dsim_zrm(sys,csys,Gm,Gm,d,u0,simsel,simpar); % discrete-time simulation
% sim('ZRM_sim') % continuous time simulation

%% Display results
t=0:Ts:Tf;
figure(2)
subplot(311)
plot(t,u),xlabel('Time (s)'),ylabel('mm')
ylim([0 160])
subplot(312)
bar(u(1,:)),xlabel('Time (s)'),ylabel('mm')
ylim([0 160])
subplot(313)
bar(u(end,:)),xlabel('Time (s)'),ylabel('mm')
ylim([0 160])

figure(3)
subplot(211)
plot(t,y),xlabel('Time (s)'),ylabel('I-Unit')
ylim([-60 60])
subplot(212)
plot(y(1,:)),hold on
plot(y(end,:)),hold off
xlabel('Zone'),ylabel('I-Unit')
legend('y(0)','y(Tf)','Location','Best')

figure(4) % a flag: upper/lower bound ���� �� on, d flag: ������ �� ASU ���� �Ÿ��� u_diff �̻��� ��� on
stairs(t,flags(:,1)),hold on,stairs(t,flags(:,2)),hold off,legend('min/max violation','dASUij violation'),ylim([-0.2 1.2])

figure(5)
subplot(211)
mesh(7:32,t,y(:,7:32))
xlabel('Width (mm)')
ylabel('Time (s)')
zlabel('I-Unit')
subplot(212)
plot(t,y(:,7:32))
xlabel('Time (s)')
ylabel('I-Unit')
ylim([-100 100])