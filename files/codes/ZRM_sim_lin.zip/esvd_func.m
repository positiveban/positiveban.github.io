function ep = esvd_func(e,xc,Gm,constraint_d,u_lb,u_ub,Cc,Dc,V,Qe,Qu)

    xc=xc';

    C_u = [1 -1 0 0 0 0 0 0 0 
        0 1 -1 0 0 0 0 0 0 
        0 0 1 -1 0 0 0 0 0 
        0 0 0 1 -1 0 0 0 0 
        0 0 0 0 1 -1 0 0 0 
        0 0 0 0 0 1 -1 0 0];

    C_u = [C_u; -1*C_u];

    d = constraint_d;
    C_ieq = C_u*Dc;
    d = d - C_u*Cc*xc;
    % upper lower bound

    lb = (Dc)\(u_lb-Cc*xc);
    ub = (Dc)\(u_ub-Cc*xc);

    Qe=diag(Qe);
    Qu=diag(Qu);

    Q1 = Gm'*Gm + V*Qe*V' + Dc'*V*Qu*V'*Dc;
    Q2 = xc'*Cc'*V*Qu*V'*Dc - e'*Gm;
    Q1=(Q1+Q1')/2;
    ep = quadprog(Q1,Q2',C_ieq,d,[],[],lb,ub);
end