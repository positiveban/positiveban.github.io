function output_sum = fuzzy_term(percen,yd,td,matrix_shape,width,tune_par)

%% Initial Setting
input_sum = zeros(1,9);
output_sum = zeros(1,9);
AS_U_input = zeros(14,9);
AS_U = zeros(14,7);
fuzzy_rule = zeros(14,7);
imr_rule = zeros(14,2);
p = zeros(14,1);
IMR_input = zeros(1,2);
init_input = zeros(1,7);
new_imr_rule= zeros(14,2);
total_fuzzy_rule = zeros(14,7);
inpu = zeros(9,1);
N=size(matrix_shape,1);
% tune_par=[0.0010,0.005,0.040]; % �ߵǴ��� 180524
%%
L_inf = max(abs(yd));

%%
for i=1:14
    p(i) = percen(i);
end

%% NMF Fuzzy Rule
for i=1:N
    if width==1055
        fuzzy_rule(i,:)=-[sum(matrix_shape(i,1:8)),sum(matrix_shape(i,4:10)),...
            sum(matrix_shape(i,7:14)),sum(matrix_shape(i,9:19)),sum(matrix_shape(i,15:22)),...
            sum(matrix_shape(i,19:24)),sum(matrix_shape(i,21:26))];
    else
        fuzzy_rule(i,:)=-[sum(matrix_shape(i,1:10)),sum(matrix_shape(i,3:12)),...
            sum(matrix_shape(i,8:19)),sum(matrix_shape(i,11:24)),sum(matrix_shape(i,17:24)),...
            sum(matrix_shape(i,23:30)),sum(matrix_shape(i,26:34))];
    end
end
% fuzzy_rule(1,:)  = -[0.100828653	0.204513714	0.297537418	0.239572473	0.159148941	0.095332099	0.057127999];      
% fuzzy_rule(2,:)  = -[0.153655599	0.203334874	0.071568349	0.046169849	0.110832628	0.256799819	0.178639928];  
% fuzzy_rule(3,:)  = -[0.311984968	0.316068901	0.140567841	0.055640643	0.046652728	0.15517693	0.085013891];
% fuzzy_rule(4,:)  = -[0.167669345	0.198161588	0.210436746	0.144623462	0.203431882	0.060408971	0.024366925];
% fuzzy_rule(5,:)  = -[0.38370021	    0.265613226	0.046677622	0.070309212	0.044943115	0.004574234	0];                       
% fuzzy_rule(6,:)  = -[0.228459254	0.221239197	0.014489198	0.02780176	0.060359974	0.286290281	0.228547392];
% fuzzy_rule(7,:)  = -[0.063187418	0.086541961	0.140308942	0.216500565	0.345893141	0.2058048	0.082556467];             
% fuzzy_rule(8,:)  = -[0.063572501	0.137753856	0.280520063	0.229692334	0.122065524	0.103049616	0.024586429];             
% fuzzy_rule(9,:)  = -[0.158342395	0.019710439	0.214087834	0.214803598	0.116450843	0.000371738	0.000371738];
% fuzzy_rule(10,:) = -[0.148709042	0.140961335	0.052668924	0.043878631	0.059037265	0.223481146	0.241796686];                       
% fuzzy_rule(11,:) = -[0.196050081	0.197419083	0.223197161	0.069882537	0           0.000538005	0.004594394];                     
% fuzzy_rule(12,:) = -[0	            0           0           0           0           0           0.179928777];
% fuzzy_rule(13,:) = -[0.115571662	0.007907618	0           0           0           0           0.138352603];                   
% fuzzy_rule(14,:) = -[0.007377247	0.190582861	0.147034349	0.053505766	0.167309573	0.148990917	0.048557175];                                             

%% NMF Fuzzy Rule
for i=1:N
    if width==1055
        imr_rule(i,:)=[sum(matrix_shape(i,1:4)),sum(matrix_shape(i,23:26))];
    else
        imr_rule(i,:)=[sum(matrix_shape(i,1:4)),sum(matrix_shape(i,31:34))];
    end
end
% imr_rule(1,:)  = [0.153385286	0.073347725];      
% imr_rule(2,:)  = [0.179890976	0.21803987];  
% imr_rule(3,:)  = [0.296317943	0.123426672];
% imr_rule(4,:)  = [0.215925432	0.049111482];
% imr_rule(5,:)  = [0.30553729	0.003430675];                           
% imr_rule(6,:)  = [0.194335875	0.226966459];
% imr_rule(7,:)  = [0.078889941	0.1543536];             
% imr_rule(8,:)  = [0.103315392	0.077287212];             
% imr_rule(9,:)  = [0.122898575	0.000278804];
% imr_rule(10,:) = [0.123345975	0.194341696];                       
% imr_rule(11,:) = [0.209803191	0.003445795];                     
% imr_rule(12,:) = [0	            0.134946583];
% imr_rule(13,:) = [0.086678747	0.103764453];                   
% imr_rule(14,:) = [0.142937146	0.111743187];     

%% Align
%   init_input = int(1:7);   
%   init_input_2 = int(8:9);   
%   inpu = [init_input;init_input_2];
% 
% for i=1:14  
%   total_fuzzy_rule(i,:) = diag(init_input*fuzzy_rule(i,:))';
%   new_imr_rule(i,:)     = diag(init_input_2*imr_rule(i,:))';
% end

%% constraint o
if (td <= 200)
    for i=1:14
        AS_U(i,:)       = p(i) * (fuzzy_rule(i,:));
%         AS_U_input(i,:) = [AS_U(i,:)*(0.0025) imr_rule(i,:).*[0.05 0.05]]; % (�۷ι�)  
%         AS_U_input(i,:) = [AS_U(i,:)*(0.2) imr_rule(i,:).*[-0.011 0.021]]; % (�۷ι�)
        AS_U_input(i,:) = [AS_U(i,:)*(tune_par(1)) imr_rule(i,:).*tune_par(2:3)]; % (�۷ι�)
    end
    % << �� ���� �ڵ� ���Ե��� ���� 180524
elseif (td > 200 && L_inf >= 55)
    for i=1:14
        AS_U(i,:) = p(i) * (fuzzy_rule(i,:));
        AS_U_input(i,:) = [AS_U(i,:)*(0.121) imr_rule(i,:).*[0.082 0.072]];     % coventional
    end    
elseif(td > 200 && L_inf <= 55)
    for i=1:14
        AS_U(i,:)       = p(i) * (fuzzy_rule(i,:));
        AS_U_input(i,:) = [AS_U(i,:)*(0.121) imr_rule(i,:).*[0.082 0.072]];
    end
else
    AS_U_input(i,:) = [AS_U(i,:)*(0.121) imr_rule(i,:).*[0.082 0.072]];
end
% >> ������� 180524
%%
for i=1:14
    output_sum = output_sum + AS_U_input(i,:);
end







