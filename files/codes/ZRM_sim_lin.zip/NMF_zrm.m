% filepath='D:\[1] Projects\2017\POSCO[1605]\[11] Newly Processed Data\Matfiles\';
% files=dir(filepath);
% for i=1:size(file,1)
%     data=load('')
% end
%% Input Data Setting
load('ZRM_DATA_09_02');     % raw data
% if width==1055
MAT = MAT(:,4:29);          % 1055mm use 26 sensors (7 ~ 32)
%     MAT = ShapeProfile(:,7:32);          % 1055mm use 26 sensors (7 ~ 32)
% else
%     MAT = ShapeProfile(:,3:36);          % 1055mm use 26 sensors (4 ~ 29)
% end
Data_Size = size(MAT,1);    % Number of Input Data
Sensor_Num = size(MAT,2);   % Number of meaningful sensors

%% User Parameters

Pattern_Number = 14;        % Expectation of Representative Pattern Numbers

Target_Error = 0.055;        % Target Normalized Error of Pattern Recognition
Max_Iteration_Number = 50;  % Maximum Iteration Number of NMF Algorithm

%% NMF Algorithm Loop

Iteration_Number = 0;       % To count NMF Algorithm Iteration Number
save_RMSE = zeros(Data_Size,1);
count = 0;                                  % to count meaningful iteration
        
while 1
    Iteration_Number = Iteration_Number + 1;
    [H, W] = nnmf(MAT,Pattern_Number);           % W is Representative Shape Pattern Matrix, H is Percentage Matrix

    MAT_BAR = H*W;                              % Reconstructed Plate Shape By NMF Matrixes

    error = 0;
    tot_error = 0;
    
    for i=1:Data_Size
        testSet = MAT(i,:);
        min_value = min(testSet);
        testSet = testSet - min_value;          
        if(max(testSet)~=0)
            count = count + 1;
            testSet = testSet/max(testSet);
            NMF_Result = MAT_BAR(i,:)/max(MAT_BAR(i,:));     % Normalization
            
            error = testSet-NMF_Result;             % Evaluate Pattern Recognition Error
            error_Rms= rms(error);
            save_RMSE(i) = error_Rms;    
            tot_error = tot_error + save_RMSE(i);   % Get Total RMS Error   
        end                                        
    end
    Mean_Error = tot_error/count;
    
    if(Mean_Error<Target_Error)
        break;                      % break since we got appropriate W Matrix
    end
    
    if(Iteration_Number>Max_Iteration_Number)
        break;                      % break since we can't get appropriate W Matrix. Need to reduce Target error, or increase Max_iteration Number
    end    
end

%% Get Representative Shape Fig

Representative_Shape = W;

for i=1:Pattern_Number
    Representative_Shape(i,:) = Representative_Shape(i,:) / max(Representative_Shape(i,:));   % Normalization
end

figure(1);
for i=1:Pattern_Number
    plot(Representative_Shape(i,:))
    hold on
end
axis([0 Sensor_Num 0 1])