
Ts=0.5;

sysd=c2d(ss(sys_),Ts);

A=sysd.a;
B=sysd.b;
C=sysd.c;
D=sysd.d;

save('ZRM_model_180402','A','B','C','D','d','u0','U','S','V')