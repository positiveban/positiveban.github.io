function [y, u, flags, t_elapsed] = dsim_zrm_meas_t(sys,csys,GmPlant,GmCon,d,u0,simsel,simpar,l2linf)

    Ts=simpar.Ts;
    Tf=simpar.Tf;
    SV=simpar.con.sv;
    
    % for cost function
    Qe=simpar.con.Qe;
    Qu=simpar.con.Qu;
    
    ssel=simsel.smodel;
    csel=simsel.cmodel;

    % Plant model discretization
    sysd=c2d(ss(sys*eye(38)),Ts);

    %Controller model discretization
    Cdsvd=c2d(ss(csys)*eye(SV),Ts);
    Cdesvd=c2d(ss(csys)*eye(9),Ts);
    
    % Actuator constraints
    u_d = simpar.con.u_d; 
    u_min = simpar.con.u_min_asu*ones(1,9);
    u_min(8:9) = simpar.con.u_min_imr;
    u_max = simpar.con.u_max_asu*ones(1,9);
    u_max(8:9) = simpar.con.u_max_imr;
        
    % initialization of variables
    [nx,~]=size(sysd.b);
    [ny,~]=size(sysd.c);
    [nu_svd,nx_svd]=size(Cdsvd.c);
    [nu,nx_esvd]=size(Cdesvd.c);
    
    N=Tf/Ts + 1;
    t_elapsed=zeros(1,N);
    
    x=zeros(N,nx);
    y=zeros(N,ny);
    y_=zeros(N,ny);
    flag_a=zeros(N,1);
    flag_d=zeros(N,1);
    xc_svd=zeros(N,nx_svd);
    uc_svd=zeros(N,nu_svd);
    xc_esvd=zeros(N,nx_esvd);
    du=zeros(N,nu);
    u=zeros(N,nu);
    delay=mean(sysd.InputDelay+sysd.OutputDelay);

    % Compute relative constraints
    d1 = u0(2:7) - u0(1:6)+ u_d;
    d2 = u0(1:6) - u0(2:7)+ u_d;
    constraint_d = [d1'; d2'];
    u_lb = u_min - u0;
    u_ub = u_max - u0;
    
    % Singular value decomposition
    [U,S,V]=svd(GmCon);
    
    for k=1:N
        % output shape calculation
        if k<=delay+1
            y(k,:)=d;
        else
            y(k,:)=(sysd.c*x(k-floor(delay),:)'+d')';
        end
        % Contol selection
        if csel == 1
            % SVD control
            yh=-U(:,1:SV)'*y(k,:)';
            xc_svd(k+1,:)=(Cdsvd.a*xc_svd(k,:)' + Cdsvd.b*yh)';
            uc_svd(k,:)=(Cdsvd.c*xc_svd(k,:)' + Cdsvd.d*yh)';
            du(k,:)=((V(:,1:SV)/S(1:SV,1:SV))*uc_svd(k,:)')';

        elseif csel == 2
            % ESVD control
            [yh, t_elapsed(k)]= l_inf_func(-y(k,:)',xc_esvd(k,:), GmCon, constraint_d, u_lb', u_ub', Cdesvd.c, Cdesvd.d,V,Qe,Qu,l2linf);
            
            xc_esvd(k+1,:)=(Cdesvd.a*xc_esvd(k,:)'+Cdesvd.b*yh)';
            du(k,:)=(Cdesvd.c*xc_esvd(k,:)'+Cdesvd.d*yh)';
        elseif csel == 3
            % Neuro-fuzzy control
             
        else
        end
        
        % input saturation
%         u(k,:)=min(u_max - u0,u(k,:));
%         u(k,:)=max(u_min - u0,u(k,:));
        
        [flag_a(k),flag_d(k)]=violate_cons(du(k,:),u0,u_max(7:8),u_min(7:8),u_d);
        
        % Static model selection
        if ssel == 1
            % IFM model
            y_(k,:) = IFM_SHAPEs_POSCO(du(k,:),simpar.ifm,simpar.width*0.001);
        elseif ssel == 2
            % CEM model
            y_(k,:) = CEM_ZRMShape_ver1(du(k,:),simpar.cem,simpar.width);
        elseif ssel == 3
            % Gm (Plant)
            y_(k,:) = GmPlant * du(k,:)';
        end
        u(k,:)=du(k,:)+u0;
        % Discrete time Plant Dynamics
        x(k+1,:)=(sysd.a*x(k,:)'+sysd.b*y_(k,:)')';
    end
    flags=[flag_a,flag_d];
end