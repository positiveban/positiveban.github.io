function total_uid = break_term(output_sum,u0,a_sum,ASU_m,ASU_M,ASU_C)

%% Initial Setting
diff_ASU     = zeros(1,6);
% total_uid    = zeros(1,9);
% uid          = zeros(1,9);
move_u_right = zeros(2,6);                     % (1) = upper and (2) = lower (2-7)
move_u_left  = zeros(2,6);                     % (1) = upper and (2) = lower (1-6)

%% Initial Defining
uid          = output_sum;
total_uid    = a_sum + uid;
total_u      = total_uid + u0';
% total_u      = a_sum + u0';

%% ASU Constraint
% ASU_C = 25;
% ASU_M = 100;
% ASU_m = 0;
Co_e = 0.9;
Co_u = 0.3;

%% ASU Rack
for i=2:7
    diff_ASU(1,i-1) = total_u(1,i) - total_u(1,i-1);
end

%% Constraint
% for i=1:6
%     if (diff_ASU(1,i) >= ASU_C)
%         diff_ASU(1,i) = ASU_C;
%     elseif (diff_ASU(1,i) <= -ASU_C)
%         diff_ASU(1,i) = -ASU_C;
%     else
%         diff_ASU(1,i) = diff_ASU(1,i);
%     end
% end

%% ASU Rack 1
    move_u_right(1,1) = diff_ASU(1,1) +Co_e*ASU_C;
    move_u_right(2,1) = diff_ASU(1,1) -Co_e*ASU_C;
    if (uid(1) >= move_u_right(1,1))
%         uid(1) =  Co_u*move_u_right(1,1);
          uid(1) = Co_u*uid(1);
    elseif (uid(1) <= move_u_right(2,1))
%         uid(1) = Co_u*move_u_right(2,1);
          uid(1) = Co_u*uid(1);
    else
        uid(1) = uid(1);
    end
%% ASU Rack 2
    move_u_left(1,1) =  Co_e*ASU_C -diff_ASU(1,1);
    move_u_left(2,1) = -Co_e*ASU_C -diff_ASU(1,1);
    move_u_right(1,2)  =  diff_ASU(1,2) + Co_e*ASU_C;
    move_u_right(2,2)  =  diff_ASU(1,2) - Co_e*ASU_C;
    if (uid(2) >= min(move_u_left(1,1),move_u_right(1,2)))
%         uid(2) = Co_u*min(move_u_left(1,1),move_u_right(1,2));
          uid(2) = Co_u*uid(2);      
    elseif (uid(2) <= max(move_u_left(2,1),move_u_right(2,2)))
%         uid(2) = Co_u* max(move_u_left(2,1),move_u_right(2,2));
           uid(2) = Co_u*uid(2);
    else
        uid(2) = uid(2);
    end
%% ASU Rack 3
    move_u_left(1,2) =  Co_e*ASU_C -diff_ASU(1,2);
    move_u_left(2,2) = -Co_e*ASU_C -diff_ASU(1,2);
    move_u_right(1,3)  = diff_ASU(1,3) + Co_e*ASU_C;
    move_u_right(2,3)  = diff_ASU(1,3) - Co_e*ASU_C;
    if (uid(3) >= min(move_u_left(1,2),move_u_right(1,3)))
%         uid(3) = Co_u*min(move_u_left(1,2),move_u_right(1,3));
        uid(3) = Co_u*uid(3);
    elseif (uid(3) <= max(move_u_left(2,2),move_u_right(2,3)))
%         uid(3) = Co_u*max(move_u_left(2,2),move_u_right(2,3));
uid(3) = Co_u*uid(3);
    else
        uid(3) = uid(3);
    end
%% ASU Rack 4
    move_u_left(1,3) =  Co_e*ASU_C -diff_ASU(1,3);
    move_u_left(2,3) = -Co_e*ASU_C -diff_ASU(1,3);
    move_u_right(1,4) = diff_ASU(1,4) + Co_e*ASU_C;
    move_u_right(2,4) = diff_ASU(1,4) - Co_e*ASU_C;
    if (uid(4) >= min(move_u_left(1,3),move_u_right(1,4)))
%         uid(4) = Co_u*min(move_u_left(1,3),move_u_right(1,4));
        uid(4) = Co_u*uid(4);
    elseif (uid(4) <= max(move_u_left(2,3),move_u_right(2,4)))
%         uid(4) = Co_u*max(move_u_left(2,3),move_u_right(2,4));
        uid(4) = Co_u*uid(4);
    else
        uid(4) = uid(4);
    end
%% ASU Rack 5
    move_u_left(1,4) =  Co_e*ASU_C -diff_ASU(1,4);
    move_u_left(2,4) = -Co_e*ASU_C -diff_ASU(1,4);
    move_u_right(1,5)  = diff_ASU(1,5) + Co_e*ASU_C;
    move_u_right(2,5)  = diff_ASU(1,5) - Co_e*ASU_C;
    if (uid(5) >= min(move_u_left(1,4),move_u_right(1,5)))
%         uid(5) =Co_u* min(move_u_left(1,4),move_u_right(1,5));
        uid(5) = Co_u*uid(5);
    elseif (uid(5) <= max(move_u_left(2,4),move_u_right(2,5)))
%         uid(5) =Co_u* max(move_u_left(2,4),move_u_right(2,5));
        uid(5) = Co_u*uid(5);
    else
        uid(5) = uid(5);
    end
%% ASU Rack 6
    move_u_left(1,5) =  Co_e*ASU_C -diff_ASU(1,5);
    move_u_left(2,5) = -Co_e*ASU_C -diff_ASU(1,5);
    move_u_right(1,6)  = diff_ASU(1,6) + Co_e*ASU_C;
    move_u_right(2,6)  = diff_ASU(1,6) - Co_e*ASU_C;
    if (uid(6) >= min(move_u_left(1,5),move_u_right(1,6)))
%         uid(6) = Co_u*min(move_u_left(1,5),move_u_right(1,6));
        uid(6) = Co_u*uid(6);
    elseif (uid(6) <= max(move_u_left(2,5),move_u_right(2,6)))
%         uid(6) =Co_u* max(move_u_left(2,5),move_u_right(2,6));
        uid(6) = Co_u*uid(6);
    else
        uid(6) = uid(6);
    end
%% ASU Rack 7
    move_u_left(1,6) =  Co_e*ASU_C -diff_ASU(1,6);
    move_u_left(2,6) = -Co_e*ASU_C -diff_ASU(1,6);
    if (uid(7) >= move_u_left(1,6))
%         uid(7) = Co_u*move_u_left(1,6);
        uid(7) = Co_u*uid(7);
    elseif (uid(7) <= move_u_left(2,6))
%         uid(7) = Co_u*move_u_left(2,6);
        uid(7) = Co_u*uid(7);
    else
        uid(7) = uid(7);
    end

%% ASU Rack
total_uid = a_sum + uid;
for i=1:7
    if (total_uid(1,i) + u0(i) >= ASU_M)
        uid(1,i) = uid(1,i) - ((total_uid(1,i) + u0(i)) - ASU_M);
    elseif (total_uid(1,i) + u0(i) <= ASU_m)
        uid(1,i) = uid(1,i) - ((total_uid(1,i) + u0(i)));
    else
        uid(1,i) = uid(1,i);
    end
end
total_uid = a_sum + uid;