clearvars
clc

% load('GM1257')
load('GM1055')

Gm=PolyGm(:,1:9);
[U,S,V]=svd(Gm);

%% 1982 dynamics
tau0=0.74;
tau=0.582;
tau1=1.064;

s=tf('s');
Ta=1/(1+.2*s)^2;                             % actuator transfer function
Ts=(1-s*tau/2)/(1+s*tau/2)/(1+s*tau1);       % strip dynamics transfer function
Tm=1/(1+s*tau0)/(1+0.01*s);                  % shapemeter dynamics transfer function
% W=Ta.*Ts.*Tm*eye(38);                        % Dynamic model
W=Ta.*Ts.*Tm;                        % Dynamic model

sys=ss(W);                                   % Plant dynamics for simulink

%% Controller dynamics for SVD
SV=9;
C0=(.4*s+.28)/(s+.001);
csys=ss(C0);                                 % Controller dynamics for Simulink

%% Input constraints
ub = [100 160]; % upper bound
lb = [0 0];     % lower bound

simpar.con.u_d=25;  % ������ �� ASU ���� ����
simpar.con.u_min_asu=lb(1);
simpar.con.u_min_imr=lb(2);
simpar.con.u_max_asu=ub(1);
simpar.con.u_max_imr=ub(2);

%% Simulation parameters
Ts=0.5;
Tf=15;

simsel.smodel=3; % gm
simsel.cmodel=2; % 1: svd, 2: esvd 3: neurofuzzy
l2linf=3; %1: esvd, 2: linf, 3: p2p

simpar.Ts=Ts;
simpar.Tf=Tf;
simpar.con.sv=SV;

% simpar.con.Qe=[1E-7,1E-7,1E-7,1E-7,20,6.3,5,0.1,0.1];
% simpar.con.Qu=[0,0,0,0,1E-6,1E-6,1.5E-4,0.26,0.6];
simpar.con.Qe=zeros(1,9);
simpar.con.Qu=zeros(1,9);
% par=[1.13806822080615,1.49258118719420,0.0166583642415814,0.00233094439463886,0.000175614013359093,0.000413637839768631,0.000259379787410719,0.000161430858230764,0.000279945097805667,9.49179484782757e-05];
% simpar.con.Qe(5:9)=par(1:5);
% simpar.con.Qu(5:9)=par(6:10);
%% For loop for each coil data
AllFiles=dir('CoilData\');

Ly0_infty=zeros(size(AllFiles,1),1);
Ly_infty=zeros(size(AllFiles,1),1);
Ly0_mse=zeros(size(AllFiles,1),1);
Ly_mse=zeros(size(AllFiles,1),1);
violate_flag=zeros(size(AllFiles,1),1);
result_indices=1;



for FileNo = 1:size(AllFiles,1)
    %% Load Pass6 work data
%     i=1524:1600
%     filename = ['CoilNo=EAV',num2str(i),'  Pass=6--0'];
    % filename = 'CoilNo=EAV1524  Pass=6--0';
    if strfind(AllFiles(FileNo).name,'CoilNo')
        load(['CoilData\',AllFiles(FileNo).name],'ShapeProfile','MillSpeed','UpIMRSHFT_Ref','LoIMRSHFT_Ref','ASU_R_Ref')
        
        if norm(ShapeProfile(floor(end/2),1:5))<1E-3
            width=1055;
            flag_sim=1;
        else
            width=1257;
            flag_sim=0;
        end
        if flag_sim
            %% Initial Conditions
            u0=[ASU_R_Ref(2000,:)*0.01,UpIMRSHFT_Ref(2000,:)*0.1,LoIMRSHFT_Ref(2000,:)*0.1]; % for ESVD
            d=ShapeProfile(2000,:)*0.01;                 % Initial shapeprofile
            x=((0:25)/12.5)-1;
            P = polyfit(x,d(7:32),8);
            d=[zeros(1,6),polyval(P,x),zeros(1,6)];
            
            %% Discrete Time Simulation
            [y,u,flags,t_elapsed]=dsim_zrm_meas_t(sys,csys,Gm,Gm,d,u0,simsel,simpar,l2linf);
            
            %% Save Results
            
            Ly_infty(result_indices)=max(y(end,:));
            Ly_mse(result_indices)=norm(y(end,:));
            violate_flag(result_indices)=max(max(flags));
            File_number(result_indices)=FileNo;
            data(result_indices).coilname=AllFiles(FileNo).name;
            data(result_indices).d=d;
            data(result_indices).u0=u0;
            data(result_indices).y=y;
            data(result_indices).u=u;
            data(result_indices).flags=flags;
            data(result_indices).Ly_infty=max(y(end,:));
            data(result_indices).Ly_mse=norm(y(end,:));
            result_indices=result_indices+1;
        end
    end
end
%% plot results
figure(1)
subplot(211)
bar(Ly_infty(1:result_indices-1))
ylabel('Infinity norm of yf (I-Unit)')
ylim([0 50])
subplot(212)
bar(Ly_mse(1:result_indices-1))
ylim([0 100])
ylabel('MSE of yf (I-Unit)')
xlabel('# of coil data')
figure(2)
bar(t_elapsed*1000)
title('Time elapsed for solving OP') % esvd: 0.0023 s, L-infinity: 0.0113 s, P2P: 0.0125
ylabel('ms')
% subplot(313)
% bar(violate_flag(1:result_indices-1))
mean(Ly_infty(1:result_indices-1))
mean(Ly_mse(1:result_indices-1))
mean(t_elapsed)
% t=0:Ts:Tf;
% figure(1)
% subplot(311)
% plot(t,u),xlabel('Time (s)'),ylabel('mm')
% subplot(312)
% bar(u(1,:)),xlabel('Time (s)'),ylabel('mm')
% subplot(313)
% bar(u(end,:)),xlabel('Time (s)'),ylabel('mm')
% 
% figure(2)
% subplot(211)
% plot(t,y),xlabel('Time (s)'),ylabel('I-Unit')
% ylim([-60 60])
% subplot(212)
% plot(y(1,:)),hold on
% plot(y(end,:)),hold off
% xlabel('Zone'),ylabel('I-Unit')
% legend('y(0)','y(Tf)','Location','Best')
% 
% figure(3) % a flag: upper/lower bound ���� �� on, d flag: ������ �� ASU ���� �Ÿ��� u_diff �̻��� ��� on
% stairs(t,flags(:,1)),hold on,stairs(t,flags(:,2)),hold off,legend('a flag','d flag'),ylim([-0.2 1.2])