function [a_flag, d_flag] = violate_cons(du,u0,ub,lb,u_diff)

reg=1E-5;
u=du+u0;

a_flag=(max(u(1:7))>ub(1)+reg) || (max(u(8:9))>ub(2)+reg) || (min(u(1:7))<lb(1)-reg) || (min(u(8:9))<lb(2)-reg);

C_u = [1 -1 0 0 0 0 0 0 0 
    0 1 -1 0 0 0 0 0 0 
    0 0 1 -1 0 0 0 0 0 
    0 0 0 1 -1 0 0 0 0 
    0 0 0 0 1 -1 0 0 0 
    0 0 0 0 0 1 -1 0 0 ];

C_u = [C_u; -1*C_u];

d_flag = max(abs(C_u*u'))>u_diff+reg;
end