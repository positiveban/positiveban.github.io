function [y, u, flags] = dsim_zrm(sys,csys,GmPlant,GmCon,d,u0,simsel,simpar)

    Ts=simpar.Ts;
    Tf=simpar.Tf;
    SV=simpar.con.sv;
    
    % for cost function
    Qe=simpar.con.Qe;
    Qu=simpar.con.Qu;
    
    ssel=simsel.smodel;
    csel=simsel.cmodel;

    % Plant model discretization
    sysd=c2d(ss(sys*eye(38)),Ts);

    %Controller model discretization
    Cdsvd=c2d(ss(csys)*eye(SV),Ts);
    Cdesvd=c2d(ss(csys)*eye(9),Ts);
    
    % Actuator constraints
    u_d = simpar.con.u_d; 
    u_min = simpar.con.u_min_asu*ones(1,9);
    u_min(8:9) = simpar.con.u_min_imr;
    u_max = simpar.con.u_max_asu*ones(1,9);
    u_max(8:9) = simpar.con.u_max_imr;
        
    % initialization of variables
    [nx,~]=size(sysd.b);
    [ny,~]=size(sysd.c);
    [nu_svd,nx_svd]=size(Cdsvd.c);
    [nu,nx_esvd]=size(Cdesvd.c);
    
    N=Tf/Ts + 1;
    x=zeros(N,nx);
    y=zeros(N,ny);
    y_=zeros(N,ny);
    flag_a=zeros(N,1);
    flag_d=zeros(N,1);
    xc_svd=zeros(N,nx_svd);
    uc_svd=zeros(N,nu_svd);
    xc_esvd=zeros(N,nx_esvd);
    du=zeros(N,nu);
    u=zeros(N,nu);
    delay=mean(sysd.InputDelay+sysd.OutputDelay);
    tot_u=zeros(N,nu);
    td=0;

    % Compute relative constraints
    d1 = u0(2:7) - u0(1:6)+ u_d;
    d2 = u0(1:6) - u0(2:7)+ u_d;
    constraint_d = [d1'; d2'];
    u_lb = u_min - u0;
    u_ub = u_max - u0;
    
    % Singular value decomposition
    [U,S,V]=svd(GmCon);
    
    for k=1:N
        % output shape calculation
        if k<=delay+1
            y(k,:)=d;
        else
            y(k,:)=(sysd.c*x(k-floor(delay),:)'+d')';
        end
        % Contol selection
        if csel == 1
            % SVD control
            yh=-U(:,1:SV)'*y(k,:)';
            xc_svd(k+1,:)=(Cdsvd.a*xc_svd(k,:)' + Cdsvd.b*yh)';
            uc_svd(k,:)=(Cdsvd.c*xc_svd(k,:)' + Cdsvd.d*yh)';
            du(k,:)=((V(:,1:SV)/S(1:SV,1:SV))*uc_svd(k,:)')';

        elseif csel == 2
            % ESVD control
            yh = esvd_func(-y(k,:)',xc_esvd(k,:), GmCon, constraint_d, u_lb', u_ub', Cdesvd.c, Cdesvd.d,V,Qe,Qu);
            
            xc_esvd(k+1,:)=(Cdesvd.a*xc_esvd(k,:)'+Cdesvd.b*yh)';
            du(k,:)=(Cdesvd.c*xc_esvd(k,:)'+Cdesvd.d*yh)';
        elseif csel == 3
            % Neuro-fuzzy control
            if simpar.width==1055
                yhat=y(k,7:32);
            else
                yhat=y(k,3:36);
            end
            matrix_shape=[0,1,0.861752494445443,0.526003193980871,0.206216133313328,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.0862768412313548,0.129764190587811,0.159617831071986,0;1,0.104080757959965,0,0.0677858548180250,0.252996744421115,0.346069063027350,0.370423454410186,0.256252377080230,0.146940676352764,0.0467225858339979,0,0,0,0,0,0,0,0,0,0,0.0164349149417853,0,0,0,0,0;0,0,0,0,0.0313540441533669,0.548524521467433,0.308633581309749,0.0180899891521313,0,0,0,0,0,0.0993829741154599,0.112472918738987,0,0.219980461657831,0.420722216198200,1,0.871213594129132,0.768659824038079,0.0939488662263607,0,0,0,0;0.136240037683763,0.320904641404898,0.621591924318686,0.891990499234575,0.967737619639885,1,0.803421224137784,0.561921853299957,0.234567577162884,0,0,0,0,0,0,0,0,0,0,0.0549748386560286,0.0284828519729975,0.0708107109449005,0.0516765068937127,0,0.0585943296708698,0.453152757397808;0,0,0,0.192382066545994,0.797146591665659,0.868593450276243,1,0.810644588523311,0.558206615478150,0.0234627779189242,0.00366764915525263,0,0,0,0,0,0,0,0.0266396479963660,0.749103083083528,0.304016691904193,0.171182154071664,0,0,0,0;0,0.169681355379296,0.373166316657802,0.732138894841791,0.831077707892414,1,0.813159268441788,0.613640930149054,0.670196826217521,0.787076310460463,0.476819066854400,0.0923884837778892,0,0,0,0,0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0.130030183249728,0.630293980210586,1,0.776840632101463,0.423084721438891,0,0,0,0,0,0.0987167832361389,0.0511245048390143,0.210948791169203,0.0876216221921601,0,0,0,0,0,0,0;0.299485620416879,0,0,0,0,0,0,0,0,0,0,0,0,0.0249322343641393,0,0,0,0,0,0,0,0,0.0286868498329803,0.159550364911853,0.272640880256352,1;0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.191011324392283,0.618439919314903,1,0.943896921637927,0.753849632825028,0.579746082488431,0.131308340270542,0,0,0;0,0.384730475329871,0.677229767443438,0.640746487432662,0.0808716927824626,0.0493675568600514,0,0,0.0542631248923302,0.0370230843522347,0.0255595032014023,0,0,0.0268035263575298,0,0,0,0,0,0,0,0,0.298695910983605,1,0.425105940791137,0;0.0188908149198349,0.128743267269080,0,0,0,0,0,0,0,0,0,0.0743018067770971,0.0346641304897769,0.0821160630497320,0.147239288462783,0.167519531031636,0.159196254896196,0.0752037204604674,0.109536030031258,0,0,0,0.244546995374629,0.826361165525252,1,0.537480442415260;0.0168393218526229,0,0,0,0,0,0,0,0,0,0,0.0450152486622940,0,0,0,0,0.000552031874584733,0,0,0.258377201424871,0.877651014142414,1,0.761837697086840,0.279681494876929,0.0855381141571046,0.108566611318041;0,0,0,0,0,0,0,0,0,0,0.105515916847971,0.171580794749133,0.0295424305918397,0,0.697546508149508,1,0.625342922390615,0.660127797643840,0.0434161394160373,0,0,0,0,0,0,0;0.122791472410914,1,0.860712308628997,0.184599468821878,0,0,0,0,0,0,0.153498357954248,0.755868836401839,0.782740889754424,0.697520078898053,0.372170308084886,0.0778187264120814,0,0,0,0,0,0,0,0.293098108644028,0.652743988289232,0.429636827680560];
            percen=inverse_term(yhat,matrix_shape);
            output_sum=fuzzy_term(percen,yhat,td,matrix_shape,simpar.width,simpar.tune_par);
            if(k==1)
                du(k,:)=break_term(output_sum,u0,du(k,:),simpar.con.u_min_asu,simpar.con.u_max_asu,simpar.con.u_d);
                du(k,:)=du(k,:);
                td=1;
            else
                du(k,:)=break_term(output_sum,u0,du(k-1,:),simpar.con.u_min_asu,simpar.con.u_max_asu,simpar.con.u_d);
                du(k,:)=du(k,:);
                td=1;
            end
        else
        end
        % input saturation
%         u(k,:)=min(u_max - u0,u(k,:));
%         u(k,:)=max(u_min - u0,u(k,:));
        
        [flag_a(k),flag_d(k)]=violate_cons(du(k,:),u0,u_max(7:8),u_min(7:8),u_d);
        
        % Static model selection
        if ssel == 1
            % IFM model
            y_(k,:) = IFM_SHAPEs_POSCO(du(k,:),simpar.ifm,simpar.width*0.001);
        elseif ssel == 2
            % CEM model
            y_(k,:) = CEM_ZRMShape_ver1(du(k,:),simpar.cem,simpar.width);
        elseif ssel == 3
            % Gm (Plant)
            y_(k,:) = GmPlant * du(k,:)';
        end
        u(k,:)=du(k,:)+u0;
        % Discrete time Plant Dynamics
        x(k+1,:)=(sysd.a*x(k,:)'+sysd.b*y_(k,:)')';
    end
    flags=[flag_a,flag_d];
end