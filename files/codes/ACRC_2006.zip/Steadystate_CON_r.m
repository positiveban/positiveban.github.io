clear all;
%% condenser parameters
% heat transfer coefficient
aoc=0.12583;
ai1c=0.38791;
ai2c=1;

% area
% Aoc=2.7927;
% Aic=0.2750;
% Acsc=5.156e-005;
Aoc=2.7927;
Aic=0.275;
Acsc=5.156e-005;

% thermal capacity of condenser
cpvc=2.1745388;

%
%muc=0.1;
syms('muc');
%gammac=param(10);
% length
Ltc=10.6895;
Vrec=0.0028665;

mdotin=0.007131777060388;
mdotout=0.007131777060388;
hin=4.433711052642836e+02;
Tain=25.669659;
m_air=0.29382712;

L1=sym('L1');
Pc=973.4489;
%gammac=0.75;
syms('gammac');
mrec=0.8;
Tw1=sym('Tw1');
Tw2=sym('Tw2');

%% refrigerant values
L2=Ltc-L1;

%rhoa=refpropm('D','T',Tain+272.15,'P',101.325,'air');
Cp=refpropm('C','T',Tain+272.15,'P',101.325,'air')/1000;

h_g=hg(Pc); 
h_f=hf(Pc);
h1=(h_g+hin)/2;
rho1=refpropm('D','P',Pc,'H',h1*1e+3,'R134a');
drho1_h=drho_H(Pc,h1); drho1_P=drho_P(Pc,h1); 

%dh_f=dhf(Pc);
rho_f=rhof(Pc); rho_g=rhog(Pc); 
dpfh_f=d_pfhf(Pc); dh_g=dhg(Pc); drho_f=drhof(Pc); drho_g=drhog(Pc);
dpgh_g=d_pghg(Pc); du_g=dug(Pc); du_f=duf(Pc);
rho2=rho_f*(1-gammac)+rho_g*gammac;

u_f=refpropm('U','P',Pc,'Q',0,'R134a')/1000
u_g=refpropm('U','P',Pc,'Q',1,'R134a')/1000
V_f=(rho_g*Vrec-mrec)/(rho_g-rho_f);
V_g=Vrec-V_f;

m_f=rho_f*V_f;
m_g=rho_g*V_g;
mrec;

Slip_ratio=(rho_f/rho_g)^(1/3);
mus=(rho_g/rho_f)*Slip_ratio;
a=mus/(1-mus);
b=1/(1-mus);
% 
% xint2=b*exp((gammac-b)/(a*b))-a;
% if(xint2>0.999)
%     xint2=1;
% elseif(xint2<0.001)
%     xint2=0;
% end
p=[2626025.29303640,-6202849.90412487,5038641.65522231,-1152664.17262897];
hint2=p(1)*gammac^3+p(2)*gammac^2+p(3)*gammac+p(4);
%hint2=refpropm('H','P',Pc,'Q',xint2,'R134a');
%syms('hint2');
Trin=refpropm('T','P',Pc,'H',hin*1e+3,'R134a')-272.15;
Tsat=refpropm('T','P',Pc,'Q',1,'R134a')-272.15;

Tr1=refpropm('T','P',Pc,'H',h1*1e+3,'R134a')-272.15;
Tr2=refpropm('T','P',Pc,'Q',1,'R134a')-272.15;
Ta=((1+muc)/(1-muc)*(m_air*Cp)/(aoc*Aoc)*Tain + (L1*Tw1/Ltc + L2*Tw2/Ltc))/(1/(1-muc)*((m_air*Cp)/(aoc*Aoc)) + 1);

%% Matrix for descriptor model
% z=zeros(6);
% z(1,1)=(rho1*(h1-h_g))*Acsc;
% z(1,2)=((drho1_P+(1/2)*drho1_h*dh_g)*(h1-h_g) + (1/2)*drho_g*rho1 - 1)*Acsc*L1;
% z(2,1)=(rho_f*(h_g-h_f))*(1-gammac)*Acsc;
% z(2,2)=(dpfh_f*(1-gammac) + dpgh_g*gammac - drho_f*h_g*(1-gammac) - drho_g*h_g*gammac - 1)*Acsc*L2;
% z(2,3)=rho_f*(h_g-h_f)*Acsc*L2;
% z(2,4)=hint2-h_g;
% z(3,1)=(rho1 - rho_f*(1-gammac) - rho_g*gammac)*Acsc;
% z(3,2)=((drho_f*(1-gammac)+drho_g*gammac)*L2+(drho1_P+(1/2)*drho1_h*dh_g)*L1)*Acsc;
% z(3,3)=(rho_g-rho_f)*Acsc*L2;
% z(3,4)=1;
% z(4,2)=(drho_g*V_g*u_g + drho_f*V_f*u_f + m_g*du_g+m_f*du_f - ((rho_g*u_g-rho_f*u_f)/(rho_g-rho_f))*(drho_g*V_g+drho_f*V_f));
% z(4,4)=((rho_g*u_g-rho_f*u_f)/(rho_g-rho_f))-hint2;
% z(5,1)=cpvc*(Tw1-Tw2)/L1;
% z(5,5)=cpvc;
% z(6,6)=cpvc;

%syms('Trec');
%% States of condenser with reciever

f(1)=mdotin*(hin-h_g) + ai1c*Aic*(L1/Ltc)*(Tw1-Tr1);
f(2)=(mdotout*(h_g-hint2)) + ai2c*Aic*(L2/Ltc)*(Tw2-Tr2);
f(3)=mdotin-mdotout;
f(4)=mdotout*(hint2-h_f)-0.059536466170424600345734038987177;
f(5)=ai1c*Aic*(Tr1-Tw1)+aoc*Aoc*(Ta-Tw1);
f(6)=ai2c*Aic*(Tr2-Tw2)+aoc*Aoc*(Ta-Tw2);
Taout=(1/(1-muc))*Ta-(muc/(1-muc))*Tain;
%%
eqn1=f(1)==0;
eqn2=f(2)==0;
eqn3=f(4)==0;
eqn4=f(5)==0;
eqn5=f(6)==0;
eqn6=Taout==30.44;

%% solve
%[L1_s, Tw1_s, Tw2_s, muc_s,UA,hint2]=solve(eqn1,eqn2,eqn3,eqn4,eqn5,L1,Tw1,Tw2,muc,UA,hint2)
%S=vpasolve(eqn1,eqn2,eqn3,eqn4,eqn5,eqn6,L1,Tw1,Tw2,muc,UA,hint2,[0.01 5],[25 40],[25 40],[0 1],[0 2],[200 300])
S=vpasolve(eqn1,eqn2,eqn3,eqn4,eqn5,L1,Tw1,Tw2,muc,gammac)
S.L1
S.Tw1
S.Tw2
S.muc
S.gammac