xc0=xc(50,:);
uc0=con_u(50,:);
%%

%Linearization of condenser

aoc=0.12583;
ai1c=0.38791;
ai2c=1;
%ai3c=2.076170446347414e-05;
ai3c=1;
% area
% Aoc=2.7927;
% Aic=0.2750;
% Acsc=5.156e-005;
Aoc=2.7927;
Aic=0.275;
Acsc=5.156e-005;

% thermal capacity of condenser
cpvc=2.1745388;

%
muc=0.007612174529842;
% length
Ltc=10.6895;

%%
L1=xc0(1);
L2=xc0(2);
Pc=xc0(3);
hout=xc0(4);
Tw1=xc0(5);
Tw2=xc0(6);
Tw3=xc0(7);

uc=uc0;

mdotin=uc(1);
mdotout=uc(2);
hin=uc(3);
Tain=uc(4);
m_air=uc(5);

%%
L3=Ltc-L1-L2;

rhoa=refpropm('D','T',Tain+272.15,'P',101.325,'air');
Cp=refpropm('C','T',Tain+272.15,'P',101.325,'air')/1000;

hgg=hg(Pc); 
hff=hf(Pc);
h1=(hgg+hin)/2;
rho1=refpropm('D','P',Pc,'H',h1*1e+3,'R134a');
h3=(hff+hout)/2;
rho3=refpropm('D','P',Pc,'H',h3*1e+3,'R134a');

drho1_h=drho_H(Pc,h1); drho1_P=drho_P(Pc,h1); 
drho3_h=drho_H(Pc,h3); drho3_P=drho_P(Pc,h3); 

rho_f=rhof(Pc); rho_g=rhog(Pc);
dpfh_f=d_pfhf(Pc); dh_f=dhf(Pc); dh_g=dhg(Pc); drho_f=drhof(Pc); drho_g=drhog(Pc);
dpgh_g=d_pghg(Pc); 

Trin=refpropm('T','P',Pc,'H',hin*1e+3,'R134a')-272.15;
Trout=refpropm('T','P',Pc,'H',hout*1e+3,'R134a')-272.15;
Tsat=refpropm('T','P',Pc,'Q',1,'R134a')-272.15;


Tr1=refpropm('T','P',Pc,'H',h1*1e+3,'R134a')-272.15;
Tr2=refpropm('T','P',Pc,'Q',1,'R134a')-272.15;
Tr3=refpropm('T','P',Pc,'H',h3*1e+3,'R134a')-272.15;
%Ta=((1+muc)/(1-muc)*(rhoa*vae*Cp)/aoc*Tain + (L1*Tw1/Ltc + L2*Tw2/Ltc))/(1/(1-muc)*((rhoa*vae*Cp)/aoc) + 1);
%Ta=((1+muc)/(1-muc)*(rhoa*vac*Cp*Aa)/(aoc*Aoc)*Tain + (L1*Tw1/Ltc + L2*Tw2/Ltc + L3*Tw3/Ltc))/(1/(1-muc)*((rhoa*vac*Cp*Aa)/(aoc*Aoc)) + 1);
Ta=((1+muc)/(1-muc)*(m_air*Cp)/(aoc*Aoc)*Tain + (L1*Tw1/Ltc + L2*Tw2/Ltc + L3*Tw3/Ltc))/(1/(1-muc)*((m_air*Cp)/(aoc*Aoc)) + 1);
%Ta=((1+muc)/(1-muc)*(0.05)/(aoc*Aoc)*Tain + (L1*Tw1/Ltc + L2*Tw2/Ltc + L3*Tw3/Ltc))/(1/(1-muc)*((0.05)/(aoc*Aoc)) + 1);


Slip_ratio=(rho_f/rho_g)^(1/3);

xout=refpropm('Q','H',hout*1e+3,'P',Pc,'R134a');
if (xout<0.001)
    xout=0;
elseif(xout>0.999)
    xout=1;
end
xin=refpropm('Q','H',hin*1e+3,'P',Pc,'R134a');
if (xin<0.001)
    xin=0;
elseif(xin>0.999)
    xin=1;
end
mus=(rho_g/rho_f)*Slip_ratio;
gammac=1/(1-mus)+(mus/((xout-xin)*(1-mus)^2))*log((mus+xin*(1-mus))/(mus+xin*(1-mus)+(xout-xin)*(1-mus)));
%gammac=0.8080;

%%
dao_m=0.8*aoc/m_air;
dTa_L1=((Tw1-Tw3)/Ltc)/((1/(1-muc))*(m_air*Cp/aoc/Aoc)+1);
dTa_L2=((Tw2-Tw3)/Ltc)/((1/(1-muc))*(m_air*Cp/aoc/Aoc)+1);
dTa_Tw1=(L1/Ltc)/((1/(1-muc))*(m_air*Cp/aoc/Aoc)+1);
dTa_Tw2=(L2/Ltc)/((1/(1-muc))*(m_air*Cp/aoc/Aoc)+1);
dTa_Tw3=(L3/Ltc)/((1/(1-muc))*(m_air*Cp/aoc/Aoc)+1);

dTa_Tain=(((1+muc)/(1-muc))*(m_air*Cp/aoc/Aoc))/((1/(1-muc))*(m_air*Cp/aoc/Aoc)+1);

dTa_m=(((1+muc)/(1-muc))*Tain-(1/(1-muc))*((L1*Tw1+L2*Tw2+L3*Tw3)/Ltc))/((1/(1-muc))*(m_air*Cp/aoc/Aoc)+1)^2*(Cp/aoc/Aoc)*(1-m_air/aoc*dao_m);

dTr1_Pc=0.5*(dTsat_Pe(Pc)+dTrin_P(Pc,hin));
%dTr1_Pc=(refpropm('T','P',Pc+1,'H',h1*1e+3,'R134a')-refpropm('T','P',Pc-1,'H',h1*1e+3,'R134a'))/2;

dTr1_hin=0.5*dTrout_H(Pc,hin);

drho1_Pc=drho1_P+0.5*drho1_h*dh_g;
drho1_hin=0.5*drho1_h;

dTr3_Pc=0.5*(dTsat_Pe(Pc)+dTrout_P(Pc,h3))
%dTr3_Pc=(refpropm('T','P',Pc+1,'H',h3*1e+3,'R134a')-refpropm('T','P',Pc-1,'H',h3*1e+3,'R134a'))/2
dTr3_hout=0.5*dTrout_H(Pc,hout)
%dTr3_hout=(refpropm('T','P',Pc,'H',h3*1e+3+1,'R134a')-refpropm('T','P',Pc,'H',h3*1e+3-1,'R134a'))/2
drho3_Pc=drho3_P+0.5*drho3_h*dh_f;
drho3_hout=0.5*drho3_h;


%%
fx=zeros(7,7);
fu=zeros(7,5);

fx(1,1)=ai1c*Aic/Ltc*(Tw1-Tr1);
fx(1,3)=-mdotin*dh_g + ai1c*Aic*(L1/Ltc)*(-dTr1_Pc);
fx(1,5)=ai1c*Aic*L1/Ltc;

fx(2,2)=ai2c*Aic/Ltc*(Tw2-Tr2);
fx(2,3)=mdotin*dh_g - mdotout*dh_f + ai2c*Aic*L2/Ltc*(-dTsat_Pe(Pc));
fx(2,6)=ai2c*Aic*L2/Ltc;

fx(3,1)=-ai3c*Aic/Ltc*(Tw3-Tr3);
fx(3,2)=-ai3c*Aic/Ltc*(Tw3-Tr3);
fx(3,3)=mdotout*dh_f + ai3c*Aic*L3/Ltc*(-dTr3_Pc);
fx(3,4)=-mdotout + ai3c*Aic*L3/Ltc*(-dTr3_hout);
fx(3,7)=ai3c*Aic*L3/Ltc;

fx(5,1)=aoc*Aoc*dTa_L1;
fx(5,2)=aoc*Aoc*dTa_L2;
fx(5,3)=ai1c*Aic*dTr1_Pc;
fx(5,5)= -ai1c*Aic - aoc*Aoc + aoc*Aoc*dTa_Tw1;
fx(5,6)=aoc*Aoc*dTa_Tw2;
fx(5,7)=aoc*Aoc*dTa_Tw3;

fx(6,1)=aoc*Aoc*dTa_L1;
fx(6,2)=aoc*Aoc*dTa_L2;
fx(6,3)=ai2c*Aic*dTsat_Pe(Pc);
fx(6,5)=aoc*Aoc*dTa_Tw1;
fx(6,6)= -ai2c*Aic - aoc*Aoc + aoc*Aoc*dTa_Tw2;
fx(6,7)=aoc*Aoc*dTa_Tw3;

fx(7,1)=aoc*Aoc*dTa_L1;
fx(7,2)=aoc*Aoc*dTa_L2;
fx(7,3)=ai3c*Aic*dTr3_Pc;
fx(7,4)=ai3c*Aic*dTr3_hout;
fx(7,5)=aoc*Aoc*dTa_Tw1;
fx(7,6)=aoc*Aoc*dTa_Tw2;
fx(7,7)=-ai2c*Aic - aoc*Aoc + aoc*Aoc*dTa_Tw3;
%%
fu(1,1)=hin-hgg;
fu(1,3)=mdotin + ai1c*Aic*L1/Ltc*(-dTr1_hin);
fu(2,1)=hgg;
fu(2,2)=-hff;
fu(3,2)=hff-hout;
fu(4,1)=1;
fu(4,2)=-1;
fu(5,3)=ai1c*Aic*dTr1_hin;
fu(5,4)=aoc*Aoc*dTa_Tain;
fu(5,5)=Aoc*(Ta-Tw1)*dao_m + aoc*Aoc*dTa_m;
fu(6,4)=aoc*Aoc*dTa_Tain;
fu(6,5)=Aoc*(Ta-Tw2)*dao_m + aoc*Aoc*dTa_m;
fu(7,4)=aoc*Aoc*dTa_Tain;
fu(7,5)=Aoc*(Ta-Tw3)*dao_m + aoc*Aoc*dTa_m;

%%
z=zeros(7);
z(1,1)=(rho1*(h1-hgg))*Acsc;
z(1,3)=((drho1_P+(1/2)*drho1_h*dh_g)*(h1-hgg) + (1/2)*dh_g*rho1 - 1)*Acsc*L1;
z(2,1)=(rho1*hgg-rho3*hff)*Acsc;
z(2,2)=((rho_g*hgg-rho_f*hff)*gammac + (rho_f-rho3)*hff)*Acsc;
z(2,3)=((drho1_P+(1/2)*drho1_h*dh_g)*hgg*L1 + (dpfh_f*(1-gammac)+dpgh_g*gammac-1)*L2 + (drho3_P+(1/2)*drho3_h*dh_f)*hff*L3)*Acsc;
z(2,4)=(1/2)*drho3_h*Acsc*L3*hff;
z(3,1)=rho3*(hff-h3)*Acsc;
z(3,2)=rho3*(hff-h3)*Acsc;
z(3,3)=((drho3_P+(1/2)*drho3_h*dh_f)*(h3-hff)+(1/2)*dh_f*rho3-1)*Acsc*L3;
z(3,4)=((1/2)*drho3_h*(h3-hff)+(1/2)*rho3)*Acsc*L3;
z(4,1)=(rho1-rho3)*Acsc;
z(4,2)=((rho_g-rho_f)*gammac+(rho_f-rho3))*Acsc;
z(4,3)=((drho1_P+(1/2)*drho1_h*dh_g)*L1 + (drho_f*(1-gammac)+drho_g*gammac)*L2 + (drho3_P+(1/2)*drho3_h*dh_f)*L3)*Acsc;
z(4,4)=(1/2)*drho3_h*Acsc*L3;
z(5,1)=cpvc*(Tw1-Tw2)/L1;
z(5,5)=cpvc;
z(6,6)=cpvc;
z(7,1)=cpvc*(Tw2-Tw3)/L3;
z(7,2)=cpvc*(Tw2-Tw3)/L3;
z(7,7)=cpvc;

f(1)=mdotin*(hin-hgg) + ai1c*Aic*(L1/Ltc)*(Tw1-Tr1);
f(2)=(mdotin*hgg-mdotout*hff) + ai2c*Aic*(L2/Ltc)*(Tw2-Tr2);
f(3)=mdotout*(hff-hout)+ai3c*Aic*(L3/Ltc)*(Tw3-Tr3);
f(4)=mdotin-mdotout;
f(5)=ai1c*Aic*(Tr1-Tw1)+aoc*Aoc*(Ta-Tw1);
f(6)=ai2c*Aic*(Tr2-Tw2)+aoc*Aoc*(Ta-Tw2);
f(7)=ai3c*Aic*(Tr3-Tw3)+aoc*Aoc*(Ta-Tw3);
%%

dx=[0;0;0;0;0;0;0];
du=[0;0;0;0;0];

L1=xc0(1)+dx(1);
L2=xc0(2)+dx(2);
Pc=xc0(3)+dx(3);
hout=xc0(4)+dx(4);
Tw1=xc0(5)+dx(5);
Tw2=xc0(6)+dx(6);
Tw3=xc0(7)+dx(7);

mdotin=uc(1)+du(1);
mdotout=uc(2)+du(2);
hin=uc(3)+du(3);
Tain=uc(4)+du(4);
m_air=uc(5)+du(5);

L3=Ltc-L1-L2;
Ta=((1+muc)/(1-muc)*(m_air*Cp)/(aoc*Aoc)*Tain + (L1*Tw1/Ltc + L2*Tw2/Ltc + L3*Tw3/Ltc))/(1/(1-muc)*((m_air*Cp)/(aoc*Aoc)) + 1);

rhoa=refpropm('D','T',Tain+272.15,'P',101.325,'air');
Cp=refpropm('C','T',Tain+272.15,'P',101.325,'air')/1000;

hgg=hg(Pc); 
hff=hf(Pc);
h1=(hgg+hin)/2;
rho1=refpropm('D','P',Pc,'H',h1*1e+3,'R134a');
h3=(hff+hout)/2;
rho3=refpropm('D','P',Pc,'H',h3*1e+3,'R134a');

drho1_h=drho_H(Pc,h1); drho1_P=drho_P(Pc,h1); 
drho3_h=drho_H(Pc,h3); drho3_P=drho_P(Pc,h3); 

rho_f=rhof(Pc); rho_g=rhog(Pc);
dpfh_f=d_pfhf(Pc); dh_f=dhf(Pc); dh_g=dhg(Pc); drho_f=drhof(Pc); drho_g=drhog(Pc);
dpgh_g=d_pghg(Pc); 


Tr1=refpropm('T','P',Pc,'H',h1*1e+3,'R134a')-272.15;
Tr2=refpropm('T','P',Pc,'Q',1,'R134a')-272.15;
Tr3=refpropm('T','P',Pc,'H',h3*1e+3,'R134a')-272.15;

f(1)=mdotin*(hin-hgg) + ai1c*Aic*(L1/Ltc)*(Tw1-Tr1);
f(2)=(mdotin*hgg-mdotout*hff) + ai2c*Aic*(L2/Ltc)*(Tw2-Tr2);
f(3)=mdotout*(hff-hout)+ai3c*Aic*(L3/Ltc)*(Tw3-Tr3);
f(4)=mdotin-mdotout;
f(5)=ai1c*Aic*(Tr1-Tw1)+aoc*Aoc*(Ta-Tw1);
f(6)=ai2c*Aic*(Tr2-Tw2)+aoc*Aoc*(Ta-Tw2);
f(7)=ai3c*Aic*(Tr3-Tw3)+aoc*Aoc*(Ta-Tw3);

z^-1;
dx1=(fx*dx+fu*du)
dx2=f'