function output=fCd(uv,dP)
output=((-9.5984)+(2.0481)*uv+(0.0054106)*dP+(-0.00074909)*uv*dP+(-0.037775)*uv*uv)*1e-006;

end