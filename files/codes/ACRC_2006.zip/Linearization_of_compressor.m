% linearization of compressor

Vk=4.905327870685290e-07;
wk=comp_RPM;
Pin=xe0(2);
Pout=xc0(3);
hin=xe0(3);
%%
Pr=Pout/Pin;

eta_v=etav(Pr,wk)
eta_k=etak(Pr,wk)
%Tout=refpropm('T','P',Pout,'H',hout*1e+3,'R134a')-272.15;
%%
rhok=refpropm('D','P',Pin,'H',hin*1e+3,'R134a');
sk=refpropm('S','P',Pin,'H',hin*1e+3,'R134a');
houtisen=refpropm('H','P',Pout,'S',sk,'R134a')/1000;

hout=(houtisen+hin*(eta_k-1))/eta_k;

%%
drhok_h=drho_H(Pin,hin);
drhok_p=drho_P(Pin,hin);

detav_wk=(etav(Pr,wk+1)-etav(Pr,wk-1))/2;
detav_Pr=(etav(Pr+1,wk)-etav(Pr-1,wk))/2;

detak_wk=(etak(Pr,wk+1)-etak(Pr,wk-1))/2;
detak_Pr=(etak(Pr+1,wk)-etak(Pr-1,wk))/2;
%%
dhouts_Pout=(refpropm('H','P',Pout+1,'S',sk,'R134a')-refpropm('H','P',Pout-1,'S',sk,'R134a'))/2000;
dhouts_sk=(refpropm('H','P',Pout,'S',sk+1,'R134a')-refpropm('H','P',Pout,'S',sk-1,'R134a'))/2000;
dsk_Pin=(refpropm('S','P',Pin+1,'H',hin*1e+3,'R134a')-refpropm('S','P',Pin-1,'H',hin*1e+3,'R134a'))/2;
dsk_hin=(refpropm('S','P',Pin,'H',hin*1e+3 + 1000,'R134a')-refpropm('S','P',Pin,'H',hin*1e+3 - 1000,'R134a'))/2;
%%
dTout_hout=dTrout_H(Pout,hout);
dTout_Pout=dTrout_P(Pout,hout);

%%
d=zeros(3,4);

%%
d(1,1)=Vk*rhok*eta_v + Vk*rhok*wk*detav_wk;
d(1,2)=wk*Vk*drhok_p*eta_v - wk*Vk*rhok*detav_Pr*Pr/Pin;
d(1,3)=wk*Vk*rhok*detav_Pr/Pin;
d(1,4)=wk*Vk*drhok_h*eta_v;

d(2,1)=((hin-houtisen)/eta_k/eta_k)*detak_wk;
d(2,2)=((hin-houtisen)/eta_k/eta_k)*detak_Pr*(-Pr)/Pin + dhouts_sk*dsk_Pin/eta_k;
d(2,3)=((hin-houtisen)/eta_k/eta_k)*detak_Pr/Pin+dhouts_Pout/eta_k;
d(2,4)=dhouts_sk*dsk_hin/eta_k + (eta_k-1)/eta_k;

d(3,1)=dTout_hout*d(2,1);
d(3,2)=dTout_hout*d(2,2);
d(3,3)=dTout_Pout + dTout_hout*d(2,3);
d(3,4)=dTout_hout*d(2,4);

uk0=[wk,Pin,Pout,hin]';
%%

u=[0,0,0,0]';

output=compressor_L(wk+u(1),Pin+u(2),Pout+u(3),hin+u(4))

comp_eq=compressor(wk+u(1),Pin+u(2),Pout+u(3),hin+u(4))