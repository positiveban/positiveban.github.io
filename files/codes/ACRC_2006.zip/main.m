clc;
clear all;
%% Constant Parameters

%% initial parameters
clear all;

% Load initial condition
load('initial_cond');
% Pe0=270.4;
% Pc0=970;
% Hev=253.820;
% Hcin=414.441;
% Hcon=443.4781;
% m_air_c=0.29382712;
% Tain_c=25.669659;
% m_air_e=0.15685995;
% Tain_e=23.981;
% xe0=[3.4515 Pe0 Hcin 3.161 16.44];
% xc0=[1.1446 9.1948 Pc0 Hev 35.1054 34.2921 30.4038];
% comp_RPM=1600;
% EEV_p=13;

% model selection (1: nonlinear model, 2: Linear model)
sel=1;

% Total simulation time
T=1000;
step_size=0.01;
%% simulation
switch sel
    case 1
        sim('Heatpump_sim.slx');
    case 2
        sim('Heatpump_sim_L.slx');
end
%% Plotting
% Condenser
figure();
n=6;
subplot(n,1,1);
plot(t,u(:,1));
title('RPM');

subplot(n,1,2);
% plot(t,xc(:,1),t,xc(:,2));
% title('L of condenser');
plot(t,u(:,2));
title('EEV opening');

subplot(n,1,3);
plot(t,xc(:,3));
title('Pressure of condenser');

subplot(n,1,4);
plot(t,xc(:,5),t,xc(:,6),t,xc(:,7));
title('Wall temp of condenser');

subplot(n,1,5);
plot(t,yc(:,10),t,yc(:,11));
title('SH&SC of condenser')

subplot(n,1,6);
plot(t,xc(:,4));
title('Hout of condenser')


% Evaporator
% hFig=figure();
% set(hFig,'Position',[600 200 300 1200]);
figure();
n=6;
subplot(n,1,1);
plot(t,u(:,1));
title('RPM');

subplot(n,1,2);
% plot(t,xc(:,1),t,xc(:,2));
% title('L of condenser');
plot(t,u(:,2));
title('EEV opening');

subplot(n,1,3);
plot(t,xe(:,2));
title('Pressure of evaporator');

subplot(n,1,4);
plot(t,xe(:,4),t,xe(:,5));
title('Wall temp of evaporator');

subplot(n,1,5);
plot(t,ye(:,8));
title('SH of evaporator');

subplot(n,1,6);
plot(t,xe(:,3));
title('Hout of evaporator');
% 
% subplot(n,1,7);
% plot(t,ye(:,9));
% title('refrigerant mass of Evaporator')
