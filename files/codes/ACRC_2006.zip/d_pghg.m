function output = d_pghg(P)

% P (kJ/kg)
% for R134a
    rho_g=rhog(P);
    h_g=hg(P);
    drho_g=drhog(P);
    dh_g=dhg(P);
    
    output=rho_g*dh_g + h_g*drho_g + drho_g*dh_g;
    
end