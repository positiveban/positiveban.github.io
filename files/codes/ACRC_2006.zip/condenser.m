function outputs=condenser(x,u)

%% condenser parameters
% heat transfer coefficient
%param=[0.1 0.1 1.0 20.0 2.7927 0.2750 5.156e-005 2.1746 0.51 0.86 10.7095 0.0020];

aoc=0.12583;
ai1c=0.38791;
ai2c=1;
%ai3c=2.076170446347414e-05;
ai3c=1;
% area
% Aoc=2.7927;
% Aic=0.2750;
% Acsc=5.156e-005;
Aoc=2.7927;
Aic=0.275;
Acsc=5.156e-005;

% thermal capacity of condenser
cpvc=2.1745388;

%
muc=0.007612174529842;
% length
Ltc=10.6895;

%%
L1=x(1);
L2=x(2);
Pc=x(3);
hout=x(4);
Tw1=x(5);
Tw2=x(6);
Tw3=x(7);

mdotin=u(1);
mdotout=u(2);
hin=u(3);
Tain=u(4);
m_air=u(5);

%% refrigerant values
L3=Ltc-L1-L2;

rhoa=refpropm('D','T',Tain+272.15,'P',101.325,'air');
Cp=refpropm('C','T',Tain+272.15,'P',101.325,'air')/1000;

hgg=hg(Pc); 
hff=hf(Pc);
h1=(hgg+hin)/2;
rho1=refpropm('D','P',Pc,'H',h1*1e+3,'R134a');
h3=(hff+hout)/2;
rho3=refpropm('D','P',Pc,'H',h3*1e+3,'R134a');

drho1_h=drho_H(Pc,h1); drho1_P=drho_P(Pc,h1); 
drho3_h=drho_H(Pc,h3); drho3_P=drho_P(Pc,h3); 

rho_f=rhof(Pc); rho_g=rhog(Pc);
dpfh_f=d_pfhf(Pc); dh_f=dhf(Pc); dh_g=dhg(Pc); drho_f=drhof(Pc); drho_g=drhog(Pc);
dpgh_g=d_pghg(Pc); 

Trin=refpropm('T','P',Pc,'H',hin*1e+3,'R134a')-272.15;
Trout=refpropm('T','P',Pc,'H',hout*1e+3,'R134a')-272.15;
Tsat=refpropm('T','P',Pc,'Q',1,'R134a')-272.15;


Tr1=refpropm('T','P',Pc,'H',h1*1e+3,'R134a')-272.15;
Tr2=refpropm('T','P',Pc,'Q',1,'R134a')-272.15;
Tr3=refpropm('T','P',Pc,'H',h3*1e+3,'R134a')-272.15;
%Ta=((1+muc)/(1-muc)*(rhoa*vae*Cp)/aoc*Tain + (L1*Tw1/Ltc + L2*Tw2/Ltc))/(1/(1-muc)*((rhoa*vae*Cp)/aoc) + 1);
%Ta=((1+muc)/(1-muc)*(rhoa*vac*Cp*Aa)/(aoc*Aoc)*Tain + (L1*Tw1/Ltc + L2*Tw2/Ltc + L3*Tw3/Ltc))/(1/(1-muc)*((rhoa*vac*Cp*Aa)/(aoc*Aoc)) + 1);
Ta=((1+muc)/(1-muc)*(m_air*Cp)/(aoc*Aoc)*Tain + (L1*Tw1/Ltc + L2*Tw2/Ltc + L3*Tw3/Ltc))/(1/(1-muc)*((m_air*Cp)/(aoc*Aoc)) + 1);
%Ta=((1+muc)/(1-muc)*(0.05)/(aoc*Aoc)*Tain + (L1*Tw1/Ltc + L2*Tw2/Ltc + L3*Tw3/Ltc))/(1/(1-muc)*((0.05)/(aoc*Aoc)) + 1);


Slip_ratio=(rho_f/rho_g)^(1/3);

xout=refpropm('Q','H',hout*1e+3,'P',Pc,'R134a');
if (xout<0.001)
    xout=0;
elseif(xout>0.999)
    xout=1;
end
xin=refpropm('Q','H',hin*1e+3,'P',Pc,'R134a');
if (xin<0.001)
    xin=0;
elseif(xin>0.999)
    xin=1;
end
mus=(rho_g/rho_f)*Slip_ratio;
gammac=1/(1-mus)+(mus/((xout-xin)*(1-mus)^2))*log((mus+xin*(1-mus))/(mus+xin*(1-mus)+(xout-xin)*(1-mus)));
%gammac=0.8080;

z=zeros(7);
z(1,1)=(rho1*(h1-hgg))*Acsc;
z(1,3)=((drho1_P+(1/2)*drho1_h*dh_g)*(h1-hgg) + (1/2)*dh_g*rho1 - 1)*Acsc*L1;
z(2,1)=(rho1*hgg-rho3*hff)*Acsc;
z(2,2)=((rho_g*hgg-rho_f*hff)*gammac + (rho_f-rho3)*hff)*Acsc;
z(2,3)=((drho1_P+(1/2)*drho1_h*dh_g)*hgg*L1 + (dpfh_f*(1-gammac)+dpgh_g*gammac-1)*L2 + (drho3_P+(1/2)*drho3_h*dh_f)*hff*L3)*Acsc;
z(2,4)=(1/2)*drho3_h*Acsc*L3*hff;
z(3,1)=rho3*(hff-h3)*Acsc;
z(3,2)=rho3*(hff-h3)*Acsc;
z(3,3)=((drho3_P+(1/2)*drho3_h*dh_f)*(h3-hff)+(1/2)*dh_f*rho3-1)*Acsc*L3;
z(3,4)=((1/2)*drho3_h*(h3-hff)+(1/2)*rho3)*Acsc*L3;
z(4,1)=(rho1-rho3)*Acsc;
z(4,2)=((rho_g-rho_f)*gammac+(rho_f-rho3))*Acsc;
z(4,3)=((drho1_P+(1/2)*drho1_h*dh_g)*L1 + (drho_f*(1-gammac)+drho_g*gammac)*L2 + (drho3_P+(1/2)*drho3_h*dh_f)*L3)*Acsc;
z(4,4)=(1/2)*drho3_h*Acsc*L3;
z(5,1)=cpvc*(Tw1-Tw2)/L1;
z(5,5)=cpvc;
z(6,6)=cpvc;
z(7,1)=cpvc*(Tw2-Tw3)/L3;
z(7,2)=cpvc*(Tw2-Tw3)/L3;
z(7,7)=cpvc;

%% States of evaporator

f(1)=mdotin*(hin-hgg) + ai1c*Aic*(L1/Ltc)*(Tw1-Tr1);
f(2)=(mdotin*hgg-mdotout*hff) + ai2c*Aic*(L2/Ltc)*(Tw2-Tr2);
f(3)=mdotout*(hff-hout)+ai3c*Aic*(L3/Ltc)*(Tw3-Tr3);
f(4)=mdotin-mdotout;
f(5)=ai1c*Aic*(Tr1-Tw1)+aoc*Aoc*(Ta-Tw1);
f(6)=ai2c*Aic*(Tr2-Tw2)+aoc*Aoc*(Ta-Tw2);
f(7)=ai3c*Aic*(Tr3-Tw3)+aoc*Aoc*(Ta-Tw3);

%% Outputs of evaporator
Taout=(1/(1-muc))*Ta-(muc/(1-muc))*Tain;
Trsh=Trin-Tsat;
Trsc=Tsat-Trout;
mc=(rho_f*(1-gammac)+rho_g*gammac)*Acsc*L1+rho1*Acsc*L2;

dx=z^-1*f';
y=[L1;L2;Pc;hout;Tw1;Tw2;Tw3;Taout;Trout;Trsh;Trsc;gammac];
% 
% if (((L1+dx(1))<0)||((L1+dx(1))>Ltc))
%     dx(1)=0;
% end
% 
% if (((L2+dx(2))<0)||((L2+dx(2))>Ltc))
%     dx(2)=0;
% end
for i=1:7
    if abs(dx(i))<1e-30
        dx(i)=0;
    end
end
outputs=[dx;y];
end