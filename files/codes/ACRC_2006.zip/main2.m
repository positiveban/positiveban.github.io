clc;
clear all;
%% Constant Parameters

%% initial parameters
clear all;

% load('initcond2.mat');
L1c=1.1851;
L1e=3.2862;
Pe0=270.4;
Pc0=973.4489;
Hev=262.3627;
Hcin=414.441;
Hcon=443.3711;
m_air_c=0.29382712;
Tain_c=25.669659;
m_air_e=0.15685995;
Tain_e=23.981;

xe0=[L1e Pe0 Hcin 4.0515 21.8488];
xc0=[L1c Pc0 0.37315 0.8 35.7740 34.8310];
comp_RPM=1600;
EEV_p=13;

T=500;
% load('initcond2.mat');
%% simulation
sim('Heatpump_sim2.slx');
%% Plotting
% Condenser
figure();
n=7;
subplot(n,1,1);
plot(t,mdotv);
hold on;
plot(t,mdotk,'red');
title('flow rates');

subplot(n,1,2);
plot(t,xc(:,1));
title('L of condenser');

subplot(n,1,3);
plot(t,xc(:,2));
title('Pressure of condenser');

subplot(n,1,4);
plot(t,xc(:,4),t,xc(:,5));
title('Wall temp of condenser');

subplot(n,1,5);
plot(t,yc(:,7));
title('SH of condenser')

subplot(n,1,6);
plot(t,xc(:,3));
title('Gamma of condenser')

subplot(n,1,7);
plot(t,yc(:,9));
title('refrigerant mass of condenser')


% Evaporator
% hFig=figure();
% set(hFig,'Position',[600 200 300 1200]);
figure();
n=7;
subplot(n,1,1);
plot(t,mdotv);
hold on;
plot(t,mdotk,'red');
title('flow rates');

subplot(n,1,2);
plot(t,xe(:,1));
title('L of evaporator');

subplot(n,1,3);
plot(t,xe(:,2));
title('Pressure of evaporator');

subplot(n,1,4);
plot(t,xe(:,4),t,xe(:,5));
title('Wall temp of evaporator');

subplot(n,1,5);
plot(t,ye(:,8));
title('SH of evaporator');

subplot(n,1,6);
plot(t,xe(:,3));
title('Hout of evaporator');

subplot(n,1,7);
plot(t,ye(:,9));
title('refrigerant mass of condenser')
