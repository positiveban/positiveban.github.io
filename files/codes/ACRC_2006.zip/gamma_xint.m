clear gamma xint2
gamma=[0.01:0.01:1.20]

xint2=b.*exp((gamma-b)./(a.*b))-a; 
%%
for i=1:120
    if xint2(i)<0
        xint2(i)=0;
    elseif xint2(i)>1
        xint2(i)=1;
    end
   hint2(i)=refpropm('H','P',Pc,'Q',xint2(i),'R134a'); 
end
%%
plot(gamma,hint2)
xlim([0.75 1.15])

save('data.mat','gamma','hint2','xint2')

%%
xdata=gamma(80:114);
ydata=hint2(80:114);
n=3;
p=polyfit(xdata,ydata,n)

figure(1)
plot(xdata,ydata)
hold on
f = p(1).*xdata.^3+p(2).*xdata.^2+p(3).*xdata+p(4);
%f=polyval(p,xdata);
plot(xdata,f,'r')
hold off