function outputs=compressor(wk, Pin, Pout,hin)

%% Compressor Parameters
%Vk=1.107877047751609e-05;       %2000RPM 0.02
%Vk=4.900634913874601e-07;
Vk=4.905327870685290e-07;
%%
rhok=refpropm('D','P',Pin,'H',hin*1e+3,'R134a');
sk=refpropm('S','P',Pin,'H',hin*1e+3,'R134a');
houtisen=refpropm('H','P',Pout,'S',sk,'R134a')/1000;
Pr=Pout/Pin;
%% Temporary variables
eta_v=(.65127)+(0.00027681)*wk+(-0.031338)*Pr+(3.0221e-005)*wk*Pr+(-1.1905e-007)*wk*wk+(-0.0081256)*Pr*Pr;
eta_k=(.5119)+(-.0030112)*wk+(1.5437)*Pr+(-0.00089251)*wk*Pr+(1.5795e-006)*wk*wk+(0.066539)*Pr*Pr;
%eta_k=1.7;
% eta_v=v1+v2*wk+v3*Pr+v4*wk*Pr+v5*wk*wk+v6*Pr*Pr;
% eta_k=k1+k2*wk+k3*Pr+k4*wk*Pr+k5*wk*wk+k6*Pr*Pr;
% 


%% output of compressor
mdotk=wk*Vk*rhok*eta_v;
hout=(houtisen+hin*(eta_k-1))/eta_k;
Tout=refpropm('T','P',Pout,'H',hout*1e+3,'R134a')-272.15;

outputs=[mdotk;hout;Tout];
end