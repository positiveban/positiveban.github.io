function output = drho_P(P,H)

% P (kJ/kg)
% for R134a

    output=(refpropm('D','P',P+1,'H',H*1e+3,'R134a')-refpropm('D','P',P-1,'H',H*1e+3,'R134a'))/2;
    
end