%fitting
clear all
Pc=973.4489;
xint2=[0.01:0.01:1]
[s1 s2]=size(xint2)
for i=1:s2
hint2(i)=refpropm('H','P',Pc,'Q',xint2(i),'R134a');
end

p = polyfit(hint2,xint2,1)

y=p(1)*245.66621676814189597381955026153+p(2)

figure()
plot(hint2,xint2,hint2,y,'o')
%%
gamma
xint2=b*exp((gammac-b)/(a*b))-a;