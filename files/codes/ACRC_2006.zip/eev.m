function outputs=eev(uv, Pin, Pout, hin)

dP=abs(Pin-Pout);
%Cd=((-9.7959)+(1.8027)*uv+(0.0074994)*dP+(-0.00093102)*uv*dP+(-0.018605)*uv*uv)*1e-006;
Cd=((-9.5984)+(2.0481)*uv+(0.0054106)*dP+(-0.00074909)*uv*dP+(-0.037775)*uv*uv)*1e-006;
rhov=refpropm('D','P',Pin,'H',hin*1e+3,'R134a');
%% output of eev
%mdotv=Cd*sqrt(rhov*dP)+0.00029-2.7304e-06;
mdotv=Cd*sqrt(rhov*dP)+2.872696e-04;
hout=hin;
Tout=refpropm('T','P',Pout,'H',hout*1e+3,'R134a')-272.15;
outputs=[mdotv;hout;Tout];
end