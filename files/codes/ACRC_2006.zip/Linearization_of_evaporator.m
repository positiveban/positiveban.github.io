
xe0=xe(50,:);
u0=eva_u(50,:);
ye0=ye(50,:);

L1=xe0(1);
Pe=xe0(2);
hout=xe0(3);
Tw1=xe0(4);
Tw2=xe0(5);

mdotin=u0(1);
mdotout=u0(2);
hin=u0(3);
Tain=u0(4);
%m_air=u(5);
m_air=u0(5);

aoe=0.058341;
ai1e=2.00;
ai2e=0.040;

Aoe=3.068;
Aie=0.321;
Acse=2.062e-005;

Lte=11.46;

cpve=0.877716;

mue=0.2039;

Aa=0.065;
%%
Cp=refpropm('C','T',Tain+272.15,'P',101.325,'air')/1000;

hgg=hg(Pe); 
h2=(hgg+hout)/2; rho2=refpropm('D','P',Pe,'H',h2*1e+3,'R134a');
rho_f=rhof(Pe); h_f=hf(Pe); rho_g=rhog(Pe); h_g=hg(Pe);
dpfh_f=d_pfhf(Pe); dh_f=dhf(Pe); dh_g=dhg(Pe); drho2_h=drho_H(Pe,h2); drho2_P=drho_P(Pe,h2); drho_f=drhof(Pe); drho_g=drhog(Pe);
dpgh_g=d_pghg(Pe); 

Slip_ratio=(rho_f/rho_g)^(1/3);
Tout=refpropm('T','P',Pe,'H',hout*1e+3,'R134a')-272.15;
Tsat=refpropm('T','P',Pe,'Q',1,'R134a')-272.15;
L2=Lte-L1;

xout=refpropm('Q','H',hout*1e+3,'P',Pe,'R134a');
if (xout<0.001)
    xout=0;
elseif(xout>0.999)
    xout=1;
end
xin=refpropm('Q','H',hin*1e+3,'P',Pe,'R134a');
if (xin<0.001)
    xin=0;
elseif(xin>0.999)
    xin=1;
end
mus=(rho_g/rho_f)*Slip_ratio;
gammae=1/(1-mus)+(mus/((xout-xin)*(1-mus)^2))*log((mus+xin*(1-mus))/(mus+xin*(1-mus)+(xout-xin)*(1-mus)));
%m_air=rhoa*vae*Aa;

dTrout_Pe=dTrout_P(Pe,hout);
dTsat_P=dTsat_Pe(Pe);
Tr1=refpropm('T','P',Pe,'Q',1,'R134a')-272.15;
Tr2=refpropm('T','P',Pe,'H',h2*1e+3,'R134a')-272.15;
%Ta=((1+mue)/(1-mue)*(rhoa*vae*Cp*Aa)/(aoe*Aoe)*Tain + (L1*Tw1/Lte + L2*Tw2/Lte))/(1/(1-mue)*((rhoa*vae*Cp*Aa)/(aoe*Aoe)) + 1);
%Ta=(((1+mue)/(1-mue))*((Cp*m_air)/(aoe*Aoe))*Tain + (L1*Tw1/Lte + L2*Tw2/Lte))/((1/(1-mue))*((Cp*m_air)/(aoe*Aoe)) + 1)
%Ta=((1+mue)/(1-mue)*(0.136)/(aoe*Aoe)*Tain + (L1*Tw1/Lte + L2*Tw2/Lte))/(1/(1-mue)*((0.136)/(aoe*Aoe)) + 1);
%Ta=((1+mue)/(1-mue)*(0.05)/(aoe*Aoe)*Tain + (L1*Tw1/Lte + L2*Tw2/Lte))/(1/(1-mue)*((0.05)/(aoe*Aoe)) + 1);
Ta=(((1+mue)/(1-mue))*((m_air*Cp)/(aoe*Aoe))*Tain+(L1*Tw1/Lte+L2*Tw2/Lte))/((1/(1-mue))*((m_air*Cp)/(aoe*Aoe))+1);
%%

dao_m=0.8*aoe/m_air;
dTa_L1=((Tw1-Tw2)/Lte)/((1/(1-mue))*(m_air*Cp/aoe/Aoe)+1);
dTa_Tw1=(L1/Lte)/((1/(1-mue))*(m_air*Cp/aoe/Aoe)+1);
dTa_Tw2=(L2/Lte)/((1/(1-mue))*(m_air*Cp/aoe/Aoe)+1);
dTa_Tain=(((1+mue)/(1-mue))*(m_air*Cp/aoe/Aoe))/((1/(1-mue))*(m_air*Cp/aoe/Aoe)+1);
dTa_m=(((1+mue)/(1-mue))*Tain-(1/(1-mue))*((L1*Tw1+L2*Tw2)/Lte))/((1/(1-mue))*(m_air*Cp/aoe/Aoe)+1)^2*(Cp/aoe/Aoe)*(1-m_air/aoe*dao_m);

dTr2_Pe=0.5*(dTsat_Pe(Pe)+dTrout_P(Pe,hout));
dTr2_hout=0.5*dTrout_H(Pe,hout);
drho2_Pe=drho2_P+0.5*drho2_h*dh_g;
drho2_ho=0.5*drho2_h;

dTr1_Pe=((refpropm('T','P',Pe+1,'Q',1,'R134a')-refpropm('T','P',Pe-1,'Q',1,'R134a'))/2);
%dTr2_Pe=((refpropm('T','P',Pe+1,'H',h2*1e+3,'R134a')-refpropm('T','P',Pe-1,'H',h2*1e+3,'R134a'))/2);
%dTr2_hout=((refpropm('T','P',Pe,'H',(h2*1e+3)+1000,'R134a')-refpropm('T','P',Pe,'H',(h2*1e+3)-1000,'R134a'))/2);


%%

z=zeros(5);
z(1,1)=(rho_f*(h_f-h_g))*(1-gammae)*Acse;
z(1,2)=((dpfh_f-drho_f*h_g)*(1-gammae)+(dpgh_g-drho_g*h_g)*gammae-1)*Acse*L1;
z(2,1)=rho2*(h_g-h2)*Acse;
z(2,2)=((drho2_P+(1/2)*drho2_h*dh_g)*(h2-h_g) + (rho2/2)*dh_g - 1)*Acse*L2;
z(2,3)=((1/2)*drho2_h*(h2-h_g)+(rho2/2))*Acse*L2;
z(3,1)=((rho_g-rho2)+(rho_f-rho_g)*(1-gammae))*Acse;
z(3,2)=((drho2_P+(1/2)*drho2_h*dh_g)*L2+(drho_f*(1-gammae)+drho_g*gammae)*L1)*Acse;
z(3,3)=(1/2)*drho2_h*Acse*L2;
z(4,4)=cpve;
z(5,1)=cpve*(Tw1-Tw2)/L2;
z(5,5)=cpve;

%%
f(1)=mdotin*(hin-hgg)+ai1e*Aie*(L1/Lte)*(Tw1-Tr1);
f(2)=mdotout*(hgg-hout)+ai2e*Aie*(L2/Lte)*(Tw2-Tr2);
f(3)=mdotin-mdotout;
f(4)=aoe*Aoe*(Ta-Tw1)-ai1e*Aie*(Tw1-Tr1);
f(5)=aoe*Aoe*(Ta-Tw2)-ai2e*Aie*(Tw2-Tr2);
%%
fx(1,1)=ai1e*Aie*(Tw1-Tr1)/Lte;
fx(1,2)=-mdotin*dh_g-ai1e*Aie*L1/Lte*dTr1_Pe;
fx(1,4)=ai1e*Aie*L1/Lte;

fx(2,1)=-ai2e*Aie/Lte*(Tw2-Tr2);
fx(2,2)=mdotout*dh_g-ai2e*Aie*L2/Lte*dTr2_Pe;
fx(2,3)=-mdotout-ai2e*Aie*L2/Lte*dTr2_hout;
fx(2,5)=ai2e*Aie*L2/Lte;

fx(4,1)=aoe*Aoe*dTa_L1;
fx(4,2)=ai1e*Aie*dTr1_Pe;
fx(4,4)=-ai1e*Aie-aoe*Aoe+aoe*Aoe*dTa_Tw1;
fx(4,5)=aoe*Aoe*dTa_Tw2;

fx(5,1)=aoe*Aoe*dTa_L1;
fx(5,2)=ai2e*Aie*dTr2_Pe;
fx(5,3)=ai2e*Aie*dTr2_hout;
fx(5,4)=aoe*Aoe*dTa_Tw1;
fx(5,5)=-ai2e*Aie-aoe*Aoe+aoe*Aoe*dTa_Tw2;

fu(1,1)=hin-h_g;
fu(1,3)=mdotin;

fu(2,2)=h_g-hout;

fu(3,1)=1;
fu(3,2)=-1;

fu(4,4)=aoe*Aoe*dTa_Tain;
%fu(4,4)=0;
fu(4,5)=dao_m*Aoe*(Ta-Tw1)+aoe*Aoe*(dTa_m);
%fu(4,5)=0;
fu(5,4)=aoe*Aoe*dTa_Tain;
%fu(5,4)=0;
fu(5,5)=dao_m*Aoe*(Ta-Tw2)+aoe*Aoe*(dTa_m);
%fu(5,5)=0;

%%
clc
dx=[0;0;0;0;0];
du=[0;0;0;0;0];

L1=xe0(1)+dx(1);
Pe=xe0(2)+dx(2);
hout=xe0(3)+dx(3);
Tw1=xe0(4)+dx(4);
Tw2=xe0(5)+dx(5);

mdotin=u0(1)+du(1);
mdotout=u0(2)+du(2);
hin=u0(3)+du(3);
Tain=u0(4)+du(4);
%m_air=u(5);
m_air=u0(5)+du(5);

Tsh0=ye0(8);

Cp=refpropm('C','T',Tain+272.15,'P',101.325,'air')/1000;

hgg=hg(Pe); 
h2=(hgg+hout)/2; rho2=refpropm('D','P',Pe,'H',h2*1e+3,'R134a');
rho_f=rhof(Pe); h_f=hf(Pe); rho_g=rhog(Pe); h_g=hg(Pe);
dpfh_f=d_pfhf(Pe); dh_f=dhf(Pe); dh_g=dhg(Pe); drho2_h=drho_H(Pe,h2); drho2_P=drho_P(Pe,h2); drho_f=drhof(Pe); drho_g=drhog(Pe);
dpgh_g=d_pghg(Pe); 

Slip_ratio=(rho_f/rho_g)^(1/3);
Tout=refpropm('T','P',Pe,'H',hout*1e+3,'R134a')-272.15;
Tsat=refpropm('T','P',Pe,'Q',1,'R134a')-272.15;
L2=Lte-L1;

xout=refpropm('Q','H',hout*1e+3,'P',Pe,'R134a');
if (xout<0.001)
    xout=0;
elseif(xout>0.999)
    xout=1;
end
xin=refpropm('Q','H',hin*1e+3,'P',Pe,'R134a');
if (xin<0.001)
    xin=0;
elseif(xin>0.999)
    xin=1;
end
mus=(rho_g/rho_f)*Slip_ratio;
gammae=1/(1-mus)+(mus/((xout-xin)*(1-mus)^2))*log((mus+xin*(1-mus))/(mus+xin*(1-mus)+(xout-xin)*(1-mus)));
%m_air=rhoa*vae*Aa;
Trout=Tout;


Tr1=refpropm('T','P',Pe,'Q',1,'R134a')-272.15;
Tr2=refpropm('T','P',Pe,'H',h2*1e+3,'R134a')-272.15;
%Ta=((1+mue)/(1-mue)*(rhoa*vae*Cp*Aa)/(aoe*Aoe)*Tain + (L1*Tw1/Lte + L2*Tw2/Lte))/(1/(1-mue)*((rhoa*vae*Cp*Aa)/(aoe*Aoe)) + 1);
%Ta=(((1+mue)/(1-mue))*((Cp*m_air)/(aoe*Aoe))*Tain + (L1*Tw1/Lte + L2*Tw2/Lte))/((1/(1-mue))*((Cp*m_air)/(aoe*Aoe)) + 1)
%Ta=((1+mue)/(1-mue)*(0.136)/(aoe*Aoe)*Tain + (L1*Tw1/Lte + L2*Tw2/Lte))/(1/(1-mue)*((0.136)/(aoe*Aoe)) + 1);
%Ta=((1+mue)/(1-mue)*(0.05)/(aoe*Aoe)*Tain + (L1*Tw1/Lte + L2*Tw2/Lte))/(1/(1-mue)*((0.05)/(aoe*Aoe)) + 1);
Ta=(((1+mue)/(1-mue))*((m_air*Cp)/(aoe*Aoe))*Tain+(L1*Tw1/Lte+L2*Tw2/Lte))/((1/(1-mue))*((m_air*Cp)/(aoe*Aoe))+1);


f(1)=mdotin*(hin-hgg)+ai1e*Aie*(L1/Lte)*(Tw1-Tr1);
f(2)=mdotout*(hgg-hout)+ai2e*Aie*(L2/Lte)*(Tw2-Tr2);
f(3)=mdotin-mdotout;
f(4)=aoe*Aoe*(Ta-Tw1)-ai1e*Aie*(Tw1-Tr1);
f(5)=aoe*Aoe*(Ta-Tw2)-ai2e*Aie*(Tw2-Tr2);

z^-1;
dx1=(fx*dx+fu*du);
dx2=f';

dP=xc(50,3)-Pe
Trsh=Tout-Tsat
Trsh_L=(dTrout_Pe-dTsat_P)*dx(2)+dTrout_H(Pe,hout)*dx(3)+Tsh0
C=[0,0,1,zeros(1,5),-1,0,0,0
    zeros(1,8),dTrout_Pe-dTsat_P,dTrout_H(Pe,hout),0,0];
y0=[dP,Tsh0]'