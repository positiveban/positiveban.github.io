% Linearization of eev
uv=EEV_p;
Pin=xc0(3);
Pout=xe0(2);
hin=xc0(4);

hout=hin;
dP=abs(Pin-Pout);
Cd=((-9.5984)+(2.0481)*uv+(0.0054106)*dP+(-0.00074909)*uv*dP+(-0.037775)*uv*uv)*1e-006;
rhov=refpropm('D','P',Pin,'H',hin*1e+3,'R134a');
Tout=refpropm('T','P',Pout,'H',hout*1e+3,'R134a')-272.15;

dCd_uv=(fCd(uv+0.1,dP)-fCd(uv-0.1,dP))/0.2;
dCd_dP=(fCd(uv,dP+1)-fCd(uv,dP-1))/2;
drhov_Pin=drho_P(Pin,hin);
drhov_hin=drho_H(Pin,hin);

dToutv_dPsat=(refpropm('T','P',Pout+1,'H',hout*1e+3,'R134a')-refpropm('T','P',Pout-1,'H',hout*1e+3,'R134a'))/2;

dv=zeros(3,4);

dv(1,1)=dCd_uv*sqrt(rhov*dP);
dv(1,2)=dCd_dP*sqrt(rhov*dP) + (Cd/2/sqrt(rhov*dP))*(rhov+dP*drhov_Pin);
dv(1,3)=-(dCd_dP)*sqrt(rhov*dP) - (Cd*rhov/2/sqrt(rhov*dP));
dv(1,4)=(Cd/2/sqrt(rhov*dP))*(dP*drhov_hin);
dv(2,4)=1;
dv(3,3)=dToutv_dPsat;

uv0=[uv;Pin;Pout;hin];
%%
u=[0,0,0,0]';
%uv0=[uv;Pin;Pout;hin];

output=eev_L(uv+u(1),Pin+u(2),Pout+u(3),hin+u(4))

output2=eev(uv+u(1),Pin+u(2),Pout+u(3),hin+u(4))
