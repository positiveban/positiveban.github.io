function output=etak(Pr,wk)

output=(.5119)+(-.0030112)*wk+(1.5437)*Pr+(-0.00089251)*wk*Pr+(1.5795e-006)*wk*wk+(0.066539)*Pr*Pr;
end