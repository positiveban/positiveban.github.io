function output = hf(P)

% P (kJ/kg)
% for R134a

    output=refpropm('H','P',P,'Q',0,'R134a')/1000;
    
end