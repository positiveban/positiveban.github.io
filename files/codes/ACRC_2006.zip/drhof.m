function output = drhof(P)

% P (kJ/kg)
% for R134a

    output=(refpropm('D','P',P+1,'Q',0,'R134a')-refpropm('D','P',P-1,'Q',0,'R134a'))/2;
    
end