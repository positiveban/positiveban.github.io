function output = hg(P)

% P (J/kg)
% for R134a

    output=refpropm('H','P',P,'Q',1,'R134a')/1000;
    
end