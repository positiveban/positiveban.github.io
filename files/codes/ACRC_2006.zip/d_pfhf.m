function output = d_pfhf(P)

% P (kJ/kg)
% for R134a
    rho_f=rhof(P);
    h_f=hf(P);
    drho_f=drhof(P);
    dh_f=dhf(P);
    
    output=rho_f*dh_f + h_f*drho_f + drho_f*dh_f;
    
end