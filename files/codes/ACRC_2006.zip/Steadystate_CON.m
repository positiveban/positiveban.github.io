clear all
clc
%% condenser parameters
% heat transfer coefficient
% heat transfer coefficient
aoc=0.12583;
ai1c=0.38791;
ai2c=1;
ai3c=sym('ai3c');
%ai3c=2.076170446347414e-05;

% area
% Aoc=2.7927;
% Aic=0.2750;
% Acsc=5.156e-005;
Aoc=2.7927;
Aic=0.275;
Acsc=5.156e-005;

% thermal capacity of condenser
cpvc=2.1745388;

%
%muc=0.007612174529842;
syms('muc');
%gammac=param(10);
% length
Ltc=10.6895;

mdotin=0.00713;
mdotout=0.00713;
hin=443.4781;
Tain=25.669659;
m_air=0.29382712;
hout=253.820;
%hout=253.000;

L1=sym('L1');
L2=sym('L2');
Pc=970;
gammac=sym('gammac');
Tw1=sym('Tw1');
Tw2=sym('Tw2');
Tw3=sym('Tw3');


%% refrigerant values
L3=Ltc-L1-L2;

rhoa=refpropm('D','T',Tain+272.15,'P',101.325,'air');
Cp=refpropm('C','T',Tain+272.15,'P',101.325,'air')/1000;

hgg=hg(Pc); 
hff=hf(Pc);
h1=(hgg+hin)/2;
rho1=refpropm('D','P',Pc,'H',h1*1e+3,'R134a');
h3=(hff+hout)/2;
rho3=refpropm('D','P',Pc,'H',h3*1e+3,'R134a');

drho1_h=drho_H(Pc,h1); drho1_P=drho_P(Pc,h1); 
drho3_h=drho_H(Pc,h3); drho3_P=drho_P(Pc,h3); 

rho_f=rhof(Pc); h_f=hf(Pc); rho_g=rhog(Pc); h_g=hg(Pc);
dpfh_f=d_pfhf(Pc); dh_f=dhf(Pc); dh_g=dhg(Pc); drho_f=drhof(Pc); drho_g=drhog(Pc);
dpgh_g=d_pghg(Pc); 

Trin=refpropm('T','P',Pc,'H',hin*1e+3,'R134a')-272.15;
Trout=refpropm('T','P',Pc,'H',hout*1e+3,'R134a')-272.15;
Tsat=refpropm('T','P',Pc,'Q',1,'R134a')-272.15;


Tr1=refpropm('T','P',Pc,'H',h1*1e+3,'R134a')-272.15;
Tr2=refpropm('T','P',Pc,'Q',1,'R134a')-272.15;
Tr3=refpropm('T','P',Pc,'H',h3*1e+3,'R134a')-272.15;
%Ta=((1+muc)/(1-muc)*(rhoa*vae*Cp)/aoc*Tain + (L1*Tw1/Ltc + L2*Tw2/Ltc))/(1/(1-muc)*((rhoa*vae*Cp)/aoc) + 1);
%Ta=((1+muc)/(1-muc)*(rhoa*vac*Cp*Aa)/(aoc*Aoc)*Tain + (L1*Tw1/Ltc + L2*Tw2/Ltc + L3*Tw3/Ltc))/(1/(1-muc)*((rhoa*vac*Cp*Aa)/(aoc*Aoc)) + 1);
%Ta=((1+muc)/(1-muc)*(0.136)/(aoc*Aoc)*Tain + (L1*Tw1/Ltc + L2*Tw2/Ltc + L3*Tw3/Ltc))/(1/(1-muc)*((0.136)/(aoc*Aoc)) + 1);
%Ta=((1+muc)/(1-muc)*(0.05)/(aoc*Aoc)*Tain + (L1*Tw1/Ltc + L2*Tw2/Ltc + L3*Tw3/Ltc))/(1/(1-muc)*((0.05)/(aoc*Aoc)) + 1);
Ta=((1+muc)/(1-muc)*(m_air*Cp)/(aoc*Aoc)*Tain + (L1*Tw1/Ltc + L2*Tw2/Ltc + L3*Tw3/Ltc))/(1/(1-muc)*((m_air*Cp)/(aoc*Aoc)) + 1);
% 
% z=zeros(7);
% z(1,1)=(rho1*(h1-h_g))*Acsc;
% z(1,3)=((drho1_P+(1/2)*drho1_h*dh_g)*(h1-h_g) + (1/2)*drho_g*rho1 - 1)*Acsc*L1;
% z(2,1)=(rho1*h_g-rho3*h_f)*Acsc;
% z(2,2)=((rho_g*h_g-rho_f*h_f)*gammac+(rho_f-rho3)*h_f)*Acsc;
% z(2,3)=((drho1_P+(1/2)*drho1_h*dh_g)*h_g*L1 + (dpfh_f*(1-gammac)+dpgh_g*gammac-1)*L2 + (drho3_P+(1/2)*drho3_h*dh_f)*h_f*L3)*Acsc;
% z(2,4)=(1/2)*drho3_h*Acsc*L3*h_f;
% z(3,1)=rho3*(h_f-h3)*Acsc;
% z(3,2)=rho3*(h_f-h3)*Acsc;
% z(3,3)=((drho3_P+(1/2)*drho3_h*h_f)*(h3-h_f)+(1/2)*dh_f*rho3-1)*Acsc*L3;
% z(3,4)=((1/2)*drho3_h*(h3-h_f)+(1/2)*rho3)*Acsc*L3;
% z(4,1)=(rho1-rho3)*Acsc;
% z(4,2)=((rho_g-rho_f)*gammac+(rho_f-rho3))*Acsc;
% z(4,3)=((drho1_P+(1/2)*drho1_h*dh_g)*L1 + (drho_f*(1-gammac)+drho_g*gammac)*L2 + (drho3_P+(1/2)*drho3_h*dh_f)*L3)*Acsc;
% z(4,4)=(1/2)*drho3_h*Acsc*L3;
% z(5,1)=cpvc*(Tw1-Tw2)/L1;
% z(5,5)=cpvc;
% z(6,6)=cpvc;
% z(7,1)=cpvc*(Tw2-Tw3)/L3;
% z(7,2)=cpvc*(Tw2-Tw3)/L3;
% z(7,7)=cpvc;

%% States of evaporator

f(1)=mdotin*(hin-hgg) + ai1c*Aic*(L1/Ltc)*(Tw1-Tr1);
f(2)=(mdotin*hgg-mdotout*hff) + ai2c*Aic*(L2/Ltc)*(Tw2-Tr2);
f(3)=mdotout*(hff-hout)+ai3c*Aic*(L3/Ltc)*(Tw3-Tr3);
f(4)=mdotin-mdotout;
f(5)=ai1c*Aic*(Tr1-Tw1)+aoc*Aoc*(Ta-Tw1);
f(6)=ai2c*Aic*(Tr2-Tw2)+aoc*Aoc*(Ta-Tw2);
f(7)=ai3c*Aic*(Tr3-Tw3)+aoc*Aoc*(Ta-Tw3);

Taout=(1/(1-muc))*Ta-(muc/(1-muc))*Tain;

%%
eqn1=f(1)==0;
eqn2=f(2)==0;
eqn3=f(3)==0;
eqn4=f(5)==0;
eqn5=f(6)==0;
eqn6=f(7)==0;
%eqn7=Taout==30.44;
eqn7=Taout==30.44;
%% solve

[L1_s,L2_s, Tw1_s, Tw2_s,Tw3_s,muc_s, ai3c]=vpasolve(eqn1,eqn2,eqn3,eqn4,eqn5,eqn6,eqn7,L1,L2,Tw1,Tw2,Tw3,muc,ai3c)