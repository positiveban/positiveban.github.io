function output=eev_opening(EEV_p,t)


step_v=50;
sett_v=[0.5,0,-0.5,0.5,-0.5,1,-1,0,-0.5,1,0.5,-1,0,0.5,0.5,0,-0.5,0.5,-0.5,1,-1,0,-0.5,1,0.5,-1,0,0.5];
n_v=floor(t/step_v)+1;
diff_v=sett_v(n_v);
    
%output_v=diff_v+0.1*rand;

output=EEV_p+diff_v;
%output=EEV_p;
end