clc;
% parameters
% 
Pe0=270.4;
Pc0=973.4489;
Hev=253.820;
Hcin=414.441;
Hcon=443.4781;
%%
bcost=1000;
for i=1:100000
addparam=rand(1)*1e-11;
param=4.905320e-7+addparam;

output=compressor(1600,Pe0,Pc0,Hcin,param);

mdotk=output(1);
hout=output(2);
Tout=output(3);

m_e=abs(0.007131777060388-mdotk);
h_e=abs(256800-hout)/1000;
T_e=abs(41.3566-Tout);

costfunction=m_e*m_e;

if (costfunction<bcost)
    bcost=costfunction
    bparam=param
    addparam
end

end
%3.3072e-05
%3.3070e-05

% bcost =
% 
%    3.3306e-25
% 
% 
% bparam =
% 
%    1.1079e-05
