function output = dTsat_Pe(P)

% P (kJ/kg)
% for R134a

    output=(refpropm('T','P',P+1,'Q',1,'R134a')-refpropm('T','P',P-1,'Q',1,'R134a'))/2;
    
end