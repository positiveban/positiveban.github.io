clc;
% parameters
% 

bcost=1000;
for i=1:1:1e8
param=48+2*rand(1);

output=eev(20,Pc0,Pe0,Hev,param);

mdotk=output(1);
hout=output(2);
Tout=output(3);

m_e=abs(0.020-mdotk);
h_e=abs(256800-hout)/1000;
T_e=abs(41.3566-Tout);

costfunction=m_e*m_e;

if (costfunction<bcost)
    bcost=costfunction
    bparam=param
end

end