function output = rhog(P)

% P (kPa)
% forR134a

    output=refpropm('D','P',P,'Q',1,'R134a');
    
end