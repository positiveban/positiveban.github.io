function output=compressor_RPM(n_RPM,t)

step_k=100;
sett_k=[50,0,-50,0,50,-50,50,0,-100,0,100,0,-100,100,50,0,-50,0,50,-50,50,0,-100,0,100,0,-100,100];
n_k=floor(t/step_k)+1;
diff_k=sett_k(n_k);

output=n_RPM+diff_k;
%output=n_RPM;
end