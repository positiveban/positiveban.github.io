function output = drho_H(P,H)

% P (kJ/kg)
% for R134a

    output=(refpropm('D','P',P,'H',H*1e+3 + 1000,'R134a')-refpropm('D','P',P,'H',H*1e+3 - 1000,'R134a'))/2;
    
end