function output=etav(Pr,wk)

output=(.65127)+(0.00027681)*wk+(-0.031338)*Pr+(3.0221e-005)*wk*Pr+(-1.1905e-007)*wk*wk+(-0.0081256)*Pr*Pr;
end