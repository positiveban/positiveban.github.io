aoe=0.058341;
ai1e=2.00;
ai2e=0.040;

% area
% Aoe=2.909;
% Aie=0.2733;
%Acse=4.217e-005;
Aoe=3.068;
Aie=0.321;
Acse=2.062e-005;

% Length
%Lte=11.8734;
Lte=11.46;

% thermal capacity of evaporator
%cpve=1.097968;
cpve=0.877716;

% 
%mue=0.01;
syms('mue')
%mue=0.2039;
%mue=0.01;
%Aa=0.005;
Aa=0.065;

%
 L1=sym('L1');
 Pe=270.4;
 hout=414.441;
 Tw1=sym('Tw1');
 Tw2=sym('Tw2');
 
%  L1=3.4515;
%  Pe=270.4;
%  hout=414.441;
%  Tw1=4.1150;
%  Tw2=22.1204;
% 
 
mdotin=0.007131777060388;
mdotout=0.007131777060388;
hin=262.3627;
Tain=23.9819834;
%vae=u(5);
m_air=0.15685995;

%% refrigerant values
rhoa=refpropm('D','T',Tain+272.15,'P',101.325,'air');
Cp=refpropm('C','T',Tain+272.15,'P',101.325,'air')/1000;

hgg=hg(Pe); 
h2=(hgg+hout)/2; rho2=refpropm('D','P',Pe,'H',h2*1e+3,'R134a');
rho_f=rhof(Pe); h_f=hf(Pe); rho_g=rhog(Pe); h_g=hg(Pe);
dpfh_f=d_pfhf(Pe); dh_f=dhf(Pe); dh_g=dhg(Pe); drho2_h=drho_H(Pe,h2); drho2_P=drho_P(Pe,h2); drho_f=drhof(Pe); drho_g=drhog(Pe);
dpgh_g=d_pghg(Pe); 

Slip_ratio=(rho_f/rho_g)^(1/3);
Tout=refpropm('T','P',Pe,'H',hout*1e+3,'R134a')-272.15;
Tsat=refpropm('T','P',Pe,'Q',1,'R134a')-272.15;
L2=Lte-L1;

xout=refpropm('Q','H',hout*1e+3,'P',Pe,'R134a');
if (xout<0.001)
    xout=0;
elseif(xout>0.999)
    xout=1;
end
xin=refpropm('Q','H',hin*1e+3,'P',Pe,'R134a');
if (xin<0.001)
    xin=0;
elseif(xin>0.999)
    xin=1;
end
mus=(rho_g/rho_f)*Slip_ratio;
gammae=1/(1-mus)+(mus/((xout-xin)*(1-mus)^2))*log((mus+xin*(1-mus))/(mus+xin*(1-mus)+(xout-xin)*(1-mus)));
%m_air=rhoa*vae*Aa;

Tr1=refpropm('T','P',Pe,'Q',1,'R134a')-272.15;
Tr2=refpropm('T','P',Pe,'H',h2*1e+3,'R134a')-272.15;
%Ta=((1+mue)/(1-mue)*(rhoa*vae*Cp*Aa)/(aoe*Aoe)*Tain + (L1*Tw1/Lte + L2*Tw2/Lte))/(1/(1-mue)*((rhoa*vae*Cp*Aa)/(aoe*Aoe)) + 1);
%Ta=(((1+mue)/(1-mue))*((Cp*m_air)/(aoe*Aoe))*Tain + (L1*Tw1/Lte + L2*Tw2/Lte))/((1/(1-mue))*((Cp*m_air)/(aoe*Aoe)) + 1)
%Ta=((1+mue)/(1-mue)*(0.136)/(aoe*Aoe)*Tain + (L1*Tw1/Lte + L2*Tw2/Lte))/(1/(1-mue)*((0.136)/(aoe*Aoe)) + 1);
%Ta=((1+mue)/(1-mue)*(0.05)/(aoe*Aoe)*Tain + (L1*Tw1/Lte + L2*Tw2/Lte))/(1/(1-mue)*((0.05)/(aoe*Aoe)) + 1);
Ta=(((1+mue)/(1-mue))*((m_air*Cp)/(aoe*Aoe))*Tain+(L1*Tw1/Lte+L2*Tw2/Lte))/((1/(1-mue))*((m_air*Cp)/(aoe*Aoe))+1);
% 
% z=zeros(5);
% z(1,1)=(rho_f*(h_f-h_g))*(1-gammae)*Acse;
% z(1,2)=((dpfh_f-drho_f*h_g)*(1-gammae)+(dpgh_g-drho_g*h_g)*gammae-1)*Acse*L1;
% z(2,1)=rho2*(h_g-h2)*Acse;
% z(2,2)=((drho2_P+(1/2)*drho2_h*dh_g)*(h2-h_g) + (rho2/2)*dh_g - 1)*Acse*L2;
% z(2,3)=((1/2)*drho2_h*(h2-h_g)+(rho2/2))*Acse*L2;
% z(3,1)=((rho_g-rho2)+(rho_f-rho_g)*(1-gammae))*Acse;
% z(3,2)=((drho2_P+(1/2)*drho2_h*dh_g)*L2+(drho_f*(1-gammae)+drho_g*gammae)*L1)*Acse;
% z(3,3)=(1/2)*drho2_h*Acse*L2;
% z(4,4)=cpve;
% z(5,1)=cpve*(Tw1-Tw2)/L2;
% z(5,5)=cpve;

%% States of evaporator

f(1)=mdotin*(hin-hgg)+ai1e*Aie*(L1/Lte)*(Tw1-Tr1)
f(2)=mdotout*(hgg-hout)+ai2e*Aie*(L2/Lte)*(Tw2-Tr2)
f(3)=mdotin-mdotout
f(4)=aoe*Aoe*(Ta-Tw1)-ai1e*Aie*(Tw1-Tr1)
f(5)=aoe*Aoe*(Ta-Tw2)-ai2e*Aie*(Tw2-Tr2)
Taout=(1/(1-mue))*Ta - (mue/(1-mue))*Tain

%%
eqn1=f(1)==0;
eqn2=f(2)==0;
eqn3=f(4)==0;
eqn4=f(5)==0;
eqn5=Taout==17.04;

%% solve
%[L1_s, Tw1_s, Tw2_s, mue_s]=solve(eqn1,eqn2,eqn3,eqn4,L1,Tw1,Tw2,mue)
%[L1_s, Tw1_s, Tw2_s]=solve(eqn1,eqn2,eqn3,eqn4,L1,Tw1,Tw2)
S=vpasolve(eqn1,eqn2,eqn3,eqn4,L1,Tw1,Tw2,mue);
S.L1
S.Tw1
S.Tw2
S.mue