function output = dTrin_P(P,H)

% P (kJ/kg)
% for R134a

    output=(refpropm('T','P',P+1,'H',H*1e+3,'R134a')-refpropm('T','P',P-1,'H',H*1e+3,'R134a'))/2;
    
end