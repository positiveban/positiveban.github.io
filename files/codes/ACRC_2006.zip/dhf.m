function output = dhf(P)

% P (kJ/kg)
% for R134a

    output=(refpropm('H','P',P+1,'Q',0,'R134a')-refpropm('H','P',P-1,'Q',0,'R134a'))/2000;
    
end