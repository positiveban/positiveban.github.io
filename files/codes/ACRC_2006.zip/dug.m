function output = dug(P)

% P (kJ/kg)
% for R134a

    output=(refpropm('U','P',P+1,'Q',1,'R134a')-refpropm('U','P',P-1,'Q',1,'R134a'))/2;
    
end