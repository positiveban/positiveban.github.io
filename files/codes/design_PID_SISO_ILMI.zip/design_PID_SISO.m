clc
clear all
%% System parameters

Tp=0.1667;
R=3;
beta=0.3483;
Tt=0.4;
Tg=0.08;
D=0.015;

A=[-D/Tp                1/Tp   0        0
    0                   -1/Tt  1/Tt     0
    -1/R/Tg             0      -1/Tg    0
    beta             0      0        0];
B=[0;0;1;0];
F=[1/Tp;0;0;0];

C=[beta/Tg,0,0,0
    0,0,0,1/Tg];

Cz=[1,0,0,0
    0,0,1,0];
Dzw=zeros(2,1);

%% Declare variables
n=size(A,1);
nz = size(Cz,1);
P=sdpvar(n);
Q=sdpvar(n,n,'full');
K=sdpvar(1,2);
% gamma=sdpvar(1);
X = care(A,B,eye(n));
% gamma_array=(1.5:0.1:5).^2;
gamma=5.5^2;
% for i=1:size(gamma_array,2)
% gamma=gamma_array(i);
alpha=5.5;
%% iterative LMI
flag=0;
while(1)
    while(1)
        At=A+B*K*C;
        m11 = -X -X';
        m21 = -X' + At'*X + P;
        m22 = At'*X + X'*At-alpha*P;
        m31 = F'*X;
        m32 = F'*X;
        m33 = -gamma*eye(1);
        m41 = zeros(nz,n);
        m42 = Cz;
        m43 = Dzw;
        m44 = -eye(nz);

        M1=[m11 m21' m31' m41'
            m21 m22 m32' m42'
            m31 m32 m33 m43'
            m41 m42 m43 m44];

        lmi_c=[P>=1E-6,M1<=-1E-6];
        opt=sdpsettings('verbose',0,'solver','mosek');
        diagnosis=optimize(lmi_c,trace(P),opt)
        disp('1')
        if diagnosis.problem==0
            if alpha<0
                flag=1;
                break;
            else
                if alpha<0.0001
                    alpha=alpha-0.000001
                elseif alpha<0.001
                    alpha=alpha-0.00001
                elseif alpha<0.01
                    alpha=alpha-0.0001
                elseif alpha<0.1
                    alpha=alpha-0.001
                elseif alpha<5
                    alpha=alpha-0.01
                else
                    alpha=alpha-0.05
                end
            end
%             gammas=double(gamma);
%         gammas=gamma;
        else
            if alpha<0.001-0.00001
                alpha=alpha+0.00001
            elseif alpha<0.01-0.0001
                alpha=alpha+0.0001
            elseif alpha<0.1-0.001
                alpha=alpha+0.001
            elseif alpha<5-0.01
                alpha=alpha+0.01
            else
                alpha=alpha+0.05
            end
            At=A+B*K*C;
            m11 = -X -X';
            m21 = -X' + At'*X + P;
            m22 = At'*X + X'*At-alpha*P;
            m31 = F'*X;
            m32 = F'*X;
            m33 = -gamma*eye(1);
            m41 = zeros(nz,n);
            m42 = Cz;
            m43 = Dzw;
            m44 = -eye(nz);

            M1=[m11 m21' m31' m41'
                m21 m22 m32' m42'
                m31 m32 m33 m43'
                m41 m42 m43 m44];
            
            lmi_c=[P>=1E-6,M1<=-1E-6];
            
            opt=sdpsettings('verbose',0,'solver','mosek');
            diagnosis=optimize(lmi_c,trace(P),opt)
            disp('2')
            if diagnosis.problem==0
                break;
            else
                alpha
            end
        end
    end
if flag==1
    break;
end
alpha_v=sdpvar(1);
% alpha_v=alpha;
Ps=double(P);
Ks=double(K);
At=A+B*Ks*C;
m11 = -Q -Q';
m21 = -Q' + At'*Q + Ps;
m22 = At'*Q + Q'*At-alpha_v*Ps;
m31 = F'*Q;
m32 = F'*Q;
m33 = -gamma*eye(1);
m41 = zeros(nz,n);
m42 = Cz;
m43 = Dzw;
m44 = -eye(nz);

M1=[m11 m21' m31' m41'
    m21 m22 m32' m42'
    m31 m32 m33 m43'
    m41 m42 m43 m44];

lmi_c=[P>=1E-6,M1<=-1E-6];
opt=sdpsettings('verbose',0,'solver','mosek');
diagnosis=optimize(lmi_c,alpha_v,opt)
disp('3')
alpha=double(alpha_v)
X=double(Q);
end
% end