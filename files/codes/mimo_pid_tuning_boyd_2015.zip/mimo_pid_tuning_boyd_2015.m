clc
clear all

N=300;
tau=0.3;


w=0;
s=1j*w;
P0=[(12.8*exp(-s))/(16.7*s+1), (-18.9*exp(-3*s))/(21.0*s+1)
   (6.6*exp(-7*s))/(10.9*s+1), (-19.4*exp(-3*s))/(14.2*s+1)];

Smax=1.7;
Tmax=1.7;
Qmax=3/min(svd(P0));
Rmax=10;
w=logspace(-3,3,N);

P=zeros(2,2,N);C=zeros(2,2,N);
Zt=zeros(2,2,N);
Ytt=zeros(2,2,N);Yqt=zeros(2,2,N);

I2=eye(2);
eps=0.06;
%% Initial conditions
Kp=zeros(2,2); Ki=eps*pinv(P0); Kd=zeros(2,2);
Z0t=P0*Ki;

for i=1:N
    s=1j*w(i);
    P(:,:,i)=[(12.8*exp(-s))/(16.7*s+1), (-18.9*exp(-3*s))/(21.0*s+1)
                (6.6*exp(-7*s))/(10.9*s+1), (-19.4*exp(-3*s))/(14.2*s+1)];
%     C(:,:,i)=Kp + 1/s*Ki + s/(1+tau*s)*Kd;
    
    Zt(:,:,i)=((eps+s)/s)*I2;
%         Zt(:,:,i)=I2+P(:,:,i)*C(:,:,i);
end
%% Solve iterative LMI
iterations=1;
inv_PKi_old=0;
while(1)
    disp(['Running ',num2str(iterations),'th iteration(s)...'])
    Kp=sdpvar(2,2,'full');
    Ki=sdpvar(2,2,'full');
%     Kd=sdpvar(2,2,'full');
    gamma=sdpvar(1,1,'full');
    Z0=P0*Ki;

    lmi_con = Z0'*Z0t + Z0t'*Z0 - Z0t'*Z0t>=gamma*I2;
    
    for i=1:N
        s=1j*w(i);
%         Cs(i).C=Kp + 1/s*Ki + s/(1+tau*s)*Kd;
        Cs(i).C=Kp + 1/s*Ki;

        Z(i).Z=(I2+P(:,:,i)*Cs(i).C);
        Y(i).Yt=(1/Tmax)*P(:,:,i)*Cs(i).C;
        Y(i).Yq=(1/Qmax)*Cs(i).C;
        Y(i).Yr=(1/Rmax)*P(:,:,i)';

        c1=Z(i).Z'*Zt(:,:,i) + Zt(:,:,i)'*Z(i).Z - Zt(:,:,i)'*Zt(:,:,i)>=(1/Smax^2)*I2;
        c2=[Z(i).Z'*Zt(:,:,i) + Zt(:,:,i)'*Z(i).Z - Zt(:,:,i)'*Zt(:,:,i), Y(i).Yt'
            Y(i).Yt, I2]>=0;
        c3=[Z(i).Z'*Zt(:,:,i) + Zt(:,:,i)'*Z(i).Z - Zt(:,:,i)'*Zt(:,:,i), Y(i).Yq'
            Y(i).Yq, I2]>=0;
        c4=[Z(i).Z*Zt(:,:,i)' + Zt(:,:,i)*Z(i).Z' - Zt(:,:,i)*Zt(:,:,i)', Y(i).Yr'
            Y(i).Yr, I2]>=0;
        lmi_con=[lmi_con,c1,c2,c3];
    end
    opt=sdpsettings('solver','mosek','verbose',0);
    diagnosis=optimize(lmi_con,-gamma,opt)
    if diagnosis.problem~=0
        check_lmi=checkset(lmi_con);
        break;
    end
        
    Z0t=double(Z0);
    for i=1:N
        Zt(:,:,i)=double(Z(i).Z);
    end
    inv_PKi=double(sqrt(1/gamma));
    if abs(inv_PKi_old-inv_PKi)<=1E-4
        disp('Iteration finished!')
        break;
    else
        disp(['Objective value:', num2str(inv_PKi)])
    end
    inv_PKi_old=double(sqrt(1/gamma));
    yalmip('clear')
    iterations=iterations+1;
end
double(sqrt(1/gamma))
Kp=double(Kp);
Ki=double(Ki);
Kd=double(Kd);

%%
Smag=zeros(2,N);
Tmag=zeros(2,N);
Qmag=zeros(2,N);
Rmag=zeros(2,N);
for i=1:N
    s=1j*w(i);
%     C(:,:,i)=Kp + 1/s*Ki + s/(1+tau*s)*Kd;
    C(:,:,i)=Kp + 1/s*Ki;
    Zt(:,:,i)=inv(I2+P(:,:,i)*C(:,:,i));
    Smag(:,i)=svd(double(Zt(:,:,i)));
    Qmag(:,i)=svd(double(C(:,:,i)*Zt(:,:,i)));
    Tmag(:,i)=svd(double((P(:,:,i)*C(:,:,i))*Zt(:,:,i)));
    Rmag(:,i)=svd(double(-Zt(:,:,i)*P(:,:,i)));
end
save('mimo_origin','Kp','Ki')
%% Plotting the results
figure(3)
subplot(411)
loglog(w,Smag)
hold on
loglog(w,ones(1,N)*Smax)
hold off
xlabel('$w$','Interpreter','latex')
ylabel('$|| S(iw) ||$','Interpreter','latex')
subplot(412)
loglog(w,Tmag)
hold on
loglog(w,ones(1,N)*Tmax)
hold off
xlabel('$w$','Interpreter','latex')
ylabel('$|| T(iw) ||$','Interpreter','latex')
subplot(413)
loglog(w,Qmag)
hold on
loglog(w,ones(1,N)*Qmax)
hold off
xlabel('$w$','Interpreter','latex')
ylabel('$|| Q(iw) ||$','Interpreter','latex')
subplot(414)
loglog(w,Rmag)
hold on
loglog(w,ones(1,N)*Rmax)
hold off
xlabel('$w$','Interpreter','latex')
ylabel('$|| R(iw) ||$','Interpreter','latex')