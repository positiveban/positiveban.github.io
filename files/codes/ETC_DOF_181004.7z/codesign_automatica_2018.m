clearvars,clc

%% System parameters
Ap=[0 1;-2 3];
Bp=[0;1];
Ep=[0;1];
Cp=[1 -4];
Dp=0;
Cpz=[1 0.5];
Cz=[Cpz,0,0];
Dz=[0.5 0 0];
Dy=[0 1 0];
Du=[0 0 1];

[np,nu]=size(Bp);
[~,nw]=size(Ep);
[ny,~]=size(Cp);
[nz,~]=size(Cz);
nxi=nw+ny+nu;
nups=ny+nu;
nc=np;

%% Declare sdp variables
% given values
% delta=[1, 1, 1, 1];
delta=[1, 1, 1, 1];
% delta=[1, 1, 0, 0];

lambdau=.1;
lambday=.1;

% vartheta_xi=1.16732^2;
% vartheta_xi=1.1832^2;
% vartheta_xi=1.975^2;
vartheta_xi=6.55^2;
% vartheta_xi=10^2;
vartheta_ups=vartheta_xi+max(lambdau^2,lambday^2);

% scalar variables
% vartheta_xi=sdpvar(1);
mu_y=sdpvar(1);
mu_u=sdpvar(1);
sigma_y=sdpvar(1);
sigma_u=sdpvar(1);

% matrix variables
X=sdpvar(np);
Y=sdpvar(np);
M=sdpvar(np,np,'full');
Z=sdpvar(np,ny);
N=sdpvar(nu,np);

%% LMI condition
lmi_con=[mu_y>=0,mu_u>=0,sigma_y>=0,sigma_u>=0,X>=0,Y>=0];

Inp=eye(np);
Iny=eye(ny);
Inu=eye(nu);
Inxi=eye(nxi);
Inz=eye(nz);

Ga1=[Y*Ap+Z*Cp,M
    Ap,Ap*X+Bp*N];
Ga2=[Y*Ep,Z,Y*Bp
    Ep,zeros(np,nu),Bp];
Ga3=[Y,Inp
    Inp,X];
Zt=[Z;zeros(np,ny)];
Yt=[Y*Bp;Bp];
Xpt=[Cp,Cp*X];
Xzt=[Cpz,Cpz*X];
Nt=[zeros(nu,np),N];

m11=Ga1+Ga1';
m21=Zt';  m22=-mu_y*Iny;
m31=Yt';  m32=zeros(nu,ny);   m33=-mu_u*Inu;
m41=Ga2'; m42=zeros(nxi,ny);  m43=zeros(nxi,nu);  m44=-vartheta_xi*Inxi;
m51=Ga1;  m52=Zt;             m53=Yt;             m54=Ga2; m55=-vartheta_ups*Ga3;
m61=Ga1;  m62=zeros(2*np,ny); m63=Yt;             m64=Ga2; m65=zeros(np*2);     m66=-lambday^(-2)*Ga3;
m71=Ga1;  m72=Zt;             m73=zeros(np*2,nu); m74=Ga2; m75=zeros(np*2);     m76=zeros(np*2);     m77=-lambdau^(-2)*Ga3;
m81=Xpt;  m82=zeros(ny,ny);   m83=zeros(ny,nu);   m84=Dy;  m85=zeros(ny,np*2);  m86=zeros(ny,np*2);  m87=zeros(ny,np*2);  m88=-sigma_y*Iny;
m91=Nt;   m92=zeros(nu,ny);   m93=zeros(nu);      m94=Du;  m95=zeros(nu,np*2);  m96=zeros(nu,np*2);  m97=zeros(nu,np*2);  m98=zeros(nu,ny); m99=-sigma_u*Inu;
m101=Xzt; m102=zeros(nz,ny);  m103=zeros(nz,nu);  m104=Dz; m105=zeros(nz,np*2); m106=zeros(nz,np*2); m107=zeros(nz,np*2); m108=zeros(nz,ny); m109=zeros(nz,nu);
m1010=-Inz;

M1=[m11 m21' m31' m41' m51' m61' m71' m81' m91' m101'
    m21 m22 m32' m42' m52' m62' m72' m82' m92' m102'
    m31 m32 m33 m43' m53' m63' m73' m83' m93' m103'
    m41 m42 m43 m44 m54' m64' m74' m84' m94' m104'
    m51 m52 m53 m54 m55 m65' m75' m85' m95' m105'
    m61 m62 m63 m64 m65 m66 m76' m86' m96' m106'
    m71 m72 m73 m74 m75 m76 m77 m87' m97' m107'
    m81 m82 m83 m84 m85 m86 m87 m88 m98' m108'
    m91 m92 m93 m94 m95 m96 m97 m98 m99 m109'
    m101 m102 m103 m104 m105 m106 m107 m108 m109 m1010];

n11=-Iny;
n21=zeros(nu,ny); n22=-Inu;
n31=-lambday^2*Xpt'; n32=-lambdau^2*Nt'; n33=-Ga3;

M2=[n11 n21' n31'
    n21 n22 n32'
    n31 n32 n33];

M3=[-Iny -Xpt;-Xpt' -Ga3];
M4=[-Inu -Nt;-Nt' -Ga3];

lmi_con=[lmi_con,M1<=0,M2<=0,M3<=0,M4<=0];

%% Optimize
cost=delta*[mu_y,mu_u,sigma_y,sigma_u]';
opt=sdpsettings('solver','mosek','verbose',0);
diagnosis=optimize(lmi_con,cost,opt)
check_val=min(checkset(lmi_con));
if diagnosis.problem
    if check_val>0
        disp('  Successfully solved.')
        disp(' ')
    else
        disp(' Infeasible problem.')
        disp([' Minimum checkset value: ',num2str(check_val)])
    end
end
%% Obtained Values
mu_u=double(mu_u);
mu_y=double(mu_y);
gammau=sqrt(mu_u)/lambdau;
gammay=sqrt(mu_y)/lambday;
Ty=1/gammay*pi/2;
Tu=1/gammau*pi/2;
sigma_u=double(sigma_u);
sigma_y=double(sigma_y);

rho_y=1/sqrt(mu_y*sigma_y)
rho_u=1/sqrt(mu_u*sigma_u)
eta_y=rho_y;
eta_u=rho_u;
X=double(X);Y=double(Y);M=double(M);N=double(N);Z=double(Z);
[Us,Ss,Vs]=svd(eye(np)-X*Y);
U=Us*sqrt(Ss);
V=(sqrt(Ss)*Vs')';

Ac=V\(M-Y*Ap*X-Y*Bp*N-Z*Cp*X)/U';
Bc=V\(Z);
Cc=(N)/U';
Dc=0;