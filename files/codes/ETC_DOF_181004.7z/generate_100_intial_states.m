clear all
clc

theta = 2*pi*rand(100,1);
rho = 50*((rand(100,1)).^(1/2))+50;
[xr,yr] = pol2cart(theta,rho);
sqrt(xr.^2+yr.^2)
figure(1)
plot(xr,yr,'.')
save('100_initial_values.mat','xr','yr')