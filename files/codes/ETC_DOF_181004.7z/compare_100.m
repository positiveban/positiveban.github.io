systemfile='systems_100_g7';
run proposed_lmi_100
run automatica_2018_100