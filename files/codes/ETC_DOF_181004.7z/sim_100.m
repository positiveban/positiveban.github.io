%% Obtained Values
mu_u=double(mu_u);
mu_y=double(mu_y);
gammau=sqrt(mu_u)/lambdau;
gammay=sqrt(mu_y)/lambday;
Ty=1/gammay*pi/2;
Tu=1/gammau*pi/2;
sigma_u=double(sigma_u);
sigma_y=double(sigma_y);

rho_y=1/sqrt(mu_y*sigma_y);
rho_u=1/sqrt(mu_u*sigma_u);

X=double(X);Y=double(Y);M=double(M);N=double(N);Z=double(Z);
[Us,Ss,Vs]=svd(eye(np)-X*Y);
U=Us*sqrt(Ss);
V=(sqrt(Ss)*Vs')';

Ac=V\(M-Y*Ap*X-Y*Bp*N-Z*Cp*X)/U';
Bc=V\(Z);
Cc=(N)/U';
Dc=0;
MM=[V Y*Bp;zeros(nu,np) eye(nu)]\[M-Y*Ap*X Z;N,zeros(nu)]/[U' zeros(np,nu);Cp*X eye(nu)];
%% simulation parameters
xx0=[10;-10;0;0];
x0=xx0(1:np);
y0=zeros(ny,1);
u0=zeros(nu,1);
tdu_n=[];tuout_n=[];tdu=[];tout=[];
tdy_n=[];tyout_n=[];tdy=[];
Tf=10;
%% c2d
sim('sim_ev')
%%
j=1;
for i=1:size(tout,1)
    if tdu(i)~=0
        tdu_n(j)=tdu(i);
        tuout_n(j)=tout(i);
        j=j+1;
    end
end
j=1;
for i=1:size(tout,1)
    if tdy(i)~=0
        tdy_n(j)=tdy(i);
        tyout_n(j)=tout(i);
        j=j+1;
    end
end
%%
events_y=size(tdy_n,2)
average_ty=mean(tdy_n)
events_u=size(tdu_n,2)
average_tu=mean(tdu_n)