clearvars -except systemfile
clc
load(systemfile)
%% System parameters
SU=zeros(1,100);
N_events_y=zeros(1,100);
average_tau_y=zeros(1,100);
N_events_u=zeros(1,100);
average_tau_u=zeros(1,100);
for k=1:100
Ap=sys(k).Ap;
Bp=sys(k).Bp;
Ep=sys(k).Ep;
Cp=sys(k).Cp;
Dp=0;
Cpz=[1 0.5];
Cz=[Cpz,0,0];
Dz=[0.5 0 0];
Dy=[0 1 0];
Du=[0 0 1];

[np,nu]=size(Bp);
[~,nw]=size(Ep);
[ny,~]=size(Cp);
[nz,~]=size(Cz);
nxi=nw+ny+nu;
nups=ny+nu;
nc=np;

%% Declare sdp variables
% given values
% delta=[1, 1, 1, 1];
delta=[1, 1, 1, 1];
% delta=[1, 1, 0, 0];

lambdau=.1;
lambday=.1;

alp1=1; 
alp2=15; % related to y
alp3=15; % related to u

% vartheta_xi=1.18732^2;
% vartheta_xi=1.975^2;
% vartheta_xi=2.975^2;
% vartheta_xi=6.548^2;
vartheta_xi=6^2;
% vartheta_xi=10^2;
vartheta_ups=vartheta_xi+max(lambdau^2,lambday^2);

% scalar variables
% vartheta_xi=sdpvar(1);
mu_y=sdpvar(1);
mu_u=sdpvar(1);
sigma_y=sdpvar(1);
sigma_u=sdpvar(1);

% matrix variables
X=sdpvar(np);
Y=sdpvar(np);
M=sdpvar(np,np,'full');
Z=sdpvar(np,ny);
N=sdpvar(nu,np);
H1=sdpvar(np*2);
H2=sdpvar(np*2);
H3=sdpvar(np*2);
%% LMI condition
lmi_con=[mu_y>=0,mu_u>=0,sigma_y>=0,sigma_u>=0,X>=0,Y>=0,H1>=0,H2>=0,H3>=0];

Inp=eye(np);
Iny=eye(ny);
Inu=eye(nu);
Inxi=eye(nxi);
Inz=eye(nz);

Ga1=[Y*Ap+Z*Cp,M
    Ap,Ap*X+Bp*N];
Ga2=[Y*Ep,Z,Y*Bp
    Ep,zeros(np,nu),Bp];
Ga3=[Y,Inp
    Inp,X];
Ga4=alp1*Ga3-H1;
Ga5=alp2*Ga3-H2;
Ga6=alp3*Ga3-H3;

Zt=[Z;zeros(np,ny)];
Yt=[Y*Bp;Bp];
Xpt=[Cp,Cp*X];
Xzt=[Cpz,Cpz*X];
Nt=[zeros(nu,np),N];

m11=Ga1+Ga1';
m21=Zt';  m22=-mu_y*Iny;
m31=Yt';  m32=zeros(nu,ny);   m33=-mu_u*Inu;
m41=Ga2'; m42=zeros(nxi,ny);  m43=zeros(nxi,nu);  m44=-vartheta_xi*Inxi;
m51=Ga1;  m52=Zt;             m53=Yt;             m54=Ga2; m55=-vartheta_ups*4/(alp1^2)*H1;
m61=Ga1;  m62=zeros(2*np,ny); m63=Yt;             m64=Ga2; m65=zeros(np*2);     m66=-lambday^(-2)*4/(alp2^2)*H2;
m71=Ga1;  m72=Zt;             m73=zeros(np*2,nu); m74=Ga2; m75=zeros(np*2);     m76=zeros(np*2);     m77=-lambdau^(-2)*4/(alp3^2)*H3;
m81=Xpt;  m82=zeros(ny,ny);   m83=zeros(ny,nu);   m84=Dy;  m85=zeros(ny,np*2);  m86=zeros(ny,np*2);  m87=zeros(ny,np*2);  m88=-sigma_y*Iny;
m91=Nt;   m92=zeros(nu,ny);   m93=zeros(nu);      m94=Du;  m95=zeros(nu,np*2);  m96=zeros(nu,np*2);  m97=zeros(nu,np*2);  m98=zeros(nu,ny); m99=-sigma_u*Inu;
m101=Xzt; m102=zeros(nz,ny);  m103=zeros(nz,nu);  m104=Dz; m105=zeros(nz,np*2); m106=zeros(nz,np*2); m107=zeros(nz,np*2); m108=zeros(nz,ny); m109=zeros(nz,nu);
m1010=-Inz;

M1=[m11 m21' m31' m41' m51' m61' m71' m81' m91' m101'
    m21 m22 m32' m42' m52' m62' m72' m82' m92' m102'
    m31 m32 m33 m43' m53' m63' m73' m83' m93' m103'
    m41 m42 m43 m44 m54' m64' m74' m84' m94' m104'
    m51 m52 m53 m54 m55 m65' m75' m85' m95' m105'
    m61 m62 m63 m64 m65 m66 m76' m86' m96' m106'
    m71 m72 m73 m74 m75 m76 m77 m87' m97' m107'
    m81 m82 m83 m84 m85 m86 m87 m88 m98' m108'
    m91 m92 m93 m94 m95 m96 m97 m98 m99 m109'
    m101 m102 m103 m104 m105 m106 m107 m108 m109 m1010];

n11=-Iny;
n21=zeros(nu,ny); n22=-Inu;
n31=-lambday^2*Xpt'; n32=-lambdau^2*Nt'; n33=-Ga4;

M2=[n11 n21' n31'
    n21 n22 n32'
    n31 n32 n33];

M3=[-Iny -Xpt;-Xpt' -Ga5];
M4=[-Inu -Nt;-Nt' -Ga6];

lmi_con=[lmi_con,M1<=0,M2<=0,M3<=0,M4<=0];

%% Optimize
cost=delta*[mu_y,mu_u,sigma_y,sigma_u]';
opt=sdpsettings('verbose',0);
diagnosis=optimize(lmi_con,cost,opt)
check_val=min(checkset(lmi_con));
if diagnosis.problem
    if check_val>0
        disp('  Successfully solved.')
        disp(' ')
        SU(k)=1;
        run sim_100
        N_events_y(k)=events_y;
        average_tau_y(k)=average_ty;
        N_events_u(k)=events_u;
        average_tau_u(k)=average_tu;
    else
        disp(' Infeasible problem.')
        disp([' Minimum checkset value: ',num2str(check_val)])
    end
else
    SU(k)=1;
    run sim_100
    N_events_y(k)=events_y;
    average_tau_y(k)=average_ty;
    N_events_u(k)=events_u;
    average_tau_u(k)=average_tu;
end
end
% run plot_time_domain
figure(101), run plot_100_results