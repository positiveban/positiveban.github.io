clearvars,clc

%% System parameters
Ap=[0 1;-2 3];
Bp=[0;1];
Ep=[0;1];
Cp=[1 -4];
Dp=0;
Cpz=[1 0.5];
Cz=[Cpz,0,0];
Dz=[0.5 0 0];
Dy=[0 1 0];
Du=[0 0 1];

[np,nu]=size(Bp);
[~,nw]=size(Ep);
[ny,~]=size(Cp);
[nz,~]=size(Cz);
nxi=nw+ny+nu;
nups=ny+nu;
nc=np;

% Ac=[-11.1782200876889,-0.732280748987106;2.91126416345769,-0.310397901657385];
% Bc=[-97.7340057714193;16.3790123625893];
% Cc=[-0.123317971303254,-0.00842125245995130];
Ac=[0 1;0 -5];
Bc=[0;1];
Cc=[1 -4];
% Ac=[-2 1;-13 -3];
% Bc=[-2;-5];
% Cc=[5 2];
% Dc=0;
%% Declare sdp variables
% given values
% delta=[1, 1, 1, 1];
delta=[1, 1, 1, 1];
% delta=[1, 1, 0, 0];

lambdau=.001;
lambday=.0001;

% vartheta_xi=1.16732^2;
% vartheta_xi=1.1832^2;
% vartheta_xi=6.23^2;
vartheta_xi=30.55^2;
vartheta_ups=vartheta_xi+max(lambdau^2,lambday^2);

% scalar variables
mu_y=sdpvar(1);
mu_u=sdpvar(1);
sigma_y=sdpvar(1);
sigma_u=sdpvar(1);

% matrix variables
P=sdpvar(2*np);
%% LMI condition
lmi_con=[mu_y>=0,mu_u>=0,sigma_y>=0,sigma_u>=0,P>=0];
Cy=[Cp,zeros(ny,np)];
Cu=[zeros(nu,np),Cc];
A1=[Ap,Bp*Cc;Bc*Cp,Ac];
B1=[zeros(np,ny);Bc];
M1=[Bp;zeros(np,nu)];
E1=[Ep,zeros(np,nw),Bp;zeros(np,nw),Bc,zeros(np,nu)];
A2=-Cy*A1;
M2=-Cy*M1;
E2=-Cy*E1;
F2=[-eye(ny),zeros(ny,nu)];
A3=-Cu*A1;
B3=-Cu*B1;
E3=-Cu*E1;
F3=[zeros(nu,ny),-eye(nu)];

m11=A1'*P+P*A1+Cz'*Cz+lambday^2*(A2'*A2)+lambdau^2*(A3'*A3);
m21=B1'*P+lambdau^2*B3'*A3;
m22=lambdau^2*(B3'*B3)-mu_y*eye(ny);
m31=M1'*P+lambday^2*M2'*A2;
m32=zeros(nu,ny);
m33=lambday^2*(M2'*M2)-mu_u*eye(nu);
m41=E1'*P+Dz'*Cz+lambday^2*E2'*A2+lambdau*E3'*A3;
m42=lambdau^2*E3'*B3;
m43=lambday^2*E2'*M2;
m44=Dz'*Dz+lambday^2*(E2'*E2)+lambdau^2*(E3'*E3)-vartheta_xi*eye(nxi);
m51=lambday^2*F2'*A2+lambdau^2*F3'*A3;
m52=lambdau^2*F3'*B3;
m53=lambday^2*F2'*M2;
m54=lambday^2*F2'*E2+lambdau^2*F3'*E3;
m55=lambday^2*(F2'*F2)+lambdau^2*(F3'*F3)-vartheta_xi*eye(nups);
m61=Cy;
m62=zeros(ny);
m63=zeros(ny,nu);
m64=Dy;
m65=zeros(ny,nups);
m66=-sigma_y*eye(ny);
m71=Cu;
m72=zeros(nu,ny);
m73=zeros(nu);
m74=Du;
m75=zeros(nu,nups);
m76=zeros(nu,ny);
m77=-sigma_u*eye(nu);

M=[m11 m21' m31' m41' m51' m61' m71'
   m21 m22 m32' m42' m52' m62' m72'
   m31 m32 m33 m43' m53' m63' m73'
   m41 m42 m43 m44 m54' m64' m74'
   m51 m52 m53 m54 m55 m65' m75'
   m61 m62 m63 m64 m65 m66 m76'
   m71 m72 m73 m74 m75 m76 m77];

lmi_con=[lmi_con,M<=0];

%% Optimize
cost=delta*[mu_y,mu_u,sigma_y,sigma_u]';
opt=sdpsettings('solver','mosek','verbose',0);
diagnosis=optimize(lmi_con,cost,opt)
check_val=min(checkset(lmi_con));
if diagnosis.problem
    if check_val>0
        disp('  Successfully solved.')
        disp(' ')
    else
        disp(' Infeasible problem.')
        disp([' Minimum checkset value: ',num2str(check_val)])
    end
end

%% Obtained Values
mu_u=double(mu_u);
mu_y=double(mu_y);
gammau=sqrt(mu_u)/lambdau;
gammay=sqrt(mu_y)/lambday;
Ty=1/gammay*pi/2;
Tu=1/gammau*pi/2;
sigma_u=double(sigma_u);
sigma_y=double(sigma_y);

rho_y=1/sqrt(mu_y*sigma_y)
rho_u=1/sqrt(mu_u*sigma_u)