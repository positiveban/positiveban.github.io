%% simulation parameters
codesign_automatica_2018;
load('100_initial_values')
xx0=zeros(4,1);
for qwe=8:8
% xx0=[3;-2;0;0];
xx0(1)=xr(qwe);xx0(2)=yr(qwe);
x0=xx0(1:np);
y0=zeros(ny,1);
u0=zeros(nu,1);
Tf=5;
%% c2d
sim('sim_ev_181004_2')
%%
j=1;
for i=1:size(tout,1)
    if trig_u(i)~=0
        tdu_n(j)=tau_u(i-1);
        tuout_n(j)=tout(i-1);
        j=j+1;
    end
end
j=1;
for i=1:size(tout,1)
    if trig_y(i)~=0
        tdy_n(j)=tau_y(i-1);
        tyout_n(j)=tout(i-1);
        j=j+1;
    end
end
%% Plotting
% %{
figure(2)
subplot(221)
plot(tout,y);
hold on
stairs(tout,yh);
plot(tout,zeros(size(tout,1),1),'k--')
hold off
legend({'$y$','$\hat{y}$'},'Interpreter','latex','FontSize',12);
% ylim([-600 100])
xlim([0 5])
xlabel('Time (s)')

subplot(223)
stem(tyout_n,tdy_n);
hold on
plot(tout,Ty*ones(size(tout,1),1),'--')
hold off
xlabel('Time (s)')
ylabel({'Release intervals of $y$ (s)'},'Interpreter','latex')
ylim([0 .015])
xlim([0 5])

subplot(222)
plot(tout,u);
hold on
stairs(tout,uh);
plot(tout,zeros(size(tout,1),1),'k--')
hold off
legend({'$u$','$\hat{u}$'},'Interpreter','latex','FontSize',12);
% ylim([-600 100])
xlim([0 5])
xlabel('Time (s)')
subplot(224)
stem(tuout_n,tdu_n);
hold on
plot(tout,Tu*ones(size(tout,1),1),'--')
hold off
xlabel('Time (s)')
ylabel({'Release intervals of $u$ (s)'},'Interpreter','latex')
ylim([0 .015])
xlim([0 5])

%}
events_y(qwe)=size(tdy_n,2);
average_ty(qwe)=mean(tdy_n);
events_u(qwe)=size(tdu_n,2);
average_tu(qwe)=mean(tdu_n);
disp([num2str(qwe),'-th simulation is running...'])
end
average_events_y=mean(events_y)
average_tau_y=mean(average_ty)
average_events_u=mean(events_u)
average_tau_u=mean(average_tu)