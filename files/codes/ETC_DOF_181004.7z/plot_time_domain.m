figure(2)
subplot(413)
plot(tout,y);
hold on
stairs(tout,yh);
plot(tout,zeros(size(tout,1),1),'k--')
hold off
legend('y','yh');
ylim([-25 25])
% xlim([0 5])

subplot(414)
stem(tyout_n,tdy_n);
xlabel('Time (s)')
ylabel('Release time interval')
ylim([0 .8])
% xlim([0 5])

subplot(411)
plot(tout,u);
hold on
stairs(tout,uh);
plot(tout,zeros(size(tout,1),1),'k--')
hold off
legend('u','uh');
ylim([-25 25])
% xlim([0 5])
subplot(412)
stem(tuout_n,tdu_n);
% xlabel('Time (s)')
ylabel('Release time interval')
ylim([0 .8])
% xlim([0 5])
events_y=size(tdy_n,2)
average_ty=mean(tdy_n)
events_u=size(tdu_n,2)
average_tu=mean(tdu_n)