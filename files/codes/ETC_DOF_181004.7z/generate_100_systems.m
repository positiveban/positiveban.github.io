clear all
clc
k=1;
while k<101
    Ap=(randi([-10,10],2,2));
    Bp=(randi([-10,10],2,1));
    Ep=(randi([-10,10],2,1));
    Cp=randi([-10,10],1,2);
    
    if (rank(ctrb(Ap,Bp))==2)&&(norm(Ep)~=0)&&(rank(obsv(Ap,Cp)))&&(max(eig(Ap))>0)
        run automatica_2018_1
        if flag
            sys(k).Ap=Ap;
            sys(k).Bp=Bp;
            sys(k).Ep=Ep;
            sys(k).Cp=Cp;
            k=k+1
        end
    end
end
