%-------------------------------------------------------------------%
%  Improved co-design of event-triggered dynamic output feedback    %
%  controllers for linear systems, Jan. 2020, Automatica            %
%                                                                   %
%                                  Jaepil Ban, POSTECH              %
%                                  banjp117(at)postech.ac.kr        %
%-------------------------------------------------------------------%

clearvars,clc

%% System parameters
Ap=[0 1;-2 -3];
Bp=[0;1];
Ep=[0;1];
Cp=[1 0];
Dp=0;
Cpz=[1 0.5];
Cz=[Cpz,0,0];
Dz=[0.5 0 0];
Dy=[0 1 0];
Du=[0 0 1];

[np,nu]=size(Bp);
[~,nw]=size(Ep);
[ny,~]=size(Cp);
[nz,~]=size(Cz);
nxi=nw+ny+nu;
nups=ny+nu;
nc=np;

%% Declare sdp variables
% given values
delta=[1, 1, 1, 1];

lambdau=.1;
lambday=.1;

a1=logspace(-4,1,10)';
a2=(1:1:20)';
a3=(1:1:30)';
costs=zeros(size(a2,1),size(a3,1),size(a1,1));
costs2=zeros(size(a2,1),size(a3,1),size(a1,1));
% 1: y-axis
% 2: x-axis
% 3: z-axis

disp('  Simulation is Running...')
for ii=1:size(a1,1)
    for jj=1:size(a2,1)
        for kk=1:size(a3,1)

alp1=a1(ii); 
alp2=a2(jj); % related to y
alp3=a3(kk); % related to u

vartheta_xi=1.17439^2;
vartheta_ups=vartheta_xi+max(lambdau^2,lambday^2);

% scalar variables
mu_y=sdpvar(1);
mu_u=sdpvar(1);
sigma_y=sdpvar(1);
sigma_u=sdpvar(1);

% matrix variables
X=sdpvar(np);
Y=sdpvar(np);
M=sdpvar(np,np,'full');
Z=sdpvar(np,ny);
N=sdpvar(nu,np);
H1=sdpvar(np*2);
H2=sdpvar(np*2);
H3=sdpvar(np*2);
%% LMI condition
lmi_con=[mu_y>=0,mu_u>=0,sigma_y>=0,sigma_u>=0,X>=0,Y>=0,H1>=0,H2>=0,H3>=0];

Inp=eye(np);
Iny=eye(ny);
Inu=eye(nu);
Inxi=eye(nxi);
Inz=eye(nz);

Ga1=[Y*Ap+Z*Cp,M
    Ap,Ap*X+Bp*N];
Ga2=[Y*Ep,Z,Y*Bp
    Ep,zeros(np,nu),Bp];
Ga3=[Y,Inp
    Inp,X];
Ga4=2*alp1*Ga3-H1;
Ga5=2*alp2*Ga3-H2;
Ga6=2*alp3*Ga3-H3;

Zt=[Z;zeros(np,ny)];
Yt=[Y*Bp;Bp];
Xpt=[Cp,Cp*X];
Xzt=[Cpz,Cpz*X];
Nt=[zeros(nu,np),N];

m11=Ga1+Ga1';
m21=Zt';  m22=-mu_y*Iny;
m31=Yt';  m32=zeros(nu,ny);   m33=-mu_u*Inu;
m41=Ga2'; m42=zeros(nxi,ny);  m43=zeros(nxi,nu);  m44=-vartheta_xi*Inxi;
m51=Ga1;  m52=Zt;             m53=Yt;             m54=Ga2; m55=-vartheta_ups/(alp1^2)*H1;
m61=Ga1;  m62=zeros(2*np,ny); m63=Yt;             m64=Ga2; m65=zeros(np*2);     m66=-lambday^(-2)/(alp2^2)*H2;
m71=Ga1;  m72=Zt;             m73=zeros(np*2,nu); m74=Ga2; m75=zeros(np*2);     m76=zeros(np*2);     m77=-lambdau^(-2)/(alp3^2)*H3;
m81=Xpt;  m82=zeros(ny,ny);   m83=zeros(ny,nu);   m84=Dy;  m85=zeros(ny,np*2);  m86=zeros(ny,np*2);  m87=zeros(ny,np*2);  m88=-sigma_y*Iny;
m91=Nt;   m92=zeros(nu,ny);   m93=zeros(nu);      m94=Du;  m95=zeros(nu,np*2);  m96=zeros(nu,np*2);  m97=zeros(nu,np*2);  m98=zeros(nu,ny); m99=-sigma_u*Inu;
m101=Xzt; m102=zeros(nz,ny);  m103=zeros(nz,nu);  m104=Dz; m105=zeros(nz,np*2); m106=zeros(nz,np*2); m107=zeros(nz,np*2); m108=zeros(nz,ny); m109=zeros(nz,nu);
m1010=-Inz;

M1=[m11 m21' m31' m41' m51' m61' m71' m81' m91' m101'
    m21 m22 m32' m42' m52' m62' m72' m82' m92' m102'
    m31 m32 m33 m43' m53' m63' m73' m83' m93' m103'
    m41 m42 m43 m44 m54' m64' m74' m84' m94' m104'
    m51 m52 m53 m54 m55 m65' m75' m85' m95' m105'
    m61 m62 m63 m64 m65 m66 m76' m86' m96' m106'
    m71 m72 m73 m74 m75 m76 m77 m87' m97' m107'
    m81 m82 m83 m84 m85 m86 m87 m88 m98' m108'
    m91 m92 m93 m94 m95 m96 m97 m98 m99 m109'
    m101 m102 m103 m104 m105 m106 m107 m108 m109 m1010];

n11=-Iny;
n21=zeros(nu,ny); n22=-Inu;
n31=-lambday^2*Xpt'; n32=-lambdau^2*Nt'; n33=-Ga4;

M2=[n11 n21' n31'
    n21 n22 n32'
    n31 n32 n33];

M3=[-Iny -Xpt;-Xpt' -Ga5];
M4=[-Inu -Nt;-Nt' -Ga6];

lmi_con=[lmi_con,M1<=0,M2<=0,M3<=0,M4<=0];

%% Optimize
cost=delta*[mu_y,mu_u,sigma_y,sigma_u]';
opt=sdpsettings('verbose',0,'solver','mosek');
diagnosis=optimize(lmi_con,cost,opt);
check_val=min(checkset(lmi_con));

%% Obtained Values
mu_u=double(mu_u);
mu_y=double(mu_y);
gammau=sqrt(mu_u)/lambdau;
gammay=sqrt(mu_y)/lambday;
Ty=1/gammay*pi/2;
Tu=1/gammau*pi/2;
sigma_u=double(sigma_u);
sigma_y=double(sigma_y);

rho_y=1/sqrt(mu_y*sigma_y);
rho_u=1/sqrt(mu_u*sigma_u);
yalmip('clear')
disp(['  ',num2str((kk+(jj-1)*size(a3,1)+(ii-1)*size(a2,1)*size(a3,1))/(size(a3,1)*size(a2,1)*size(a1,1))*100,'%.2f'),'% has been processed'])

if diagnosis.problem
    if check_val>0
        costs(jj,kk,ii)=rho_y;
        costs2(jj,kk,ii)=rho_u;
    else
        costs(jj,kk,ii)=NaN;
        costs2(jj,kk,ii)=NaN;
    end
else
    costs(jj,kk,ii)=rho_y;
    costs2(jj,kk,ii)=rho_u;
end

        end
    end    
end
%%
a1_slice=logspace(-3,1,5);
figure(1)
A=axes;
rng3=a3;
rng2=a2;

slice(a3,a2,a1,costs+costs2,10,[],a1_slice)

xlabel('\alpha_3','FontSize',12)
ylabel('\alpha_2','FontSize',12)
zlabel('\alpha_1','FontSize',12)
view(30,20)
colormap(jet(128));
c=colorbar('vertical');
grid on
ylabel(c,'$\eta_y+\eta_u$','FontSize',14,'interpreter','latex')
zlim([1E-4 0.99E-0])
set(A,'ZScale','log')
shading flat;