clc
clear all

Nunits = 3;
Horizon = 48;

Pmax = [100;50;25];
Pmin = [20;30;1];

minup   = [6;10;1];
mindown = [3;6;3];

rampup = [7;5;15];
rampdown = [10;15;30];

Q = diag([.04 .01 .02]);
C = [10 20 10];

Pforecast = 100 + 50*sin((1:Horizon)*2*pi/24);

onoff = binvar(Nunits,Horizon,'full');
P     = sdpvar(Nunits,Horizon,'full');

Constraints = [];

% Generation limit constraints
for k = 1:Horizon
    Constraints = [Constraints, onoff(:,k).*Pmin <= P(:,k) <= onoff(:,k).*Pmax];
end

% Power balance constraints
for k = 1:Horizon
    Constraints = [Constraints, sum(P(:,k)) >= Pforecast(k)];
end


% ramp up constraints
for k = 2:Horizon
    for unit = 1:Nunits
        % Constraints will be redundant unless indicator = 1
        Constraints = [Constraints, P(unit,k)-P(unit,k-1)<=rampup(unit)*onoff(unit,k-1)];
    end
end
% ramp down constraints
for k = 2:Horizon
    for unit = 1:Nunits
        % Constraints will be redundant unless indicator = 1
        Constraints = [Constraints, P(unit,k-1) - P(unit,k)<=rampdown(unit)*onoff(unit,k)];
    end
end

% minimum up time constraints
for k = 2:Horizon
    for unit = 1:Nunits
        % indicator will be 1 only when switched on
        indicator = onoff(unit,k)-onoff(unit,k-1);
        range = k:min(Horizon,k+minup(unit)-1);
        % Constraints will be redundant unless indicator = 1
        Constraints = [Constraints, onoff(unit,range) >= indicator];
    end
end

% minimum down time constraints
for k = 2:Horizon
    for unit = 1:Nunits
        % indicator will be 1 only when switched off
        indicator = onoff(unit,k-1)-onoff(unit,k);
        range = k:min(Horizon,k+mindown(unit)-1);
        % Constraints will be redundant unless indicator = 1
        Constraints = [Constraints, onoff(unit,range) <= 1-indicator];
    end
end


% Cost function
Objective = 0;
for k = 1:Horizon
  Objective = Objective + P(:,k)'*Q*P(:,k) + C*P(:,k);
end

% Solve MILP
optimize(Constraints,Objective)

figure(7)
subplot(211)
stairs(value(P)');
legend('Unit 1','Unit 2','Unit 3');
ylabel('P (MW)')
xlabel('Time (h)')
ylabel('Generation (MW)')
ylim([0 120])
subplot(212)
stairs(sum(value(P)',2))
hold on
stairs(Pforecast,'--')
hold off
xlabel('Time (h)')
ylabel('Load (MW)')
legend('Total Gen','Load')