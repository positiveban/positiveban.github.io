clc
clear all
%% System Description
global A B C D E F
load('..\rand_system')
% A{1}=[0.8133 0.4413;0.6953 0.4707];
% B{1}=[0.1260;0.5361];
% C{1}=[0.0223 0.1483];
% D{1}=0.8632;
% E{1}=[0.7573;0.8858];
% F{1}=0.2857;
alpha{1}=0.1*(1/sqrt(2));

% A{2}=[0.8814 0.1462;0.6451 0.2124];
% B{2}=[0.8399;0.2399];
% C{2}=[0.4757 0.8780];
% D{2}=0.9961;
% E{2}=[0.3687;0.7160];
% F{2}=0.7895;
alpha{2}=0.2;

mu=0.05;
% k=8.5393;

sigma=.0;
sigma2=sigma*sigma;
d=1;
mm=10;

[m,n]=size(C{1});
[tmp,nu]=size(B{1});
[tmp,nd]=size(E{1});

cond=1>=0;

R=eye(n);

x=[3.5156    0.4829   -0.2854    1.5681   -1.8898    0.9826    2.6075]; % optimal values

%  
% beta=x(1);
% b1=x(2);
% b2=x(3);
% b3=x(4);
% b4=x(5);
% b5=x(6);
% %  
beta=3.5;
b1=1;
b2=1;
b3=1;
b4=1;
b5=1;

k=10.9;
Inu=eye(n,nu);
Idu=eye(nd,nu);
Imu=eye(m,nu);
%% Variable description
for i=1:2
    P{i}=sdpvar(n);
    Y{i}=sdpvar(nu,nu,'full');
    Kb{i}=sdpvar(nu,n,'full');
    for j=1:2
        U{i,j}=sdpvar(n,n,'full');
        V{i,j}=sdpvar(n,n,'full');
%         V{i,j}=zeros(n);
        W{i,j}=sdpvar(n,n,'full');
%         W{i,j}=zeros(n);
        X{i,j}=sdpvar(nd,n,'full');
    end
end
eta=sdpvar(1,1);
gamma2=sdpvar(1,1);
% k=sdpvar(1,1);
ebs2=sdpvar(1,1);

%% LMI constraint
for i=1:2
    for j=1:2

M11=-(1+mu)*P{i} + U{i,j}*A{i} + A{i}'*U{i,j}' + b1*Inu*Kb{i} + (b1*Inu*Kb{i})'+(eta*alpha{i}*alpha{i}+1)*eye(n);
M12=C{i} + b2*Imu*Kb{i};
M13=V{i,j}*A{i} - U{i,j}' + b3*Inu*Kb{i};
M14=W{i,j}*A{i} + U{i,j}' + b4*Inu*Kb{i};
M15=X{i,j}*A{i} + E{i}'*U{i,j}' + F{i}'*C{i} + b5*Idu*Kb{i};

M22=-eye(m);
M23=zeros(n,m);
M24=zeros(n,m);
M25=zeros(nd,m);

M33=(1+mu)*P{j}-V{i,j}-V{i,j}';
% M33=P{i}-V{i,j}-V{i,j}';
M34=-W{i,j}+V{i,j}';
M35=-X{i,j}+E{i}'*V{i,j}';

M44=-eta*eye(n) + W{i,j} + W{i,j}';
M45=X{i,j} + E{i}'*W{i,j}';

% M55=-gamma2/((1+mu)^(mm))*eye(nd)+X{i,j}*E{i}+E{i}'*X{i,j}'+F{i}'*F{i};
M55=-gamma2*eye(nd)+X{i,j}*E{i}+E{i}'*X{i,j}'+F{i}'*F{i};
M16=beta*[(U{i,j}*B{i}-b1*Inu*Y{i})' (D{i}-b2*Imu*Y{i})' (V{i,j}*B{i}-b3*Inu*Y{i})' (W{i,j}*B{i}-b4*Inu*Y{i})' (X{i,j}*B{i}+F{i}'*D{i}-b5*Idu*Y{i})']+[Kb{i} zeros(nu,m) zeros(nu,n) zeros(nu,n) zeros(nu,nd)];
M66=-beta*Y{i}-beta*Y{i}';

Mb=[M11 M12' M13' M14' M15'
   M12 M22 M23' M24' M25'
   M13 M23 M33 M34' M35'
   M14 M24 M34 M44 M45'
   M15 M25 M35 M45 M55];

M=[Mb M16';M16 M66];

cond=[cond,M+0.0001*eye(9)<=0];
    end
end
for i=1:2
    cond1=R-P{i}+0.0001*eye(n)<=0;
    cond2=P{i}-k*R+0.0001*eye(n)<=0;
    cond=[cond,cond1,cond2];
end
cond3=gamma2*d*d-ebs2*((1+mu)^-mm)/k;
% cond3=((1+mu)^mm)*k*sigma2 + gamma2*d*d-ebs2;
cond=[cond,cond3<=0,P{1}>=0,P{2}>=0,k>=0,gamma2>=0];
% cond=[cond,P{1}>=0,P{2}>=0];

%% Solve LMI
% diagnosis=optimize(cond)
diagnosis=optimize(cond,ebs2+gamma2)
a=checkset(cond)'
[tmp sa]=size(a);
for i=1:sa
    if a(i)<=0
        a(i)
    end
end
ebs=sqrt(double(ebs2))
gamma=sqrt(double(gamma2))
ebs+gamma
eta=double(eta)
for i=1:2
  K{i}=double(Y{i})^-1*double(Kb{i});
end
K{1}
K{2}

%%
clear x
tspan=[0 20];
tspan(2)=tspan(2)-1;
t=tspan(1):1:tspan(2)+1;
x(:,1)=[1 -2];

% d(0)=
sel=1;
for i=tspan(1)+1:tspan(2)+1
    w(i)=0.1*sin(0.5*i);
%     w(i)=0;
    x(:,i+1)=(A{sel}+B{sel}*K{sel})*x(:,i)+E{sel}*w(i)+[0;0.1*(x(1,i)+sin(x(2,i)))/sqrt(2)];
    if sel==1
        sel=2;
    else
        x(:,i+1)=(A{sel}+B{sel}*K{sel})*x(:,i)+E{sel}*w(i)+[0.2*sin(x(1,i));0];
        sel=1;
    end
end
figure(1)
subplot(4,1,4)
plot(t,x)
str=sprintf('2016 my g:%.2f, e:%.2f',gamma,ebs);
title(str);