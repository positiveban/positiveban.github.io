clc
clear
%% System Description
A{1}=[0.8133 0.4413;0.6953 0.4707];
B{1}=[0.1260;0.5361];
C{1}=[0.0223 0.1483];
D{1}=0.8632;
E{1}=[0.7573;0.8858];
F{1}=0.2857;
alpha{1}=0.1*(1/sqrt(2));
% 
% A{2}=[0.8814 0.1462;0.6451 0.2124];
% B{2}=[0.8399;0.2399];
% C{2}=[0.4757 0.8780];
% D{2}=0.9961;
% E{2}=[0.3687;0.7160];
% F{2}=0.7895;
% alpha{2}=0.2;

A=[0.8133 0.4413;0.6953 0.4707];
B=[0.1260;0.5361];
C=[0.0223 0.1483];
D=0.8632;
E=[0.7573;0.8858];
F=0.2857;
alpha=0.1*(1/sqrt(2));


mu=0.34;

sigma=2;
sigma2=sigma*sigma;
d=1;
mm=10;

[m,n]=size(C);
[tmp,nu]=size(B);
[tmp,nd]=size(E);

cond=1>=0;

R=eye(n);
b1=1;
b2=1;
b3=1;
b4=1;
b5=1;
zeta=9;
beta=1;

Inu=eye(n,nu);
Idu=eye(nd,nu);
Imu=eye(m,nu);
%% Variable Description
P=sdpvar(n);
Y=sdpvar(nu,nu,'full');
Kb=sdpvar(nu,n,'full');
U=sdpvar(n,n,'full');
V=sdpvar(n,n,'full');
W=sdpvar(n,n,'full');

%% LMI constraint
M11=-(1+mu)*P+U*A+A'*U'+b1*Inu*Kb+(b1*Inu*Kb)'+zeta*alpha*alpha*eye(n);
M12=C   + b2*Imu*Kb; 
M13=V*A + b3*Inu*Kb-U';
M14=W*A + b4*Inu*Kb+U';

M22=-eye(m);
M23=zeros(n,m);
M24=zeros(n,m);

M33=P-V-V';
M34=-W+V';


M44=-zeta*eye(n) + W+W';

M15=beta*[(U*B-b1*Inu*Y)' (D-b2*Imu*Y)' (V*B-b3*Inu*Y)' (W*B-b4*Inu*Y)'] + [Kb zeros(nu,m) zeros(nu,n) zeros(nu,n)];
M55=-beta*Y-beta*Y';

Mb=[M11 M12' M13' M14'
    M12 M22 M23' M24'
    M13 M23 M33 M34'
    M14 M24 M34 M44];
M=[Mb M15'
   M15 M55];

%% solving LMI
cond=[P>=0 M<=0];

optimize(cond)
a=checkset(cond)

