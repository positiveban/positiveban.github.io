function dxdt=myode(z)
global A B C D E F


dxdt=
end