clear all
clc
i=1;
j=1;

c=0;

for a=-10:1:10;
for b=-10:1:10;

    
    A=[-4 a b
        a -2 c
        b c -3];

f=eig(A);

e(i,j,1)=f(1);
e(i,j,2)=f(2);
e(i,j,3)=f(3);
j=j+1;
end
i=i+1;
j=1;
end
a=[-10:1:10];
b=[-10:1:10];
figure(2)
subplot(311)
mesh(b,a,e(:,:,1))
title('EV1');

subplot(312)
mesh(b,a,e(:,:,2))
title('EV2');
subplot(313)
mesh(b,a,e(:,:,3))
title('EV3');