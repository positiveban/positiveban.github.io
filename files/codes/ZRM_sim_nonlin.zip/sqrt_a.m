function y=sqrt_a(u)

y=real(sqrt(abs(u)));

end