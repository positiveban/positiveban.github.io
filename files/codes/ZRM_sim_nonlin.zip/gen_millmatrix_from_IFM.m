clear all
% initial input
u0=zeros(1,9);
% u0(8)=79;
% u0(9)=79;

% input change
u=eye(9);
Gm_IFM=zeros(38,9);
for i=1:9
    Gm_IFM(:,i)=IFM_SHAPEs_POSCO(u(i,:)+u0)-IFM_SHAPEs_POSCO(u0);
end
load('GM1257.mat');range=3:36;range2=34;r3=2;
% load('GM1055.mat');range=7:32;range2=26;r3=6;

xn=[0.192000000000000,0.218000000000000,0.244000000000000,0.270000000000000,0.296000000000000,0.322000000000000,0.348000000000000,0.374000000000000,0.400000000000000,0.426000000000000,0.452000000000000,0.478000000000000,0.504000000000000,0.556000000000000,0.608000000000000,0.660000000000000,0.712000000000000,0.764000000000000,0.816000000000000,0.868000000000000,0.920000000000000,0.972000000000000,1.02400000000000,1.07600000000000,1.12800000000000,1.18000000000000,1.23200000000000,1.25800000000000,1.28400000000000,1.31000000000000,1.33600000000000,1.36200000000000,1.38800000000000,1.41400000000000,1.44000000000000,1.46600000000000,1.49200000000000,1.51800000000000];
IFM_NMSE=zeros(1,9);
IFM_NMSEp=zeros(1,9);
figure(3)
for i=1:9
    subplot(5,2,i)
    plot(xn(range),Gm(range,i))
    hold on
    P=polyfit(((1:range2)-mean(1:range2))/range2,Gm(range,i)',8);
    PolyGm(:,i)=[zeros(1,r3),polyval(P,((1:range2)-mean(1:range2))/range2),zeros(1,r3)];
    plot(xn(range),PolyGm(range,i))
    plot(xn(range),Gm_IFM(range,i))
    hold off
    axis([0.2 1.5 -4 4])
    xlabel('Shapemeter Zone')
    ylabel('I-Unit')
    IFM_NMSE(i)=20*log10(norm(Gm_IFM(:,i)-PolyGm(:,i))/norm(PolyGm(:,i)));
    IFM_NMSEp(i)=20*log10(norm(Gm_IFM(:,i)-Gm(:,i))/norm(Gm(:,i)));
end
legend('Gm','PolyGm','IFM Model','Location','Best')
figure(1)
bar(IFM_NMSE)
xlabel('# of Actuators')
ylabel('NMSE (dB)')
figure(2)
bar(IFM_NMSEp)
xlabel('# of Actuators')
ylabel('NMSE (dB)')
avr_NMSE=mean(IFM_NMSE);
avr_NMSEp=mean(IFM_NMSEp);
