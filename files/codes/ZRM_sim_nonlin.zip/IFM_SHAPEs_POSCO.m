function shape_I_unit = IFM_SHAPEs_POSCO(u)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    ZRM simulator by JP of POSTECH         %
%     (Influence function method)           %
%         Modified roll length              %
%                       2017.08.21          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ma=-u(1:7); % ASU inputs

UpIMR_setpoint=88.5;
LoIMR_setpoint=88.5;

% UpIMR_setpoint=128.5;
% LoIMR_setpoint=128.5;

% When (u + setpoint) > 67, IMRs' affect to strip shape
LIT=(u(8)+UpIMR_setpoint)*0.001; % IMR inpus
LIB=(u(9)+LoIMR_setpoint)*0.001;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         Parameter Settings                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parameter settings of IFM simulator
ms=0;
mpl=0; %(>0)
mpr=0; %(>0)

% strip parameters
h_mean=0.310E-3; % mean input gauge
H_mean=0.220E-3; % mean output gauge
Es=203E9; %young's modulus of strip

width = 1.257; % strip width

% Actuator parameters
N=7; % number of As-U-rack

% rotation of screwdown, side eccentric discs (rad)
phis=0*pi/180;
phip=0*pi/180;

% eccentricities (m)
ea=1.25E-3;
es=8.89E-3;
ep=4.44E-3;

% roll paramters
v=0.3; % poisson's ratio
E=203E9; % young's modulus of rolls

% roll diameters (m)
Db=0.405;
D2i=0.2305;
D2d=0.2305;
D1=0.14075;
Dw=0.075;


% roll radius
Rb=Db/2;
R2i=D2i/2;
% R2d=D2d/2;
% R1=D1/2;
Rw=Dw/2;

bearingratio=1;
% backing bearing
Lb=0.171*bearingratio; % Length of barrel of each bearing
Pb=0.221*bearingratio; % pitch of bearings (distance between saddles)
Lt2=1.55; % Length of 2IR (Lt2 <= Lt1)
Lt1=1.677; % Length of 1IR (Lt1 <= Lt)
Lt=1.71; % Length of work roll barrels
% Ls=1.257;
Ls=Lt;

Lr=.052; % length of each shapemeter's roll
Lsr=1.326; % Length of shapemeter's roll

Ltap=0.584; % Length tapered
% D1t=D1*0.9;
D1t=1.15E-4;

% nominal separations (m)
BC_=0.419;
AD_=1.094;
AB_=0.423;

l1=BC_/2-ea-es; 
l2=AD_/2-ep; 
l4=AB_; 
l3=sqrt_a(l4^2-(l2-l1)^2);

ra=1.55E-5*[1.69,0.78,1.05,1.55,.77,0.95,1.59]; % as-u-roll rack to rotation ratio (rad/m)
rs=0.01; % screw down ratio (rad/m)
rp=0.01; % side eccentricity ratio (rad/m)

% simulation parameters
M2=400; % number of segments of 2IR (even number)
M1=400; % number of segments of 1IR (even number)
Mw=400; % number of segments of work roll (even number)
J1F=200; % number of concentrated force on 1IR from 2IR (sub-multiple of M2)
JWF=200; % number of concentrated force on 1IR from 2IR (sub-multiple of M1)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           Mill Geometry                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Mill_geometry;
% parameters calculation
thetaA=ra.*ma;
thetaS=rs*ms;
thetaPL=rp*mpl;
thetaPR=rp*mpr;
thetaA_=sum(thetaA)/N;

%obtaining Lbc
alpha=atan(l3/(l2-l1));
Lx0y0=sqrt_a(l4^2+ea^2-2*l4*ea*cos(alpha));
beta=acos_c((Lx0y0^2+ea^2-l4^2)/(2*Lx0y0*ea))-phis;
Lx0b0=sqrt_a(Lx0y0^2+es^2+2*Lx0y0*es*cos(beta));
gamma=asin(es*sin(beta)/Lx0b0);

La0b0=sqrt_a(Lx0b0^2+ep^2-2*Lx0b0*ep*cos(beta+phis-phip-gamma));
% Lc0d0=La0b0;
Lb0c0=2*(l1+ea+es*cos(phis));
La0d0=2*(l2+ep*cos(phip));

Lbc=Lb0c0+2*es*(cos(phis-thetaS)-cos(phis))-2*ea*(1-cos(thetaA_)); %Lbc

Laa0=2*ep*sin(thetaPL/2);
delta=acos_c((La0d0-Lb0c0)/(2*La0b0));
Lad0=sqrt_a(La0d0^2+Laa0^2+2*La0d0*Laa0*sin(phip-thetaPL/2));
Ldd0=2*ep*sin(thetaPR/2);
tau=acos_c((La0d0^2+Lad0^2-Laa0^2)/(2*Lad0*La0d0));

Lad=sqrt_a(Lad0^2+Ldd0^2-2*Lad0*Ldd0*sin(thetaPR/2-phip+tau)); %Lad

%Lab
Ly0y=2*ea*sin(abs(thetaA_)/2);
if abs(thetaA_)<=1E-5
    Lb0y=es;
    mu=pi/2-phis;
    Lbb0=sqrt_a(Lb0y^2+es^2+2*Lb0y*es*sin(thetaS-phis-mu-abs(thetaA_)/2));
    sigma=mu;
    La0b=sqrt_a(La0b0^2+Lbb0^2-2*La0b0*Lbb0*sin(delta+sigma-mu-abs(thetaA_)/2));
elseif thetaA_<0
    Lb0y=sqrt_a(Ly0y^2+es^2+2*Ly0y*es*sin(phis+abs(thetaA_)/2));
    mu=acos_c((Lb0y^2+Ly0y^2-es^2)/(2*Lb0y*Ly0y));
    Lbb0=sqrt_a(Lb0y^2+es^2+2*Lb0y*es*sin(thetaS-phis-mu-abs(thetaA_)/2));
    sigma=acos_c((Lbb0^2+Lb0y^2-es^2)/(2*Lbb0*Lb0y));
    La0b=sqrt_a(La0b0^2+Lbb0^2-2*La0b0*Lbb0*sin(delta+sigma-mu-abs(thetaA_)/2));
else
    Lb0y=sqrt_a(Ly0y^2+es^2+2*Ly0y*es*sin(thetaA_/2-phis));
    mu=acos_c((Lb0y^2+Ly0y^2-es^2)/(2*Lb0y*Ly0y));
    Lbb0=sqrt_a(Lb0y^2+es^2+2*Lb0y*es*sin(phis-thetaS-mu-thetaA_/2));
    sigma=acos_c((Lbb0^2+Lb0y^2-es^2)/(2*Lbb0*Lb0y));
    if (phis-thetaS)>=(mu-pi/2+thetaA_/2)
        La0b=sqrt_a(La0b0^2+Lbb0^2-2*La0b0*Lbb0*sin(sigma-delta-mu-thetaA_/2));
    else
        La0b=sqrt_a(La0b0^2+Lbb0^2-2*La0b0*Lbb0*sin(-sigma-delta-mu-thetaA_/2));
    end
end
rho=acos_c((La0b0^2+La0b^2-Lbb0^2)/(2*La0b0*La0b));
if thetaA_<=0
    Lab=sqrt_a(Laa0^2+La0b^2-2*Laa0*La0b*sin(thetaPL/2-phip-delta+rho));
    Lcd=sqrt_a(Laa0^2+La0b^2-2*Laa0*La0b*sin(thetaPR/2-phip-delta+rho));
else
    if (phis-thetaS)>=(mu-pi/2+thetaA_/2)
        if (pi/2-delta+sigma-mu-thetaA_/2)>=0
            Lab=sqrt_a(Laa0^2+La0b^2-2*Laa0*La0b*sin(thetaPL/2-phip-delta+rho));
            Lcd=sqrt_a(Laa0^2+La0b^2-2*Laa0*La0b*sin(thetaPR/2-phip-delta+rho));
        else
            Lab=sqrt_a(Laa0^2+La0b^2-2*Laa0*La0b*sin(thetaPL/2-phip-delta-rho));
            Lcd=sqrt_a(Laa0^2+La0b^2-2*Laa0*La0b*sin(thetaPR/2-phip-delta-rho));
        end
    else
        if (pi*3/2-delta-sigma-mu-thetaA_/2)>=0
            Lab=sqrt_a(Laa0^2+La0b^2-2*Laa0*La0b*sin(thetaPL/2-phip-delta+rho));
            Lcd=sqrt_a(Laa0^2+La0b^2-2*Laa0*La0b*sin(thetaPR/2-phip-delta+rho));
        else
            Lab=sqrt_a(Laa0^2+La0b^2-2*Laa0*La0b*sin(thetaPL/2-phip-delta-rho));
            Lcd=sqrt_a(Laa0^2+La0b^2-2*Laa0*La0b*sin(thetaPR/2-phip-delta-rho));
        end
    end
end


% if Laa0==0
%     eta=delta-rho;
% else
%     epsilon=acos_c((Laa0^2+Lab^2-La0b^2)/(2*Laa0*Lab));
%     eta=pi/2-phip+thetaPL/2-epsilon;
% end
% Lab*sin(pi/2-eta)-(Lad-Lbc)/2
eta=pi/2-asin((Lad-Lbc)/2/Lab);

% final geometry
% Geo_datum.Lab=Lab;Geo_datum.Lcd=Lcd;Geo_datum.Lbc=Lbc;Geo_datum.Lad=Lad;Geo_datum.eta=eta;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        Roll Force  Distribution           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% roll_force_distribution;
% roll parameters


%% angle calculations
theta6=1/2*acos_c(1-2*Lbc^2/(Db+D2i)^2); %theta 6 and theta6r
theta6r=theta6; 

theta9=pi/2-eta;
theta10=acos_c(1-2*Lab^2/(Db+D2d)^2);
theta11=(pi-theta10)/2;
theta7=theta9-theta11; %theta7
theta5=theta10-theta7; %theta5
theta12=theta6+theta7;

Lij=1/2*sqrt_a((Db+D2d)^2+(Db+D2i)^2-2*(Db+D2d)*(Db+D2i)*cos(theta12));
theta13=asin((Db+D2d)*sin(theta12)/(2*Lij));
theta14=acos_c((4*Lij^2+(D2i+D1)^2-(D2d+D1)^2)/(4*Lij*(D2i+D1)));
theta3=pi-theta6-theta13-theta14; %theta3

theta15=acos_c(((D2i+D1)^2+(D2d+D1)^2-4*Lij^2)/(2*(D2i+D1)*(D2d+D1)));
theta4=theta15-theta3; %theta4

Lac=sqrt_a(Lab^2+Lbc^2+2*Lab*Lbc*cos(eta));
Ang_bca=asin(Lab*sin(eta)/Lac);
Ang_acd=acos_c((Lac^2+Lcd^2-Lad^2)/(2*Lac*Lcd));
psi=pi-Ang_bca-Ang_acd; %psi calcaulation

% same procedure for right hand side
theta9r=pi/2-psi;
theta10r=acos_c(1-2*Lab^2/(Db+D2d)^2);
theta11r=(pi-theta10r)/2;
theta7r=theta9r-theta11r;
theta5r=theta10r-theta7r;
theta12r=theta6r+theta7r;

Lijr=1/2*sqrt_a((Db+D2d)^2+(Db+D2i)^2-2*(Db+D2d)*(Db+D2i)*cos(theta12r));
theta13r=asin((Db+D2d)*sin(theta12r)/(2*Lijr));
theta14r=acos_c((4*Lijr^2+(D2i+D1)^2-(D2d+D1)^2)/(4*Lijr*(D2i+D1)));
theta3r=pi-theta6r-theta13r-theta14r;

theta15r=acos_c(((D2i+D1)^2+(D2d+D1)^2-4*Lijr^2)/(2*(D2i+D1)*(D2d+D1)));
theta4r=theta15r-theta3r;

% calcaultion of theta2
Lop=(D2i+D1)*sin((theta3+theta3r)/2);
x=2*asin(Lop/(D1+Dw));
y=((D2i+D1)*(cos(theta3)-cos(theta3r)))/(D1+Dw);
theta2=2*atan((sin(x)-sqrt_a(4*sin(x/2)^2-y^2))/(y-2*sin(x/2)^2));
theta2r=acos_c(cos(theta2)+y);

%% Force distribution
% pt=1;% rolling load pt=f(w,hi,ho,Ti,To,k,mu,E,v,R)
% pt=3.25E6;
pt=3.5E6;
% DR=2.75*RESIST(25,h_mean*1E3,h_mean*1E3,H_mean*1E3);
% OUT=RCFORCE(Rw*1E3,DR(1),DR(2),134/Ls,191/Ls,h_mean*1E3,H_mean*1E3,v,E*1E-6,0.06)*Ls*1E3;
% pt=OUT(1);

f1=1.0*pt;
f2r=sin(theta2)/sin(theta2+theta2r)*pt;
f2=f2r*sin(theta2r)/sin(theta2);
f3=f2*sin(theta4-theta2)/sin(theta3+theta4);
f3r=f2r*sin(theta4r-theta2r)/sin(theta3r+theta4r);
f4=f3*sin(theta3+theta2)/sin(theta4-theta2);
f4r=f3r*sin(theta3r+theta2r)/sin(theta4r-theta2r);
f7=f4*sin(theta5-theta4)/sin(theta5+theta7);
f7r=f4r*sin(theta5r-theta4r)/sin(theta5r+theta7r);
f5=f7*sin(theta7+theta4)/sin(theta5-theta4);
f5r=f7r*sin(theta7r+theta4r)/sin(theta5r-theta4r);
f6=(f3*sin(theta6-theta3)+f3r*sin(theta6+theta3r))/sin(2*theta6);
f6r=f6+(f3*sin(theta3)-f3r*sin(theta3r))/sin(theta6);

theta8=atan((f6*sin(theta6)-f7*sin(theta7))/(f7*cos(theta7)+f6*cos(theta6)));
theta8r=atan((f6r*sin(theta6r)-f7r*sin(theta7r))/(f7r*cos(theta7r)+f6r*cos(theta6r)));

f8=f6*cos(theta6-theta8)+f7*cos(theta7+theta8);
f8r=f6r*cos(theta6r-theta8r)+f7r*cos(theta7r+theta8r);

% verification
if(f5*cos(theta5)+f8*cos(theta8)+f8r*cos(theta8r)+f5r*cos(theta5r)-pt<1E-5)
%     theta=[0,theta2,theta3,theta4,theta5,theta6,theta7,theta8];
%     thetar=[0,theta2r,theta3r,theta4r,theta5r,theta6r,theta7r,theta8r];
%     theta*180/pi;
%     thetar*180/pi;
    F=[f1,f2,f3,f4,f5,f6,f7,f8];
else
    disp('error')
    F=[f1,f2,f3,f4,f5,f6,f7,f8];
%     f5*cos(theta5)+f8*cos(theta8)+f8r*cos(theta8r)+f5r*cos(theta5r)
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Loading Pattern on 2IR                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% loading_pattern_on_2IR;
thetac=acos_c(Lbc/(2*Rb+R2i));
Lb1b=2*ea*sin(abs(thetaA)/2);
Lb1v=zeros(1,N);
for i=1:N
    if thetaA(i)>=0
        Lb1v(i)=sqrt_a(Rb^2+Lb1b(i).^2+2.*Rb.*Lb1b(i).*sin(abs(thetaA(i))./2-thetac));
    else
        Lb1v(i)=sqrt_a(Rb^2+Lb1b(i).^2+2.*Rb.*Lb1b(i).*sin(abs(thetaA(i))./2+thetac));
    end
end
abv=Lb1v-Rb;

Lp=(Pb-Lb)/2;
yf=zeros(1,N-1);
yr=zeros(1,N-1);
Lf=zeros(1,N-1);
for i=1:N-1
    if abv(i)*abv(i+1)>=0 % a c d e g h
        yf(i)=abv(i)-Lp/Pb*(abv(i)-abv(i+1));
        yr(i)=abv(i)-(Lp+Lb)/Pb*(abv(i)-abv(i+1));
    else % b f
        Lf(i)=(abs(abv(i))*(Pb-2*Lp))/(abs(abv(i))+abs(abv(i+1)));
        yf(i)=Lf(i)/(Lf(i)+Lp)*abv(i);
        yr(i)=abv(i+1)*(1-Lp/(Pb-Lp-Lf(i)));
    end 
end

f1=pi*E/(2*(1-v^2));
f2=exp(2/3)*pi*E/(4*(1-v^2));
kb2=f1/(log(f2)+log(Db+D2i)-log(F(6)/Lt2));

qd=zeros(1,N-1);
td=zeros(1,N-1);
tdf=zeros(1,N-1);
tdr=zeros(1,N-1);
load_flag=zeros(1,N-1);
for i=1:N-1
    if abv(i)*abv(i+1)>=0
        if abs(abv(i))>=abs(abv(i+1))% a d e h
            qd(i)=kb2*yr(i);
            td(i)=kb2*(yf(i)-yr(i));
            load_flag(i)=1;
        else % c g
            qd(i)=kb2*yf(i);
            td(i)=kb2*(yr(i)-yf(i));
            load_flag(i)=2;
        end
        tdf(i)=0;
        tdr(i)=0;
    else % b f
        qd(i)=0;
        tdf(i)=kb2*yf(i);
        tdr(i)=kb2*yr(i);
        load_flag(i)=3;
    end 
end
xe=(Lt2-(N-1)*Pb)/2+(Pb-Lb)/2+(0:N-2)*Pb;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     Roll Deflection of 2IR                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% roll_deflection_2IR;
% UDL
k21=f1/(log(f2)+log(D2i+D1)-log(F(3)/Lt1));
I2=pi*D2i^4/64;
lambda2=(k21/(4*E*I2))^(1/4);
E12=0.5*exp(lambda2*Lt2)/(sinh(lambda2*Lt2)+sin(lambda2*Lt2));
E22=0.5*exp(lambda2*Lt2)/(sinh(lambda2*Lt2)-sin(lambda2*Lt2));

y2x_TDL_tf=zeros(N-1,M2);
y2x_TDL_tr=zeros(N-1,M2);

xm2=Lt2*(2*(1:M2)-1)/2/M2;

% [al2,bl2,cl2,dl2]=gfa(lambda2);
[al2_xe,bl2_xe,cl2_xe,~]=gfa(lambda2*xe);
[al2_Lt_xe,bl2_Lt_xe,cl2_Lt_xe,~]=gfa(lambda2*(Lt2-xe));
[al2_xeLb,bl2_xeLb,cl2_xeLb,~]=gfa(lambda2*(xe+Lb));
[al2_Lt_xe_Lb,bl2_Lt_xe_Lb,cl2_Lt_xe_Lb,~]=gfa(lambda2*(Lt2-xe-Lb));
[al2_Lt,~,cl2_Lt,dl2_Lt]=gfa(lambda2*Lt2);
[al2_xm2,bl2_xm2,~,~]=gfa(lambda2*(xm2));
[al2_Lt_xm2,bl2_Lt_xm2,~,~]=gfa(lambda2*(Lt2-xm2));

Ma2=-qd./(4*lambda2^2).*(bl2_xe - bl2_xeLb);
Mb2=qd./(4*lambda2^2).*(bl2_Lt_xe - bl2_Lt_xe_Lb);
Qa2=qd./(4*lambda2).*(cl2_xe - cl2_xeLb);
Qb2=qd./(4*lambda2).*(cl2_Lt_xe - cl2_Lt_xe_Lb);

Ma2d=0.5*(Ma2+Mb2); Ma2dd=0.5*(Ma2-Mb2); Qa2d=0.5*(Qa2-Qb2); Qa2dd=0.5*(Qa2+Qb2);

Fo2d= 4*E12*(Qa2d*(1+dl2_Lt) + lambda2*Ma2d*(1-al2_Lt));
Mo2d= -2*E12/lambda2*(Qa2d*(1+cl2_Lt) + 2*lambda2*Ma2d*(1-dl2_Lt));
Fo2dd= 4*E22*(Qa2dd*(1-dl2_Lt) + lambda2*Ma2dd*(1+al2_Lt));
Mo2dd= -2*E22/lambda2*(Qa2dd*(1-cl2_Lt) + 2*lambda2*Ma2dd*(1+dl2_Lt));

Foa2 = Fo2d + Fo2dd; Fob2 = Fo2d - Fo2dd; Moa2 = Mo2d + Mo2dd; Mob2 = Mo2d - Mo2dd;

y2x_UDL=lambda2/(2*k21)*(Foa2'*al2_xm2+Fob2'*al2_Lt_xm2)+lambda2^2/k21*(Moa2'*bl2_xm2+Mob2'*bl2_Lt_xm2);
dl2_xe_xm2=zeros(N-1,size(xm2,2));
dl2_xm2_xe=zeros(N-1,size(xm2,2));
dl2_xe_xm2Lb=zeros(N-1,size(xm2,2));
dl2_xm2_xe_Lb=zeros(N-1,size(xm2,2));
for j=1:N-1
    [~,~,~,dl2_xe_xm2(j,:)]=gfa(lambda2*(xe(j)-xm2));
    [~,~,~,dl2_xm2_xe(j,:)]=gfa(lambda2*(xm2-xe(j)));
    [~,~,~,dl2_xe_xm2Lb(j,:)]=gfa(lambda2*(xe(j)-xm2+Lb));
    [~,~,~,dl2_xm2_xe_Lb(j,:)]=gfa(lambda2*(xm2-xe(j)-Lb));
    for i=1:M2
        if xm2(i)<xe(j)
            y2x_UDL(j,i)=y2x_UDL(j,i) + qd(j)/(2*k21)*(dl2_xe_xm2(j,i)-dl2_xe_xm2Lb(j,i));
        elseif xm2(i)<=(xe(j)+Lb)
            y2x_UDL(j,i)=y2x_UDL(j,i) + qd(j)/(2*k21)*(2-dl2_xm2_xe(j,i)-dl2_xe_xm2Lb(j,i));
        else
            y2x_UDL(j,i)=y2x_UDL(j,i) - qd(j)/(2*k21)*(dl2_xm2_xe(j,i)-dl2_xm2_xe_Lb(j,i));
        end
    end
end
% clear Ma2 Mb2 Qa2 Qb2 Ma2d Ma2dd Qa2d
% [al2,bl2,cl2,dl2]=gfa(lambda2);

% TDL
Ma2=-td./(8*lambda2^3*Lb).*(al2_xe - al2_xeLb-2*lambda2*Lb*bl2_xeLb);
Mb2=-td./(8*lambda2^3*Lb).*(al2_Lt_xe - al2_Lt_xe_Lb+2*lambda2*Lb*bl2_Lt_xe_Lb);
Qa2=-td./(4*lambda2^2*Lb).*(bl2_xe - bl2_xeLb+lambda2*Lb*cl2_xeLb);
Qb2=td./(4*lambda2^2*Lb).*(bl2_Lt_xe - bl2_Lt_xe_Lb-lambda2*Lb*cl2_Lt_xe_Lb);

Ma2d=0.5*(Ma2+Mb2); Ma2dd=0.5*(Ma2-Mb2); Qa2d=0.5*(Qa2-Qb2); Qa2dd=0.5*(Qa2+Qb2);

Fo2d= 4*E12*(Qa2d*(1+dl2_Lt) + lambda2*Ma2d*(1-al2_Lt));
Mo2d= -2*E12/lambda2*(Qa2d*(1+cl2_Lt) + 2*lambda2*Ma2d*(1-dl2_Lt));
Fo2dd= 4*E22*(Qa2dd*(1-dl2_Lt) + lambda2*Ma2dd*(1+al2_Lt));
Mo2dd= -2*E22/lambda2*(Qa2dd*(1-cl2_Lt) + 2*lambda2*Ma2dd*(1+dl2_Lt));

Foa2 = Fo2d + Fo2dd; Fob2 = Fo2d - Fo2dd; Moa2 = Mo2d + Mo2dd; Mob2 = Mo2d - Mo2dd;

y2x_TDL=lambda2/(2*k21)*(Foa2'*al2_xm2+Fob2'*al2_Lt_xm2)+lambda2^2/k21*(Moa2'*bl2_xm2+Mob2'*bl2_Lt_xm2);
cl2_xe_xm2=zeros(N-1,size(xm2,2));
cl2_xm2_xe=zeros(N-1,size(xm2,2));
cl2_xe_xm2Lb=zeros(N-1,size(xm2,2));
cl2_xm2_xe_Lb=zeros(N-1,size(xm2,2));
for j=1:N-1
    [~,~,cl2_xe_xm2(j,:),dl2_xe_xm2(j,:)]=gfa(lambda2*(xe(j)-xm2));
    [~,~,cl2_xm2_xe(j,:),dl2_xm2_xe(j,:)]=gfa(lambda2*(xm2-xe(j)));
    [~,~,cl2_xe_xm2Lb(j,:),dl2_xe_xm2Lb(j,:)]=gfa(lambda2*(xe(j)-xm2+Lb));
    [~,~,cl2_xm2_xe_Lb(j,:),dl2_xm2_xe_Lb(j,:)]=gfa(lambda2*(xm2-xe(j)-Lb));
    for i=1:M2
        if xm2(i)<=xe(j)
            y2x_TDL(j,i)=y2x_TDL(j,i) + td(j)/(4*lambda2*k21*Lb)*(cl2_xe_xm2(j,i)-cl2_xe_xm2Lb(j,i)-2*lambda2*Lb*dl2_xe_xm2Lb(j,i));
        elseif xm2(i)<=(xe(j)+Lb)
            y2x_TDL(j,i)=y2x_TDL(j,i) + td(j)/(4*lambda2*k21*Lb)*(cl2_xm2_xe(j,i)-cl2_xe_xm2Lb(j,i)-2*lambda2*Lb*dl2_xe_xm2Lb(j,i)+4*lambda2*(xm2(i)-xe(j)));
        else
            y2x_TDL(j,i)=y2x_TDL(j,i) + td(j)/(4*lambda2*k21*Lb)*(cl2_xm2_xe(j,i)-cl2_xm2_xe_Lb(j,i)+2*lambda2*Lb*dl2_xm2_xe_Lb(j,i));
        end
    end
end

% clear Ma2 Mb2 Qa2 Qb2 Ma2d Ma2dd Qa2d
xed=Lt2-xe-Lb;

[al2_xed,bl2_xed,~,~]=gfa(lambda2*xed);
[al2_Lt_xed,bl2_Lt_xed,~,~]=gfa(lambda2*(Lt2-xed));
[al2_xedLb,bl2_xedLb,cl2_xedLb,~]=gfa(lambda2*(xed+Lb));
[al2_Lt_xed_Lb,bl2_Lt_xed_Lb,cl2_Lt_xed_Lb,~]=gfa(lambda2*(Lt2-xed-Lb));

Ma2=-td./(8*lambda2^3*Lb).*(al2_xed-al2_xedLb-2*lambda2*Lb*bl2_xedLb);
Mb2=-td./(8*lambda2^3*Lb).*(al2_Lt_xed-al2_Lt_xed_Lb+2*lambda2*Lb*bl2_Lt_xed_Lb);
Qa2=-td/(4*lambda2^2*Lb).*(bl2_xed-bl2_xedLb+lambda2*Lb*cl2_xedLb);
Qb2=td./(4*lambda2^2*Lb).*(bl2_Lt_xed-bl2_Lt_xed_Lb-lambda2*Lb*cl2_Lt_xed_Lb);

Ma2d=0.5*(Ma2+Mb2); Ma2dd=0.5*(Ma2-Mb2); Qa2d=0.5*(Qa2-Qb2); Qa2dd=0.5*(Qa2+Qb2);

Fo2d= 4*E12*(Qa2d*(1+dl2_Lt) + lambda2*Ma2d*(1-al2_Lt));
Mo2d= -2*E12/lambda2*(Qa2d*(1+cl2_Lt) + 2*lambda2*Ma2d*(1-dl2_Lt));
Fo2dd= 4*E22*(Qa2dd*(1-dl2_Lt) + lambda2*Ma2dd*(1+al2_Lt));
Mo2dd= -2*E22/lambda2*(Qa2dd*(1-cl2_Lt) + 2*lambda2*Ma2dd*(1+dl2_Lt));

Foa2 = Fo2d + Fo2dd; Fob2 = Fo2d - Fo2dd; Moa2 = Mo2d + Mo2dd; Mob2 = Mo2d - Mo2dd;
temp=lambda2/(2*k21)*(Foa2'*al2_xm2+Fob2'*al2_Lt_xm2)+lambda2^2/k21*(Moa2'*bl2_xm2+Mob2'*bl2_Lt_xm2);

cl2_xed_xm2=zeros(N-1,size(xm2,2));
cl2_xm2_xed=zeros(N-1,size(xm2,2));
cl2_xed_xm2Lb=zeros(N-1,size(xm2,2));
cl2_xm2_xed_Lb=zeros(N-1,size(xm2,2));
dl2_xed_xm2=zeros(N-1,size(xm2,2));
dl2_xm2_xed=zeros(N-1,size(xm2,2));
dl2_xed_xm2Lb=zeros(N-1,size(xm2,2));
dl2_xm2_xed_Lb=zeros(N-1,size(xm2,2));

for j=1:N-1
    [~,~,cl2_xed_xm2(j,:),dl2_xed_xm2(j,:)]=gfa(lambda2*(xed(j)-xm2));
    [~,~,cl2_xm2_xed(j,:),dl2_xm2_xed(j,:)]=gfa(lambda2*(xm2-xed(j)));
    [~,~,cl2_xed_xm2Lb(j,:),dl2_xed_xm2Lb(j,:)]=gfa(lambda2*(xed(j)-xm2+Lb));
    [~,~,cl2_xm2_xed_Lb(j,:),dl2_xm2_xed_Lb(j,:)]=gfa(lambda2*(xm2-xed(j)-Lb));
    for i=1:M2
        if xm2(i)<xed(j)
            temp(j,i)=temp(j,i) + td(j)/(4*lambda2*k21*Lb)*(cl2_xed_xm2(j,i)-cl2_xed_xm2Lb(j,i)-2*lambda2*Lb*dl2_xed_xm2Lb(j,i));
        elseif xm2(i)<=(xed(j)+Lb)
            temp(j,i)=temp(j,i) + td(j)/(4*lambda2*k21*Lb)*(cl2_xm2_xed(j,i)-cl2_xed_xm2Lb(j,i)-2*lambda2*Lb*dl2_xed_xm2Lb(j,i)+4*lambda2*(xm2(i)-xed(j)));
        else
            temp(j,i)=temp(j,i) + td(j)/(4*lambda2*k21*Lb)*(cl2_xm2_xed(j,i)-cl2_xm2_xed_Lb(j,i)+2*lambda2*Lb*dl2_xm2_xed_Lb(j,i));
        end
    end
end
for j=1:N-1
    if load_flag(j)==1
        y2x_TDL(j,:)=temp(j,:);
    end
end

%TDL_LH
% clear Ma2 Mb2 Qa2 Qb2 Ma2d Ma2dd Qa2d
xed=Lt2-xe-Lf;

[al2_xed,bl2_xed,~,~]=gfa(lambda2*xed);
[al2_Lt_xed,bl2_Lt_xed,~,~]=gfa(lambda2*(Lt2-xed));
[al2_xedLf,bl2_xedLf,cl2_xedLf,~]=gfa(lambda2*(xed+Lf));
[al2_Lt_xed_Lf,bl2_Lt_xed_Lf,cl2_Lt_xed_Lf,~]=gfa(lambda2*(Lt2-xed-Lf));

Ma2=-tdf./(8*lambda2^3*Lf).*(al2_xed-al2_xedLf-2*lambda2*Lf.*bl2_xedLf);
Mb2=-tdf./(8*lambda2^3*Lf).*(al2_Lt_xed-al2_Lt_xed_Lf+2*lambda2*Lf.*bl2_Lt_xed_Lf);
Qa2=-tdf./(4*lambda2^2*Lf).*(bl2_xed-bl2_xedLf+lambda2*Lf.*cl2_xedLf);
Qb2=tdf./(4*lambda2^2*Lf).*(bl2_Lt_xed-bl2_Lt_xed_Lf-lambda2*Lf.*cl2_Lt_xed_Lf);

Ma2d=0.5*(Ma2+Mb2); Ma2dd=0.5*(Ma2-Mb2); Qa2d=0.5*(Qa2-Qb2); Qa2dd=0.5*(Qa2+Qb2);

Fo2d= 4*E12*(Qa2d*(1+dl2_Lt) + lambda2*Ma2d*(1-al2_Lt));
Mo2d= -2*E12/lambda2*(Qa2d*(1+cl2_Lt) + 2*lambda2*Ma2d*(1-dl2_Lt));
Fo2dd= 4*E22*(Qa2dd*(1-dl2_Lt) + lambda2*Ma2dd*(1+al2_Lt));
Mo2dd= -2*E22/lambda2*(Qa2dd*(1-cl2_Lt) + 2*lambda2*Ma2dd*(1+dl2_Lt));

Foa2 = Fo2d + Fo2dd; Fob2 = Fo2d - Fo2dd; Moa2 = Mo2d + Mo2dd; Mob2 = Mo2d - Mo2dd;
temp=lambda2/(2*k21)*(Foa2'*al2_xm2+Fob2'*al2_Lt_xm2)+lambda2^2/k21*(Moa2'*bl2_xm2+Mob2'*bl2_Lt_xm2);
cl2_xed_xm2=zeros(N-1,size(xm2,2));
cl2_xm2_xed=zeros(N-1,size(xm2,2));
cl2_xed_xm2Lf=zeros(N-1,size(xm2,2));
cl2_xm2_xed_Lf=zeros(N-1,size(xm2,2));
dl2_xed_xm2=zeros(N-1,size(xm2,2));
dl2_xm2_xed=zeros(N-1,size(xm2,2));
dl2_xed_xm2Lf=zeros(N-1,size(xm2,2));
dl2_xm2_xed_Lf=zeros(N-1,size(xm2,2));
for j=1:N-1
    [~,~,cl2_xed_xm2(j,:),dl2_xed_xm2(j,:)]=gfa(lambda2*(xed(j)-xm2));
    [~,~,cl2_xm2_xed(j,:),dl2_xm2_xed(j,:)]=gfa(lambda2*(xm2-xed(j)));
    [~,~,cl2_xed_xm2Lf(j,:),dl2_xed_xm2Lf(j,:)]=gfa(lambda2*(xed(j)-xm2+Lf(j)));
    [~,~,cl2_xm2_xed_Lf(j,:),dl2_xm2_xed_Lf(j,:)]=gfa(lambda2*(xm2-xed(j)-Lf(j)));
    for i=1:M2
        if xm2(i)<xed(j)
            temp(j,i)=temp(j,i) + tdf(j)/(4*lambda2*k21*Lf(j))*(cl2_xed_xm2(j,i)-cl2_xed_xm2Lb(j,i)-2*lambda2*Lf(j)*dl2_xed_xm2Lf(j,i));
        elseif xm2(i)<=(xed(j)+Lf(j))
            temp(j,i)=temp(j,i) + tdf(j)/(4*lambda2*k21*Lf(j))*(cl2_xm2_xed(j,i)-cl2_xed_xm2Lf(j,i)-2*lambda2*Lf(j)*dl2_xed_xm2Lf(j,i)+4*lambda2*(xm2(i)-xed(j)));
        else
            temp(j,i)=temp(j,i) + tdf(j)/(4*lambda2*k21*Lf(j))*(cl2_xm2_xed(j,i)-cl2_xm2_xed_Lf(j,i)+2*lambda2*Lf(j)*dl2_xm2_xed_Lf(j,i));
        end
    end
end
for j=1:N-1
    if load_flag(j)==3
        y2x_TDL_tf(j,:)=fliplr(temp(j,:));
    end
end


%TDL_RH
% clear Ma2 Mb2 Qa2 Qb2 Ma2d Ma2dd Qa2d
xe=xe+Lf;

[al2_xe,bl2_xe,~,~]=gfa(lambda2*xe);
[al2_Lt_xe,bl2_Lt_xe,~,~]=gfa(lambda2*(Lt2-xe));
[al2_xeLb_Lf,bl2_xeLb_Lf,cl2_xeLb_Lf,~]=gfa(lambda2*(xe+Lb-Lf));
[al2_Lt_xe_LbLf,bl2_Lt_xe_LbLf,cl2_Lt_xe_LbLf,~]=gfa(lambda2*(Lt2-xe-Lb+Lf));

Ma2=-tdr./(8*lambda2^3*(Lb-Lf)).*(al2_xe - al2_xeLb_Lf-2*lambda2*(Lb-Lf).*bl2_xeLb_Lf);
Mb2=-tdr./(8*lambda2^3*(Lb-Lf)).*(al2_Lt_xe - al2_Lt_xe_LbLf+2*lambda2*(Lb-Lf).*bl2_Lt_xe_LbLf);
Qa2=-tdr./(4*lambda2^2*(Lb-Lf)).*(bl2_xe - bl2_xeLb_Lf+lambda2*(Lb-Lf).*cl2_xeLb_Lf);
Qb2=tdr./(4*lambda2^2*(Lb-Lf)).*(bl2_Lt_xe - bl2_Lt_xe_LbLf-lambda2*(Lb-Lf).*cl2_Lt_xe_LbLf);

Ma2d=0.5*(Ma2+Mb2); Ma2dd=0.5*(Ma2-Mb2); Qa2d=0.5*(Qa2-Qb2); Qa2dd=0.5*(Qa2+Qb2);

Fo2d= 4*E12*(Qa2d*(1+dl2_Lt) + lambda2*Ma2d*(1-al2_Lt));
Mo2d= -2*E12/lambda2*(Qa2d*(1+cl2_Lt) + 2*lambda2*Ma2d*(1-dl2_Lt));
Fo2dd= 4*E22*(Qa2dd*(1-dl2_Lt) + lambda2*Ma2dd*(1+al2_Lt));
Mo2dd= -2*E22/lambda2*(Qa2dd*(1-cl2_Lt) + 2*lambda2*Ma2dd*(1+dl2_Lt));

Foa2 = Fo2d + Fo2dd; Fob2 = Fo2d - Fo2dd; Moa2 = Mo2d + Mo2dd; Mob2 = Mo2d - Mo2dd;

temp=lambda2/(2*k21)*(Foa2'*al2_xm2+Fob2'*al2_Lt_xm2)+lambda2^2/k21*(Moa2'*bl2_xm2+Mob2'*bl2_Lt_xm2);
cl2_xe_xm2=zeros(N-1,size(xm2,2));
cl2_xm2_xe=zeros(N-1,size(xm2,2));
cl2_xe_xm2Lb_Lf=zeros(N-1,size(xm2,2));
cl2_xm2_xe_LbLf=zeros(N-1,size(xm2,2));
dl2_xe_xm2=zeros(N-1,size(xm2,2));
dl2_xm2_xe=zeros(N-1,size(xm2,2));
dl2_xe_xm2Lb_Lf=zeros(N-1,size(xm2,2));
dl2_xm2_xe_LbLf=zeros(N-1,size(xm2,2));
for j=1:N-1
    for i=1:M2
        [~,~,cl2_xe_xm2(j,:),dl2_xe_xm2(j,:)]=gfa(lambda2*(xe(j)-xm2));
        [~,~,cl2_xm2_xe(j,:),dl2_xm2_xe(j,:)]=gfa(lambda2*(xm2-xe(j)));
        [~,~,cl2_xe_xm2Lb_Lf(j,:),dl2_xe_xm2Lb_Lf(j,:)]=gfa(lambda2*(xe(j)-xm2+Lb-Lf(j)));
        [~,~,cl2_xm2_xe_LbLf(j,:),dl2_xm2_xe_LbLf(j,:)]=gfa(lambda2*(xm2-xe(j)-Lb+Lf(j)));
        if xm2(i)<xe(j)
            temp(j,i)=temp(j,i) + tdr(j)/(4*lambda2*k21*(Lb-Lf(j)))*(cl2_xe_xm2(j,i)-cl2_xe_xm2Lb_Lf(j,i)-2*lambda2*(Lb-Lf(j))*dl2_xe_xm2Lb_Lf(j,i));
        elseif xm2(i)<=(xe(j)+(Lb-Lf(j)))
            temp(j,i)=temp(j,i) + tdr(j)/(4*lambda2*k21*(Lb-Lf(j)))*(cl2_xm2_xe(j,i)-cl2_xe_xm2Lb_Lf(j,i)-2*lambda2*(Lb-Lf(j))*dl2_xe_xm2Lb_Lf(j,i)+4*lambda2*(xm2(i)-xe(j)));
        else
            temp(j,i)=temp(j,i) + tdr(j)/(4*lambda2*k21*(Lb-Lf(j)))*(cl2_xm2_xe(j,i)-cl2_xm2_xe_LbLf(j,i)+2*lambda2*(Lb-Lf(j))*dl2_xm2_xe_LbLf(j,i));
        end
    end
end
for j=1:N-1
    if load_flag(j)==3
        y2x_TDL_tr(j,:)=temp(j,:);
    end
end
% xe=xe-Lf; %return

for j=1:N-1
    if load_flag(j)==1
        y2x_TDL(j,:)=fliplr(y2x_TDL(j,:));
    end
end
T2=2*cos(theta6)*cos(theta3);
y2x=sum(y2x_UDL+y2x_TDL+y2x_TDL_tr+y2x_TDL_tf)*T2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     Loading and Deflection of 1IR         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% loading_deflection_1IR;
% loading pattern on 1IR
% x1f=Lt2*(2*(1:J1F)-1)/(2*J1F);
xm1=zeros(1,M2);
F1N=zeros(1,J1F);

if Lt1>=Lt2
    x1f=(Lt1-Lt2)/2+Lt2*(2*(1:J1F)-1)/(2*J1F); % include roll width difference by JP 170809
else
    x1f=Lt2*(2*(1:J1F)-1)/(2*J1F);
end

for i=1:M1
    xm1(i)=Lt1*(2*i-1)/(2*M1);
end
for i=1:J1F
    for j=1+(i-1)*M2/J1F:i*M2/J1F
        F1N(i)=F1N(i)+k21*Lt1/M2*y2x(j);
    end
end
T1=cos(theta3)*cos(theta2);
F1N=F1N*T1;

% delfection of 1IR(Tapered)
dx=x1f(2)-x1f(1);
dyt=-D1t/2/Ltap*((LIT-x1f).*(LIT>=x1f));
dyb=-D1t/2/Ltap*((LIB-x1f).*(LIB>=x1f));
dy=dyt+fliplr(dyb);
D1x=D1+2*dy;
% k1w_=f1./(log(f2)+log(D1x+Dw)-log(F(2)/Lt));
k1w=f1/(log(f2)+log(D1+Dw)-log(F(2)/Lt));
I1=pi*D1^4/64;
lambda1=(k1w/(4*E*I1))^(1/4);
E1=0.5*exp(lambda1*Lt1)/(sinh(lambda1*Lt1) + sin(lambda1*Lt1));
E21=0.5*exp(lambda1*Lt1)/(sinh(lambda1*Lt1) - sin(lambda1*Lt1));

% [al1,bl1,cl1,dl1]=gfa(lambda1);
[~,~,cl1_x1f,dl1_x1f]=gfa(lambda1*x1f);
[~,~,cl1_Lt_x1f,dl1_Lt_x1f]=gfa(lambda1*(Lt1-x1f));
[al1_Lt,~,cl1_Lt,dl1_Lt]=gfa(lambda1*(Lt1));
[al1_xm1,bl1_xm1,~,~]=gfa(lambda1*(xm1));
[al1_Lt_xm1,bl1_Lt_xm1,~,~]=gfa(lambda1*(Lt1-xm1));

% clear Ma2 Mb2 Qa2 Qb2 Ma2d Ma2dd Qa2d

Ma1=(F1N-k1w*dy*dx)/(4*lambda1).*cl1_x1f;
Mb1=(F1N-k1w*dy*dx)/(4*lambda1).*cl1_Lt_x1f;
Qa1=(F1N-k1w*dy*dx)/2.*dl1_x1f;
Qb1=-(F1N-k1w*dy*dx)/2.*dl1_Lt_x1f;

Ma1d=0.5*(Ma1+Mb1); Ma1dd=0.5*(Ma1-Mb1); Qa1d=0.5*(Qa1-Qb1); Qa1dd=0.5*(Qa1+Qb1);

Fo1d= 4*E1*(Qa1d*(1+dl1_Lt) + lambda1*Ma1d*(1-al1_Lt));
Mo1d= -2*E1/lambda1*(Qa1d*(1+cl1_Lt) + 2*lambda1*Ma1d*(1-dl1_Lt));
Fo1dd= 4*E21*(Qa1dd*(1-dl1_Lt) + lambda1*Ma1dd*(1+al1_Lt));
Mo1dd= -2*E21/lambda1*(Qa1dd*(1-cl1_Lt) + 2*lambda1*Ma1dd*(1+dl1_Lt));

Foa1 = Fo1d + Fo1dd; Fob1 = Fo1d - Fo1dd; Moa1 = Mo1d + Mo1dd; Mob1 = Mo1d - Mo1dd;

y1x_ecf=lambda1/(2*k1w)*(Foa1'*al1_xm1+Fob1'*al1_Lt_xm1)+lambda1^2/k1w*(Moa1'*bl1_xm1+Mob1'*bl1_Lt_xm1);

y1x_self=zeros(J1F,M1);
al1_x1f_xm1=zeros(J1F,size(xm1,2));

for i=1:J1F
    al1_x1f_xm1(i,:)=gfa(lambda1*abs(x1f(i)-xm1));
    y1x_self(i,:)=lambda1*(F1N(i)-k1w*dy(i)*dx)/(2*k1w)*al1_x1f_xm1(i,:);
end

y1x=sum(y1x_ecf+y1x_self);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     Loading and Deflection of Work Roll   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% loading_deflection_wr;
% xwf=Lt*(2*(1:JWF)-1)/(2*JWF);
if Lt>=Lt1
    xwf=(Lt-Lt1)/2+Lt1*(2*(1:JWF)-1)/(2*JWF); % include roll width difference by JP 170809
else
    xwf=Lt*(2*(1:JWF)-1)/(2*JWF);
end
FwN=zeros(1,JWF);
for i=1:JWF
    for j=1+(i-1)*M1/JWF:i*M1/JWF
        FwN(i)=FwN(i)+k1w*Ls/M1*y1x(j);
    end
end
Tw=cos(theta2)+cos(theta2r);
FwN=FwN*Tw;

kwws=f1/(log(f2)+log(2*Dw)-log(pt/Ls));
Iw=pi*Dw^4/64;
lambdaws=(kwws/(4*E*Iw))^(1/4);
E1ws=0.5*exp(lambdaws*Ls)/(sinh(lambdaws*Ls)+sin(lambdaws*Ls));
E2ws=0.5*exp(lambdaws*Ls)/(sinh(lambdaws*Ls)-sin(lambdaws*Ls));
Lu=0.5*(Lt-Ls);

xmw=zeros(1,Mw);
for i=1:Mw
    xmw(i)=Lt*(2*i-1)/2/Mw;
end
% [alws,blws,clws,dlws]=gfa(lambdaws);
[~,blws.xwf_Lu,clws.xwf_Lu,dlws.xwf_Lu]=gfa(lambdaws*(xwf-Lu));
[~,blws.Ls_xwfLu,clws.Ls_xwfLu,dlws.Ls_xwfLu]=gfa(lambdaws*(Ls-xwf+Lu));
[alws_Ls,blws.Ls,clws.Ls,dlws.Ls]=gfa(lambdaws*(Ls));
[alws_Ls_xmwLu,blws.Ls_xmwLu,clws.Ls_xmwLu,dlws.Ls_xmwLu]=gfa(lambda1*(Ls-xmw+Lu));
[alws_xmw_Lu,blws.xmw_Lu,clws.xmw_Lu,dlws.xmw_Lu]=gfa(lambda1*(xmw-Lu));

% LH unsupported end

% RH unsupported end

% wr deflection due to a force over the strip

% clear Ma2 Mb2 Qa2 Qb2 Ma2d Ma2dd Qa2d

Mas=FwN/(4*lambdaws).*clws.xwf_Lu;
Mbs=FwN/(4*lambdaws).*clws.Ls_xwfLu;
Qas=FwN/2.*dlws.xwf_Lu;
Qbs=-FwN/2.*dlws.Ls_xwfLu;

Masd=0.5*(Mas+Mbs); Masdd=0.5*(Mas-Mbs); Qasd=0.5*(Qas-Qbs); Qasdd=0.5*(Qas+Qbs);

Fosd= 4*E1ws*(Qasd*(1+dlws.Ls) + lambdaws*Masd*(1-alws_Ls));
Mosd= -2*E1ws/lambdaws*(Qasd*(1+clws.Ls) + 2*lambdaws*Masd*(1-dlws.Ls));
Fosdd= 4*E2ws*(Qasdd*(1-dlws.Ls) + lambdaws*Masdd*(1+alws_Ls));
Mosdd= -2*E2ws/lambdaws*(Qasdd*(1-clws.Ls) + 2*lambdaws*Masdd*(1+dlws.Ls));

Foas = Fosd + Fosdd; Fobs = Fosd - Fosdd; Moas = Mosd + Mosdd; Mobs = Mosd - Mosdd;

ywx_ecf=lambdaws/(2*kwws)*(Foas'*alws_xmw_Lu + Fobs'*alws_Ls_xmwLu) + lambdaws^2/kwws*(Moas'*blws.xmw_Lu + Mobs'*blws.Ls_xmwLu);
ywx_self=zeros(JWF,Mw);
alws_xwf_xmw=zeros(JWF,size(xmw,2));
for i=1:JWF
    alws_xwf_xmw(i,:)=gfa(lambdaws*abs(xwf(i)-xmw));
    ywx_self(i,:)=FwN(i)*lambdaws/(2*kwws)*alws_xwf_xmw(i,:);
end
ywx=sum(ywx_ecf+ywx_self);
pc=polyfit(xmw,ywx,8);

% ywx_poly=polyval(pc,xmw);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Strip Shape Calculation &              %
%                Transformation to I-Unit   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% strip_shape_cal;
ih=floor(Ls/Lr);
if rem(ih,2)==1 % odd
    Jh=ih;
else            % even
    Jh=ih+1;
end

Lps=(Ls-Lr*(Jh-1))/2;
xn=Lu+Lps+((1:Jh)-1)*Lr;
yw=polyval(pc,xn);

Lts=(Lt-Lsr)/2;
xxx=[0:26:26*12,26*12+52:52:(26*12+52*14),(26*12+52*14+26):26:(26*12*2+52*14-26)];
xn2=Lts+xxx*0.001;

Lu_=0.5*(Lt-width);
flags=0;
flagf=0;
for i=1:size(xn,2)
    if xn(i)<=Lu_
        yw(i)=0;
    elseif xn(i)>Lu_
        if flags==0
            flags=1;xns=i;
        end
        if xn(i)>=width+Lu_
            yw(i)=0;
            if flagf==0
                flagf=1;xnf=i-1;
            end
        end
    end
end
flags=0;
flagf=0;
for i=1:size(xn2,2)
    if xn2(i)>Lu_
        if flags==0
            flags=1;xn2s=i;
        end
        if xn2(i)>=width+Lu_
            if flagf==0
                flagf=1;xn2f=i-1;
            end
        end
    end
end

yw_mean=mean(yw);
H=H_mean+yw_mean-yw;
H=abs(sign(yw).*H);
ds=Es*(1-(1)./(H(xns:xnf)*mean(1./H(xns:xnf))));

ds2=polyval(polyfit(xn(xns:xnf),ds,8),xn2(xn2s:xn2f));
ds2=[zeros(1,xn2s-1),ds2,zeros(1,xn2s-1)];
shape_I_unit=(-ds2/E*1E5)';
end