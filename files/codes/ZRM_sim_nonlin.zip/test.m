i=1;
IFM_SHAPEs_POSCO(u(i,:));


i=1;
plot(shape_I_unit);
hold on
load('GM1055.mat');range=7:32;range2=26;r3=6;
P=polyfit(((1:range2)-mean(1:range2))/range2,Gm(range,i)',8);
PolyGm(:,i)=[zeros(1,r3),polyval(P,((1:range2)-mean(1:range2))/range2),zeros(1,r3)];
plot(xn(range),PolyGm(range,i))
plot(xn(range),Gm_IFM(range,i))
hold off