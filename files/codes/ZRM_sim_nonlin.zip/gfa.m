function [a,b,c,d]=gfa(x)
a=exp(-x).*(cos(x)+sin(x));
b=exp(-x).*sin(x);
c=exp(-x).*(cos(x)-sin(x));
d=exp(-x).*cos(x);
end