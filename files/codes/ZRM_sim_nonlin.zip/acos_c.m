function y=acos_c(x)

y=real(acos(complex(x)));
end