% clc
% clear all
% trainRatio=0.80;
% valRatio=0;
% testRatio=.20;
% [trainInd,valInd,testInd] = dividerand(148,trainRatio,valRatio,testRatio);
% load wholedata_2015_2018_ver6
for j=1:3
load(['TrainValTest_Indices_',num2str(j),'_ver10_2015_2018_news'])

DTrain = DData(trainInd,:,:,1);
DValidation = DData(valInd,:,:,1);
DTest = DData(testInd,:,:,1);

DDTrain = DDataD(trainInd,:,:,1);
DDValidation = DDataD(valInd,:,:,1);
DDTest = DDataD(testInd,:,:,1);

MTrain = MData(trainInd,:,:,1);
MValidation = MData(valInd,:,:,1);
MTest = MData(testInd,:,:,1);

MDTrain = MDataD(trainInd,:,:,1);
MDValidation = MDataD(valInd,:,:,1);
MDTest = MDataD(testInd,:,:,1);

WTrain = WData(trainInd,:,:,1);
WValidation = WData(valInd,:,:,1);
WTest = WData(testInd,:,:,1);

WDTrain = WDataD(trainInd,:,:,1);
WDValidation = WDataD(valInd,:,:,1);
WDTest = WDataD(testInd,:,:,1);

PriceTrain = targetPriceWeekly(trainInd,:);
PriceValidation = targetPriceWeekly(valInd,:);
PriceTest = targetPriceWeekly(testInd,:);

PriceDTrain = targetPriceWeeklyD(trainInd,:);
PriceDValidation = targetPriceWeeklyD(valInd,:);
PriceDTest = targetPriceWeeklyD(testInd,:);

DailyPriceTrain = PriceLSTM(trainInd,:);
DailyPriceValidation = PriceLSTM(valInd,:);
DailyPriceTest = PriceLSTM(testInd,:);

DailyPriceDTrain = PriceDLSTM(trainInd,:);
DailyPriceDValidation = PriceDLSTM(valInd,:);
DailyPriceDTest = PriceDLSTM(testInd,:);

PriceDTrain_digit = targetPriceD_digit(trainInd,:);
PriceDValidation_digit = targetPriceD_digit(valInd,:);
PriceDTest_digit = targetPriceD_digit(testInd,:);

PriceDTrain_abs = targetPriceD_abs(trainInd,:);
PriceDValidation_abs = targetPriceD_abs(valInd,:);
PriceDTest_abs = targetPriceD_abs(testInd,:);

PriceDTest_digit=PriceDTest_digit/2+0.5;
PriceDTrain_digit=PriceDTrain_digit/2+0.5;

for i=1:5
    eval(['PriceDTrain',num2str(i),'_onehot(:,1)=PriceDTrain_digit(:,i);'])
    eval(['PriceDTrain',num2str(i),'_onehot(:,2)=PriceDTrain_digit(:,i);'])
    eval(['PriceDTest',num2str(i),'_onehot(:,1)=PriceDTest_digit(:,i);'])
    eval(['PriceDTest',num2str(i),'_onehot(:,2)=PriceDTest_digit(:,i);'])
end
% save(['TrainValTest_Indices_',num2str(j),'_ver10_2015_2018_news'],'trainInd','valInd','testInd')
save(['TrainValTestData_python_5weeksahead_',num2str(j),'_ver10_news_shift',num2str(n)],'DTrain','DValidation','DTest','DDTrain','DDValidation','DDTest',...
    'MTrain','MValidation','MTest','MDTrain','MDValidation','MDTest',...
    'WTrain','WValidation','WTest','WDTrain','WDValidation','WDTest',...
    'PriceDTrain','PriceDValidation','PriceDTest',...
    'PriceTrain','PriceValidation','PriceTest',...
    'DailyPriceTrain','DailyPriceValidation','DailyPriceTest',...
    'DailyPriceDTrain','DailyPriceDValidation','DailyPriceDTest',...
    'PriceDTrain_digit','PriceDValidation_digit','PriceDTest_digit',...
    'PriceDTrain_abs','PriceDValidation_abs','PriceDTest_abs',...
    'PriceDTrain1_onehot','PriceDTrain2_onehot','PriceDTrain3_onehot',...
    'PriceDTrain4_onehot','PriceDTrain5_onehot','PriceDTest1_onehot',...
    'PriceDTest2_onehot','PriceDTest3_onehot','PriceDTest4_onehot',...
    'PriceDTest5_onehot')
end