clc
clear all

% parameters
Nm=6; % number of months to use for predict
n=4; % % Number of Daily Shifts

% Load the data set
FilePath='C:\Users\J\Desktop\������ AI ������ȸ\������\interpolated_matfiles\';
% %{
monthlyData_1=load([FilePath,'����������ȯ��_����_2015-201807']);
monthlyData_2=load([FilePath,'�߱�������ǥ_����_2015-201807']);
monthlyData_3=load([FilePath,'ö�����û��������Է�_����_2015-201807']);
monthlyData_4=load([FilePath,'ö����ǰ����_����_2015-201807']);
monthlyData_5=load([FilePath,'����Ʈ���� ����3']);
monthlyData_6=load([FilePath,'��������2']);

weeklyData_1=load([FilePath,'����������ȯ��_�ְ�_2015-201807']);
weeklyData_2=load([FilePath,'ö�����������_�ְ�_2015-201807']);
weeklyData_3=load([FilePath,'ö����ǰ����_�ְ�_2015-201807']);

dailyData_1=load([FilePath,'����������ȯ��_�ϰ�_2015-201807']);
dailyData_2=load([FilePath,'ö����ǰ����_�ϰ�_2015-201807']);
dailyData_3=load([FilePath,'�����Ϻ�3']);


% set the date domains
% months
months=flipud((datetime(2015,01,01,0,0,0):calmonths(1):datetime(2018,07,01,0,0,0))');
% months=flipud((datetime(2011,01,01,0,0,0):calmonths(1):datetime(2013,12,01,0,0,0))');
[months_y,months_m,~]=ymd(months);
% weeks
weeks=flipud((datetime(2015,01,05,0,0,0):calweeks(1):datetime(2018,07,23,0,0,0))');
% weeks=flipud((datetime(2011,01,03,0,0,0):calweeks(1):datetime(2013,12,31,0,0,0))');
[weeks_y,weeks_m,weeks_d]=ymd(weeks);
% days
% %{
days=(datetime(2015,01,05,0,0,0):caldays(1):datetime(2018,07,27,0,0,0))';
% days=(datetime(2011,01,03,0,0,0):caldays(1):datetime(2013,12,31,0,0,0))';
weekdays_=weekday(days);
% remove weekends
for i=fliplr(1:size(weekdays_,1))
    if (weekdays_(i)==1)||(weekdays_(i)==7)
        days(i)=[];
    end
end
clear weekdays_
%}
days=flipud(days);
[days_y,days_m,days_d]=ymd(days);

ddata1=dailyData_1.x;
ddata2=dailyData_2.x;
ddata3=dailyData_3.x;

% monthly data augmentation
accum=0;
mdata1=zeros(42,10);
mdata4=zeros(42,3);
mdata6=zeros(42,5);

for i=1:42
    Nd=size(find((months_y(i)==days_y).*(months_m(i)==days_m)),1);
    mdata1(i,:)=mean(ddata1(1+accum+n:Nd+accum+n,:));
    mdata4(i,:)=mean(ddata2(1+accum+n:Nd+accum+n,:));
    mdata6(i,:)=sum(ddata3(1+accum+n:Nd+accum+n,:));
    accum=accum+Nd;
end
mdata1_t=monthlyData_1.x;
mdata4_t=monthlyData_4.x;
mdata1_t(:,9)=[];
mdata4_t(:,[2,5:9])=[];

%{
figure(1)
subplot(211)
plot(mdata1)
hold on
plot(mdata1_t,'.')
hold off
title('Shifted: line, Original: dots')
subplot(212)
plot(mdata4)
hold on
plot(mdata4_t,'.')
hold off
%}
%%
monthlyData_1.x(1:42,[1:8,10:11])=mdata1;
monthlyData_4.x(1:42,[1,3,4])=mdata4;
monthlyData_6.x(1:42,:)=mdata6;
%%
% weekly data augmentation
accum=0;
wdata1=zeros(185,10);
wdata3=zeros(185,3);
wdata4=zeros(187,5);

for i=1:185
    wdata1(i,:)=mean(ddata1(1+accum+n:5+accum+n,:));
    wdata3(i,:)=mean(ddata2(1+accum+n:5+accum+n,:));
    wdata4(i,:)=sum(ddata3(1+accum+n:5+accum+n,:));
    accum=accum+5;
end
wdata1_t=weeklyData_1.x;
wdata3_t=weeklyData_3.x;
wdata1_t(:,9)=[];
wdata3_t(:,[2,5:9])=[];
%{
figure(1)
subplot(211)
plot(wdata1)
hold on
plot(wdata1_t,'.')
hold off
title('Shifted: line, Original: dots')
subplot(212)
plot(wdata3)
hold on
plot(wdata3_t,'.')
hold off
%}
%%
weeklyData_1.x(1:185,[1:8,10:11])=wdata1;
weeklyData_3.x(1:185,[1,3,4])=wdata3;

%% 
PriceDataMonthly=monthlyData_4.x(:,1);
PriceDataWeekly=weeklyData_3.x(:,1);
PriceDataDaily=dailyData_2.x(:,1);

%monthlyData = [monthlyData_1.x,monthlyData_2.x,monthlyData_3.x,monthlyData_4.x];
monthlyData = [monthlyData_1.x,monthlyData_2.x,monthlyData_3.x,monthlyData_4.x,monthlyData_5.x,monthlyData_6.x];
% weeklyData = [weeklyData_1.x,weeklyData_2.x,weeklyData_3.x];
weeklyData = [weeklyData_1.x,weeklyData_2.x,weeklyData_3.x,wdata4];
% dailyData = [dailyData_1.x,dailyData_2.x];
dailyData = [dailyData_1.x,dailyData_2.x,dailyData_3.x];

clear monthlyData_1 monthlyData_2 monthlyData_3 monthlyData_4 weeklyData_1 ...
    weeklyData_2 weeklyData_3 dailyData_1 dailyData_2 dailyData_3 FilePath

% Make a deviations
monthlyDataD=monthlyData(1:end-1,:)-monthlyData(2:end,:);
weeklyDataD=weeklyData(1:end-1,:)-weeklyData(2:end,:);
dailyDataD=dailyData(1:end-1,:)-dailyData(2:end,:);

PriceDataWeeklyD=PriceDataWeekly(1:end-1,:)-PriceDataWeekly(2:end,:);
PriceDataDailyD=PriceDataDaily(1:end-1,:)-PriceDataDaily(2:end,:);

TargetPriceDataWeeklyD=[
    [zeros(4,1);PriceDataWeekly(1:end-5,:)-PriceDataWeekly(6:end,:)],...
    [zeros(3,1);PriceDataWeekly(1:end-4,:)-PriceDataWeekly(5:end,:)],...
    [zeros(2,1);PriceDataWeekly(1:end-3,:)-PriceDataWeekly(4:end,:)],...
    [zeros(1,1);PriceDataWeekly(1:end-2,:)-PriceDataWeekly(3:end,:)],...
    PriceDataWeekly(1:end-1,:)-PriceDataWeekly(2:end,:)];

Nonormal_TargetPriceDataWeeklyD=TargetPriceDataWeeklyD;
Nonormal_PriceDataWeekly=PriceDataWeekly;
PriceD_digit=sign(TargetPriceDataWeeklyD);
PriceD_abs=abs(TargetPriceDataWeeklyD);
PriceDataWeekly_unnormal=PriceDataWeekly;
% Normalize data
% min-max normalization
% %{
[monthlyData,min_monthlyData,max_monthlyData]=minmaxnorm(monthlyData);
[monthlyDataD,min_monthlyDataD,max_monthlyDataD]=minmaxnorm(monthlyDataD);
[weeklyData,min_weeklyData,max_weeklyData]=minmaxnorm(weeklyData);
[weeklyDataD,min_weeklyDataD,max_weeklyDataD]=minmaxnorm(weeklyDataD);
[dailyData,min_dailyData,max_dailyData]=minmaxnorm(dailyData);
[dailyDataD,min_dailyDataD,max_dailyDataD]=minmaxnorm(dailyDataD);
[PriceDataWeekly,min_PriceDataWeekly,max_PriceDataWeekly]=minmaxnorm(PriceDataWeekly);
[PriceDataWeeklyD,min_PriceDataWeeklyD,max_PriceDataWeeklyD]=minmaxnorm(PriceDataWeeklyD);
[PriceDataDaily,min_PriceDataDaily,max_PriceDataDaily]=minmaxnorm(PriceDataDaily);
[PriceDataDailyD,min_PriceDataDailyD,max_PriceDataDailyD]=minmaxnorm(PriceDataDailyD);
[TargetPriceDataWeeklyD,min_TargetPriceDataWeeklyD,max_TargetPriceDataWeeklyD]=minmaxnorm(TargetPriceDataWeeklyD);
[PriceD_abs,min_PriceD_abs,max_PriceD_abs]=minmaxnorm(PriceD_abs);

% For python
% %{
N=148; %148 for 2015-2018
% %{
MData=zeros(N,Nm,30+15,1);
WData=zeros(N,8,26+5,1);
DData=zeros(N,10,13+5,1);
MDataD=zeros(N,Nm,30+15,1);
WDataD=zeros(N,8,26+5,1);
DDataD=zeros(N,10,13+5,1);
WeeklyPriceOffset=zeros(N,1);
targetPriceWeekly=zeros(N,5);
targetPriceWeeklyD=zeros(N,5);
targetPriceD_digit=zeros(N,5);
targetPriceD_abs=zeros(N,5);
Week_Day=weeks(5:4+N);
PriceLSTM=zeros(N,10);
PriceDLSTM=zeros(N,10);
%}

for i=(5+4):size(weeks,1)
    % monthly data processing
    m0=find((weeks_y(i)==months_y).*(weeks_m(i)==months_m));
    if m0+Nm>(size(PriceDataMonthly,1)-1)
        break;
    end
    MData(i-4-4,:,:,1)=monthlyData(m0+1:m0+Nm,:);
    MDataD(i-4-4,:,:,1)=monthlyDataD(m0+1:m0+Nm,:);
    % weekly data processing
    w0=i;
    WData(i-4-4,:,:,1)=weeklyData(w0+1:w0+8,:);
    WDataD(i-4-4,:,:,1)=weeklyDataD(w0+1:w0+8,:);
    % daily data processing
    d0=find((weeks_y(i)==days_y).*(weeks_m(i)==days_m).*(weeks_d(i)==days_d));
    DData(i-4-4,:,:,1)=dailyData(d0+1+n:d0+10+n,:);
    DDataD(i-4-4,:,:,1)=dailyDataD(d0+1+n:d0+10+n,:);
    PriceLSTM(i-4-4,:)=PriceDataDaily(d0+1+n:d0+10+n)';
    PriceDLSTM(i-4-4,:)=PriceDataDailyD(d0+1+n:d0+10+n)';
    
    WeeklyPriceOffset(i-4-4,:)=Nonormal_PriceDataWeekly(i+1);
    targetPriceWeekly(i-4-4,:)=PriceDataWeekly(i-4:i);
    targetPriceWeeklyD(i-4-4,:)=TargetPriceDataWeeklyD(i,:);
    targetPriceD_digit(i-4-4,:)=PriceD_digit(i,:);
    targetPriceD_abs(i-4-4,:)=PriceD_abs(i,:);
end
