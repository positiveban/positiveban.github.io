clc
clear all

for i=1:3

load(['TrainValTestData_python_5weeksahead_',num2str(i),'_ver10_news_shift0'])

    tmp1 = DailyPriceDTrain;
    tmp2 = DailyPriceTrain;
    tmp3 = DDTrain;
    tmp4 = DTrain;
    tmp5 = MDTrain;
    tmp6 = MTrain;
    tmp7 = PriceDTrain;
    tmp8 = PriceDTrain1_onehot;
    tmp9 = PriceDTrain2_onehot;
    tmp10 = PriceDTrain3_onehot;
    tmp11 = PriceDTrain4_onehot;
    tmp12 = PriceDTrain5_onehot;
    tmp13 = PriceDTrain_abs;
    tmp14 = PriceDTrain_digit;
    tmp15 = PriceTrain;
    tmp16 = WDTrain;
    tmp17 = WTrain;
    
    tmp18 = DailyPriceDTest;
    tmp19 = DailyPriceTest;
    tmp20 = DDTest;
    tmp21 = DTest;
    tmp22 = MDTest;
    tmp23 = MTest;
    tmp24 = PriceDTest;
    tmp25 = PriceDTest1_onehot;
    tmp26 = PriceDTest2_onehot;
    tmp27 = PriceDTest3_onehot;
    tmp28 = PriceDTest4_onehot;
    tmp29 = PriceDTest5_onehot;
    tmp30 = PriceDTest_abs;
    tmp31 = PriceDTest_digit;
    tmp32 = PriceTest;
    tmp33 = WDTest;
    tmp34 = WTest;

    load(['TrainValTestData_python_5weeksahead_',num2str(i),'_ver10_news_shift1'])

    tmp1 = [tmp1; DailyPriceDTrain];
    tmp2 = [tmp2; DailyPriceTrain];
    tmp3 = [tmp3; DDTrain];
    tmp4 = [tmp4; DTrain];
    tmp5 = [tmp5; MDTrain];
    tmp6 = [tmp6; MTrain];
    tmp7 = [tmp7; PriceDTrain];
    tmp8 = [tmp8; PriceDTrain1_onehot];
    tmp9 = [tmp9; PriceDTrain2_onehot];
    tmp10 = [tmp10; PriceDTrain3_onehot];
    tmp11 = [tmp11; PriceDTrain4_onehot];
    tmp12 = [tmp12; PriceDTrain5_onehot];
    tmp13 = [tmp13; PriceDTrain_abs];
    tmp14 = [tmp14; PriceDTrain_digit];
    tmp15 = [tmp15; PriceTrain];
    tmp16 = [tmp16; WDTrain];
    tmp17 = [tmp17; WTrain];

    tmp18 = [tmp18; DailyPriceDTest];
    tmp19 = [tmp19; DailyPriceTest];
    tmp20 = [tmp20; DDTest];
    tmp21 = [tmp21; DTest];
    tmp22 = [tmp22; MDTest];
    tmp23 = [tmp23; MTest];
    tmp24 = [tmp24; PriceDTest];
    tmp25 = [tmp25; PriceDTest1_onehot];
    tmp26 = [tmp26; PriceDTest2_onehot];
    tmp27 = [tmp27; PriceDTest3_onehot];
    tmp28 = [tmp28; PriceDTest4_onehot];
    tmp29 = [tmp29; PriceDTest5_onehot];
    tmp30 = [tmp30; PriceDTest_abs];
    tmp31 = [tmp31; PriceDTest_digit];
    tmp32 = [tmp32; PriceTest];
    tmp33 = [tmp33; WDTest];
    tmp34 = [tmp34; WTest];

    load(['TrainValTestData_python_5weeksahead_',num2str(i),'_ver10_news_shift2'])

    tmp1 = [tmp1; DailyPriceDTrain];
    tmp2 = [tmp2; DailyPriceTrain];
    tmp3 = [tmp3; DDTrain];
    tmp4 = [tmp4; DTrain];
    tmp5 = [tmp5; MDTrain];
    tmp6 = [tmp6; MTrain];
    tmp7 = [tmp7; PriceDTrain];
    tmp8 = [tmp8; PriceDTrain1_onehot];
    tmp9 = [tmp9; PriceDTrain2_onehot];
    tmp10 = [tmp10; PriceDTrain3_onehot];
    tmp11 = [tmp11; PriceDTrain4_onehot];
    tmp12 = [tmp12; PriceDTrain5_onehot];
    tmp13 = [tmp13; PriceDTrain_abs];
    tmp14 = [tmp14; PriceDTrain_digit];
    tmp15 = [tmp15; PriceTrain];
    tmp16 = [tmp16; WDTrain];
    tmp17 = [tmp17; WTrain];

    tmp18 = [tmp18; DailyPriceDTest];
    tmp19 = [tmp19; DailyPriceTest];
    tmp20 = [tmp20; DDTest];
    tmp21 = [tmp21; DTest];
    tmp22 = [tmp22; MDTest];
    tmp23 = [tmp23; MTest];
    tmp24 = [tmp24; PriceDTest];
    tmp25 = [tmp25; PriceDTest1_onehot];
    tmp26 = [tmp26; PriceDTest2_onehot];
    tmp27 = [tmp27; PriceDTest3_onehot];
    tmp28 = [tmp28; PriceDTest4_onehot];
    tmp29 = [tmp29; PriceDTest5_onehot];
    tmp30 = [tmp30; PriceDTest_abs];
    tmp31 = [tmp31; PriceDTest_digit];
    tmp32 = [tmp32; PriceTest];
    tmp33 = [tmp33; WDTest];
    tmp34 = [tmp34; WTest];

    load(['TrainValTestData_python_5weeksahead_',num2str(i),'_ver10_news_shift3'])

    tmp1 = [tmp1; DailyPriceDTrain];
    tmp2 = [tmp2; DailyPriceTrain];
    tmp3 = [tmp3; DDTrain];
    tmp4 = [tmp4; DTrain];
    tmp5 = [tmp5; MDTrain];
    tmp6 = [tmp6; MTrain];
    tmp7 = [tmp7; PriceDTrain];
    tmp8 = [tmp8; PriceDTrain1_onehot];
    tmp9 = [tmp9; PriceDTrain2_onehot];
    tmp10 = [tmp10; PriceDTrain3_onehot];
    tmp11 = [tmp11; PriceDTrain4_onehot];
    tmp12 = [tmp12; PriceDTrain5_onehot];
    tmp13 = [tmp13; PriceDTrain_abs];
    tmp14 = [tmp14; PriceDTrain_digit];
    tmp15 = [tmp15; PriceTrain];
    tmp16 = [tmp16; WDTrain];
    tmp17 = [tmp17; WTrain];

    tmp18 = [tmp18; DailyPriceDTest];
    tmp19 = [tmp19; DailyPriceTest];
    tmp20 = [tmp20; DDTest];
    tmp21 = [tmp21; DTest];
    tmp22 = [tmp22; MDTest];
    tmp23 = [tmp23; MTest];
    tmp24 = [tmp24; PriceDTest];
    tmp25 = [tmp25; PriceDTest1_onehot];
    tmp26 = [tmp26; PriceDTest2_onehot];
    tmp27 = [tmp27; PriceDTest3_onehot];
    tmp28 = [tmp28; PriceDTest4_onehot];
    tmp29 = [tmp29; PriceDTest5_onehot];
    tmp30 = [tmp30; PriceDTest_abs];
    tmp31 = [tmp31; PriceDTest_digit];
    tmp32 = [tmp32; PriceTest];
    tmp33 = [tmp33; WDTest];
    tmp34 = [tmp34; WTest];


    load(['TrainValTestData_python_5weeksahead_',num2str(i),'_ver10_news_shift4'])

    DailyPriceDTrain = [tmp1; DailyPriceDTrain];
    DailyPriceTrain = [tmp2; DailyPriceTrain];
    DDTrain = [tmp3; DDTrain];
    DTrain = [tmp4; DTrain];
    MDTrain = [tmp5; MDTrain];
    MTrain = [tmp6; MTrain];
    PriceDTrain = [tmp7; PriceDTrain];
    PriceDTrain1_onehot = [tmp8; PriceDTrain1_onehot];
    PriceDTrain2_onehot = [tmp9; PriceDTrain2_onehot];
    PriceDTrain3_onehot = [tmp10; PriceDTrain3_onehot];
    PriceDTrain4_onehot = [tmp11; PriceDTrain4_onehot];
    PriceDTrain5_onehot = [tmp12; PriceDTrain5_onehot];
    PriceDTrain_abs = [tmp13; PriceDTrain_abs];
    PriceDTrain_digit = [tmp14; PriceDTrain_digit];
    PriceTrain = [tmp15; PriceTrain];
    WDTrain = [tmp16; WDTrain];
    WTrain = [tmp17; WTrain];

    DailyPriceDTest = [tmp18; DailyPriceDTest];
    DailyPriceTest = [tmp19; DailyPriceTest];
    DDTest = [tmp20; DDTest];
    DTest = [tmp21; DTest];
    MDTest = [tmp22; MDTest];
    MTest = [tmp23; MTest];
    PriceDTest = [tmp24; PriceDTest];
    PriceDTest1_onehot = [tmp25; PriceDTest1_onehot];
    PriceDTest2_onehot = [tmp26; PriceDTest2_onehot];
    PriceDTest3_onehot = [tmp27; PriceDTest3_onehot];
    PriceDTest4_onehot = [tmp28; PriceDTest4_onehot];
    PriceDTest5_onehot = [tmp29; PriceDTest5_onehot];
    PriceDTest_abs = [tmp30; PriceDTest_abs];
    PriceDTest_digit = [tmp31; PriceDTest_digit];
    PriceTest = [tmp32; PriceTest];
    WDTest = [tmp33; WDTest];
    WTest = [tmp34; WTest];


str=['TrainValTestData_python_5weeksahead_',num2str(i),'_ver10_extended'];
save(str)
end