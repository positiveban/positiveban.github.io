clc
clear all

% Load data
filename='�����Ϻ�3';

data=xlsread([filename,'.xlsx']);
% data=flipud(data);

% number of objects in the xlsx file
n_objects = size(data,2)/2;


% 2013-2015
% ���� 42
% �߱�������ǥ ������Է� 40. 15�� 1��, 18�� 6�� ��������
%
% �ϰ� 866, 878 --> ������ �� �ָ� ����

dates=(datetime(2015,01,01,0,0,0):caldays(1):datetime(2018,07,27,0,0,0))';
weekdays_=weekday(dates);

% remove weekends
for i=fliplr(1:size(weekdays_,1))
    if (weekdays_(i)==1)||(weekdays_(i)==7)
        dates(i)=[];
    end
end

% convert date to serial number
dates=flipud(datenum(dates));

% If there're NaN, convert it to dummy number
data(isnan(data))=11111111;

% rearrange data for each objects
dates_object=zeros(size(data,1),n_objects);

% convert the date into integer
for i=1:n_objects
    dates_object(:,i)=datenum(datevec(num2str(data(:,1+2*(i-1))),'yyyymmdd'));
end
x=zeros(size(dates,1),n_objects);

% rearrange the data at a non-sparse date domain
for i=1:size(dates,1)
    for p=1:n_objects
        row=find(dates_object(:,p)==dates(i)); % find the date from original data
        if row
            x(i,p)=data(row,2*p); % store in a new non-sparse domain set if it exists
        else
            x(i,p)=NaN; % place NaN in a new non-sparse domain set if it does not exist
        end
    end
end
for p=1:n_objects
    for i=flipud(1:size(dates_object,1))
        if dates_object(i,p)==406099
            dates_object(i,p)=NaN; % for displaying plots, we recover NaN on dummy date
        end
    end
end
figure(1)
for p=1:n_objects
    subplot(n_objects,1,p)
    plot(dates,x(:,p),'.')
    hold on
    plot(dates_object(:,p),data(:,2*p),'-')
    hold off
end
save(['C:\Users\J\Desktop\������ AI ������ȸ\������\matfiles\',filename,'.mat'],'x')