clc
clear all

filename='ö����ǰ����_�ϰ�_2015-201807';
data = load([filename,'.mat']);

x=zeros(size(data.x));
for i=1:size(data.x,2)
    x(:,i)=fillmissing(data.x(:,i),'linear');
end

% months
% dates=(datetime(2015,01,01,0,0,0):calmonths(1):datetime(2018,07,01,0,0,0))';
% dates=(datetime(2011,01,01,0,0,0):calmonths(1):datetime(2013,12,01,0,0,0))';

% weeks
% dates=(datetime(2014,12,29,0,0,0):calweeks(1):datetime(2018,07,23,0,0,0))';
% dates=(datetime(2011,01,03,0,0,0):calweeks(1):datetime(2013,12,31,0,0,0))';

% days
% %{
dates=(datetime(2015,01,01,0,0,0):caldays(1):datetime(2018,07,27,0,0,0))';
% dates=(datetime(2011,01,03,0,0,0):caldays(1):datetime(2013,12,31,0,0,0))';

weekdays_=weekday(dates);
% remove weekends
for i=fliplr(1:size(weekdays_,1))
    if (weekdays_(i)==1)||(weekdays_(i)==7)
        dates(i)=[];
    end
end
%}
dates=flipud(dates);

figure(2)
for i=1:size(data.x,2)
    subplot(size(data.x,2),1,i)
    plot(dates,x(:,i),'.')
    hold on
    plot(dates,data.x(:,i),'>')
    hold off
end

save(['C:\Users\J\Desktop\������ AI ������ȸ\������\interpolated_matfiles\',filename,'.mat'],'x')