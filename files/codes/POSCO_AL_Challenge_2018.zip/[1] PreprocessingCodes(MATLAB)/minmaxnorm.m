function [y,min_x,max_x] = minmaxnorm(x)
    % Min-Max normalization
    % Y = minmaxnorm(X)
    % Y = (X - min(X))/(max(X) - min(X))    
    
    min_x=min(x);
    max_x=max(x);
    y=(x-min_x)./(max_x-min_x);    
end