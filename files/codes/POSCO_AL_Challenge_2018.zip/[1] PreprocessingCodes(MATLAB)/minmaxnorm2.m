function y = minmaxnorm2(x,min_x,max_x)
    % Min-Max normalization
    % Y = minmaxnorm(X)
    % Y = (X - min(X))/(max(X) - min(X))    
    
    y=(x-min_x)./(max_x-min_x);    
end