from __future__ import print_function
import keras
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten, Input, concatenate, add, BatchNormalization, Activation
from keras.layers import Conv2D, MaxPooling2D, AveragePooling2D
from keras import backend as K
from scipy import io
from keras.utils import plot_model
import matplotlib.pyplot as plt
import numpy as np
import random as rnd

import openpyxl
import time
import pandas as pd
import glob
import os
import shutil

import warnings
warnings.filterwarnings("ignore")

mat_file2 = io.loadmat('normalization_parameters_ver12.mat')

num_of_dataset = 1
output_dir = "output/"
output_dir2 = "outputforAug/"
# JP: 180801Aug_ver6_ext_data(6+July)_ker1(23)_ker2(23)_aver_max_dr(5)_nw0_ds0
# BJ: 180801Aug_ver6_ext_data(6+July)_ker1(23)_ker2(21)_conv_conv_dr(3)_nw0_ds0
# MS: 180801Aug_ver6_ext_data(6+July)_ker1(23)_ker2(22)_max_max_dr(4)_nw0_ds0

recode_pred = []

# 나 범준 교권
kernel_1_1_set = [3, 2, 3]
kernel_1_2_set = [2, 2, 3]

kernel_2_1_set = [1, 3, 3]
kernel_2_2_set = [2, 2, 2]

BN = 0

drop_out_rate_set = [5 * 0.1, 2 * 0.1, 3 * 0.1]

pi1_set = [2, 2, 1]  # 0: aver, 1: max, 2: conv
pi2_set = [1, 0, 1]  # 0: aver, 1: max, 2: conv

Pools1 = ["aver", "max", "conv"]
Pools2 = ["aver", "max", "conv"]

for k in range(3):
    for wholeiter in range(4):
        kernel_1_1 = kernel_1_1_set[k]
        kernel_1_2 = kernel_1_2_set[k]

        kernel_2_1 = kernel_2_1_set[k]
        kernel_2_2 = kernel_2_2_set[k]

        drop_out_rate = drop_out_rate_set[k]

        pi1 = pi1_set[k]  # 0: aver, 1: max, 2: conv
        pi2 = pi2_set[k]  # 0: aver, 1: max, 2: conv

        version = time.strftime('%y%m%d%h') + "_" + "ver12_ext_" \
                  + "data(6+July)_ker1(" + str(kernel_1_1) \
                  + str(kernel_1_2) + ")_ker2(" + str(kernel_2_1) + str(kernel_2_2) + ")_" + Pools1[pi1] + "_" + Pools2[
                      pi2] \
                  + "_dr(" + str(int(drop_out_rate * 10)) + ")"

        def make_branch1(model_input, input_shape):
            s1 = Conv2D(32, kernel_size=(kernel_1_1, kernel_1_2), input_shape=input_shape)(model_input)
            if BN == 1:
                s1 = BatchNormalization()(s1)
            s1 = Activation('relu')(s1)
            s1 = Dropout(drop_out_rate)(s1)

            s1 = Conv2D(64, (kernel_1_1, kernel_1_2))(s1)
            if BN == 1:
                s1 = BatchNormalization()(s1)
            s1 = Activation('relu')(s1)
            s1 = Dropout(drop_out_rate)(s1)

            if Pools1[pi1] == "aver":
                s1 = AveragePooling2D(pool_size=(2, 2))(s1)
            elif Pools1[pi1] == "max":
                s1 = MaxPooling2D(pool_size=(2, 2))(s1)
            else:
                s1 = Conv2D(128, (2, 2))(s1)
                if BN == 1:
                    s1 = BatchNormalization()(s1)
                s1 = Activation('relu')(s1)
                s1 = Dropout(drop_out_rate)(s1)

            s1 = Flatten()(s1)
            s1 = Dense(128)(s1)
            if BN == 1:
                s1 = BatchNormalization()(s1)

            s1 = Activation('relu')(s1)
            s1 = Dropout(drop_out_rate)(s1)

            return s1


        def make_branch2(model_input, input_shape):
            s2 = Conv2D(32, kernel_size=(kernel_2_1, kernel_2_2), input_shape=input_shape)(model_input)
            if BN == 1:
                s2 = BatchNormalization()(s2)
            s2 = Activation('relu')(s2)
            s2 = Dropout(drop_out_rate)(s2)
            s2 = Conv2D(64, (kernel_2_1, kernel_2_2))(s2)
            if BN == 1:
                s2 = BatchNormalization()(s2)
            s2 = Activation('relu')(s2)
            s2 = Dropout(drop_out_rate)(s2)

            if Pools2[pi2] == "aver":
                s2 = AveragePooling2D(pool_size=(2, 2))(s2)
            elif Pools2[pi2] == "max":
                s2 = MaxPooling2D(pool_size=(2, 2))(s2)
            else:
                s2 = Conv2D(128, (2, 2))(s2)
                if BN == 1:
                    s2 = BatchNormalization()(s2)
                s2 = Activation('relu')(s2)
                s2 = Dropout(drop_out_rate)(s2)

            s2 = Flatten()(s2)
            s2 = Dense(128)(s2)
            if BN == 1:
                s2 = BatchNormalization()(s2)
            s2 = Activation('relu')(s2)
            s2 = Dropout(drop_out_rate)(s2)
            return s2


        for itr_dataset in range(num_of_dataset):

            max_PriceDataWeekly = mat_file2['max_PriceDataWeekly']
            min_PriceDataWeekly = mat_file2['min_PriceDataWeekly']
            max_TargetPriceDataWeeklyD = mat_file2['max_TargetPriceDataWeeklyD']
            min_TargetPriceDataWeeklyD = mat_file2['min_TargetPriceDataWeeklyD']

            # 1: Daily, 2: DDaily, 3: Weekly, 4: DWeekly, 5: Monthly, 6: DMonthly
            input_shape1 = (10, 13 + 5, 1)
            input_1 = Input(shape=(10, 13 + 5, 1))
            model1 = make_branch1(input_1, input_shape1)

            input_shape2 = (10, 13 + 5, 1)
            input_2 = Input(shape=(10, 13 + 5, 1))
            model2 = make_branch1(input_2, input_shape2)

            input_shape3 = (8, 26 + 5, 1)
            input_3 = Input(shape=(8, 26 + 5, 1))
            model3 = make_branch1(input_3, input_shape3)

            input_shape4 = (8, 26 + 5, 1)
            input_4 = Input(shape=(8, 26 + 5, 1))
            model4 = make_branch1(input_4, input_shape4)

            input_shape5 = (6, 28 + 15, 1)
            input_5 = Input(shape=(6, 28 + 15, 1))
            model5 = make_branch2(input_5, input_shape5)

            input_shape6 = (6, 28 + 15, 1)
            input_6 = Input(shape=(6, 28 + 15, 1))
            model6 = make_branch2(input_6, input_shape6)

            merged = concatenate([model1, model2, model3, model4, model5, model6])

            out = Dense(128, activation='relu')(merged)
            out = Dropout(drop_out_rate)(out)
            out = Dense(5, activation='sigmoid')(out)

            out2 = Dense(128, activation='relu')(merged)
            out2 = Dropout(drop_out_rate)(out2)
            out_sub = Dense(5, activation='sigmoid')(out2)

            model = keras.models.Model(inputs=[input_1, input_2, input_3, input_4, input_5, input_6], outputs=[out, out_sub])

            # model.load_weights(output_dir + version + "_nw" + str(wholeiter) + "_ds" + str(itr_dataset) + ".h5")
            model.load_weights(output_dir + version + "_nw" + str(wholeiter) + "_net" + str(k) + ".h5")
            print("Loaded model to disk")

            ###################### for July  ################################

            # mat_file = io.loadmat('TestData_ver10_news_forJuly.mat')
            mat_file = io.loadmat('TestData_ver12_news_forAug.mat')

            DTest, DDTest, MTest, MDTest, WTest, WDTest = mat_file['DTest'], mat_file['DDTest'], mat_file['MTest'], \
                                                          mat_file['MDTest'], mat_file['WTest'], mat_file['WDTest']
            WeeklyPriceOffset = mat_file['WeeklyPriceOffset']

            test_data_length = len(DTest)

            DTest = DTest.reshape(test_data_length, 10, 13 + 5, 1)
            DDTest = DDTest.reshape(test_data_length, 10, 13 + 5, 1)
            WTest = WTest.reshape(test_data_length, 8, 26 + 5, 1)
            WDTest = WDTest.reshape(test_data_length, 8, 26 + 5, 1)
            MTest = MTest.reshape(test_data_length, 6, 28 + 15, 1)
            MDTest = MDTest.reshape(test_data_length, 6, 28 + 15, 1)

            Target_hat = model.predict([DTest, DDTest, WTest, WDTest, MTest, MDTest])
            Target_hat = np.delete(Target_hat, 1, 0)
            Target_hat = np.reshape(Target_hat, 5)

            Target_hat = (max_TargetPriceDataWeeklyD - min_TargetPriceDataWeeklyD) * Target_hat + min_TargetPriceDataWeeklyD

            print('Price Change Pred: ', Target_hat)

            recode_pred.append(Target_hat)

            del model, model1, model2, model3, model4, model5, model6
            K.clear_session()

            print("--------------------------")

# Ensemble the results
y = np.array(recode_pred)
print(y)
maxi = np.argmax(np.max(y, 2))
mini = np.argmin(np.min(y, 2))
y = np.delete(y, (maxi, mini), axis=0)
print(y)

y_ensemble = np.mean(y, 0)[0]

actual_price = (y_ensemble + WeeklyPriceOffset)[0]

recode = []
recode.append([actual_price[0], actual_price[1], actual_price[2], actual_price[3], actual_price[4]])
df_loss = pd.DataFrame(recode,
                       columns=['5w Prediction D', '4w Prediction D', '3w Prediction D', '2w Prediction D',
                                '1w Prediction D'])
writer = pd.ExcelWriter(output_dir2 + 'FinalAug' + time.strftime('%y%m%d') + '.xlsx', engine='xlsxwriter')
df_loss.to_excel(writer)
writer.save()

plt.figure(figsize=(20, 20))
plt.plot(actual_price)
plt.title('Coal Ore Price Prediction')
plt.ylabel('Price ($)')
plt.ylim([-5+WeeklyPriceOffset, 5+WeeklyPriceOffset])

plt.savefig(output_dir2 + "Final_Aug" + "_Target Price Prediction for Aug", dpi=None, facecolor='w',
            edgecolor='w',
            orientation='portrait', papertype=None, format=None,
            transparent=False, bbox_inches=None, pad_inches=0.1,
            frameon=None)
plt.close()
