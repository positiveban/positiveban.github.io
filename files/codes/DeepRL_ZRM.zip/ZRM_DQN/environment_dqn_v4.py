import numpy as np
from scipy import io


class Env:
    def __init__(self):
        super(Env, self).__init__()

        mat_file = io.loadmat('ZRM_Model.mat')
        self.A = mat_file['A']
        self.B = mat_file['B']
        self.C = mat_file['C']
        self.u0 = mat_file['u0']
        self.d = mat_file['d']
        self.svd_U = mat_file['U']
        self.svd_S = mat_file['S']
        self.svd_V = mat_file['V']

        self.nx = len(self.A)
        self.ny = len(self.C)
        self.nu = len(self.B[0])

        self.action_space = np.zeros([25, 9], dtype='float32')
        for k in [0, 2, 4, 6, 8, 10, 12, 14, 16]:
            self.action_space[k, int(k / 2)] = -1
            self.action_space[k + 1, int(k / 2)] = 1

        self.action_space[18, 0] = -1
        self.action_space[18, 6] = -1
        self.action_space[19, 0] = 1
        self.action_space[19, 6] = 1

        self.action_space[20, 1] = -1
        self.action_space[20, 5] = -1
        self.action_space[21, 1] = 1
        self.action_space[21, 5] = 1

        self.action_space[22, 2] = -1
        self.action_space[22, 4] = -1
        self.action_space[23, 2] = 1
        self.action_space[23, 4] = 1

        self.u = np.zeros([1, self.nu], dtype='float32')
        self.n_actions = len(self.action_space)
        self.x = np.zeros([1, self.nx], dtype='float32')
        self.y = np.zeros([1, self.ny], dtype='float32')
        self.n_states = len(self.y)
        self.steps = 1
        self.min_y = max(abs(self.d[0]))
        self.y0_max = max(abs(self.d[0]))

    def reset(self):
        self.u = np.zeros([1, self.nu], dtype='float32')
        self.x = np.zeros([1, self.nx], dtype='float32')  # 초기상태로 reset
        self.y = np.zeros([1, self.ny], dtype='float32')
        self.min_y = max(abs(self.d[0]))
        self.steps = 1
        tmp_y = self.d.T

        return np.concatenate((tmp_y.T, self.u), axis=1)

    def step(self, action):
        x = self.x

        if max(abs(self.y[0])) > 30:
            u = self.u + 5 * self.action_space[action]
        elif max(abs(self.y[0])) > 25:
            u = self.u + 2 * self.action_space[action]
        elif max(abs(self.y[0])) > 20:
            u = self.u + self.action_space[action]
        elif max(abs(self.y[0])) > 15:
            u = self.u + 0.5 * self.action_space[action]
        else:
            u = self.u + 0.25 * self.action_space[action]

        tmp_u = u + self.u0
        # for k in range(6):
        #     un = tmp_u[0, k]
        #     if (un <= 0) and (un >= 100):
        #         u[0, k] = self.u[0, k]

        # for k in range(7, 8):
        #     un = tmp_u[0, k]
        #     if (un <= 40) and (un >= 120):
        #         u[0, k] = self.u[0, k]

        # action 에 따른 State Transition
        tmp_x = np.dot(self.A, x.T) + np.dot(self.B, u.T)
        self.x = tmp_x.T
        tmp_y = np.dot(self.C, self.x.T) + self.d.T
        y = tmp_y.T

        # 보상함수
        # 보상함수
        if self.steps > 199:
            done = True
            reward = 0.0
            self.steps = 0

        elif max(abs(y[0])) > 50:
            done = True
            reward = -10.0
            self.steps = 0

        elif max(abs(y[0])) > self.y0_max:
            done = False
            reward = -1.0
            self.steps += 1

        elif max(abs(y[0])) < 15:
            done = False
            reward = 1.0
            self.steps += 1

        elif max(abs(y[0])) < self.min_y:
            done = False
            reward = self.min_y - max(abs(y[0]))
            self.min_y = max(abs(y[0]))
            self.steps += 1

        else:
            reward = 0.0
            done = False
            self.steps += 1

        self.y = y
        self.u = u

        u = u / 20
        y = y / 30

        return np.concatenate((y, u), axis=1), reward, done
