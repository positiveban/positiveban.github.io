from environment_dqn import Env
import matplotlib.pyplot as plt
import numpy as np

env = Env()
state = env.reset()

y = env.step(0)
y = env.step(1)


plt.show()