import numpy as np
from keras.models import Model
from keras.layers import Dense, Flatten, Input
from environment_a3c_v4 import Env
from scipy import io
import matplotlib.pyplot as plt

global episode
episode = 0
EPISODES = 2
env_name = "ZRM"
sv = 38

class TestAgent:
    def __init__(self, action_size):
        self.state_size = (sv + 9, )
        self.action_size = action_size

        self.discount_factor = 0.99
        self.no_op_steps = 30

        self.actor, self.critic = self.build_model()

    def build_model(self):
        ins = Input(shape=self.state_size)
        fc_act = Dense(50, activation='relu')(ins)
        fc_act = Dense(50, activation='relu')(fc_act)

        fc_cri = Dense(50, activation='relu')(ins)
        fc_cri = Dense(20, activation='relu')(fc_cri)

        policy = Dense(self.action_size, activation='softmax')(fc_act)
        # policy = Dense(self.action_size, activation='sigmoid')(fc_act)
        value = Dense(1, activation='linear')(fc_cri)

        actor = Model(inputs=ins, outputs=policy)
        critic = Model(inputs=ins, outputs=value)

        actor.summary()
        critic.summary()

        return actor, critic

    def get_action(self, history):
        history = np.float32(history)
        policy = self.actor.predict(history)[0]
        action_index = np.random.choice(self.action_size, 1, p=policy)[0]

        return action_index, policy

    def load_model(self, name):
        self.actor.load_weights(name)


if __name__ == "__main__":

    env = Env()
    agent = TestAgent(action_size=25)
    agent.load_model("save_model/zrm_a3c_25ins_actor.h5")

    step = 0

    done = False

    score = 0
    observe = env.reset()
    next_observe = observe

    traj_y, traj_u = [], []

    for k in range(41):
        step += 1
        observe = next_observe

        action, policy = agent.get_action(np.reshape(observe, [1, sv + 9]))

        # 선택한 행동으로 한 스텝을 실행
        next_observe, reward, done = env.step(action)

        traj_u.append(env.u)
        traj_y.append(env.y)

        score += reward

        # if done, plot the score over episodes
        if k > 40:
            episode += 1
            print("episode:", episode, "  score:", score, "  step:", step)
            step = 0

    traj_y = np.reshape(traj_y, [41, 38])
    traj_u = np.reshape(traj_u, [41, 9])


    plt.figure(1)
    plt.subplot(2, 1, 1)
    plt.plot(traj_u)
    plt.subplot(2, 1, 2)
    plt.plot(traj_y)
    plt.show()
