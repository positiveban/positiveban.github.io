from environment_a3c_v_esvd import Env
import matplotlib.pyplot as plt
import numpy as np
from scipy import io
import quadprog
import mosek, sys

mat_file = io.loadmat('ZRM_Model.mat')
mat_file2 = io.loadmat('ESVD_Control.mat')

Ac, Bc, Cc, Dc = mat_file2['Ac'], mat_file2['Bc'], mat_file2['Cc'], mat_file2['Dc']

Gm, all_PolyGm = mat_file2['Gm'], mat_file2['all_PolyGm']
Gm = Gm[:, 0:9]

svd_U, svd_S, svd_V = np.linalg.svd(Gm)
svd_S = np.diag(svd_S)
svd_V = svd_V.T

constraint_d, u_lb, u_ub, C_u = mat_file2['constraint_d'], mat_file2['u_lb'], mat_file2['u_ub'], mat_file2['C_u']

env = Env()
y = env.reset()
actions = np.zeros([1, 9], dtype='float32')
xc = np.zeros([1, 9], dtype='float32')

svd_Up = svd_U[:, 0:9]

traj_y, traj_yh, traj_u = [], [], []
V_S = np.dot(svd_V[:, 0:9], np.linalg.inv(svd_S[0:9, 0:9]))

def quadprog_solve_qp(P, q, G=None, h=None, A=None, b=None):
    qp_G = .5 * (P + P.T)   # make sure P is symmetric
    qp_a = -q
    if A is not None:
        qp_C = -np.vstack([A, G]).T
        qp_b = -np.hstack([b, h])
        meq = A.shape[0]
    else:  # no equality constraint
        qp_C = -G.T
        qp_b = -h
        meq = 0
    return quadprog.solve_qp(qp_G, qp_a, qp_C, qp_b, meq)[0]

def streamprinter(text):
    sys.stdout.write(text)
    sys.stdout.flush()

def mosek_solve_qo(Q, c, A=None, b=None, lb=None, ub=None):
        with mosek.Env() as m_env:
            m_env.set_Stream(mosek.streamtype.log, streamprinter)
            with m_env.Task() as task:
                task.set_Stream(mosek.streamtype.log, streamprinter)
                Q = .5 * (Q + Q.T)
                nq = len(Q)

                bkc = [mosek.boundkey.up] * len(b)
                blc = [0.0] * len(b)
                buc = b.tolist()

                numvar = nq
                bkx = [mosek.boundkey.ra] * numvar
                blx = lb.T[0].tolist()
                bux = ub.T[0].tolist()

                c = c.tolist()

                aval=[]
                asub=[]
                asub_sb = [0, 1, 2, 3, 4, 5, 6, 7, 8]
                for i in range(len(A)):
                    asub.append(asub_sb)
                    aval.append(A[i].tolist())

                numvar = len(bkx)
                numcon = len(bkc)

                task.appendcons(numcon)

                task.appendvars(numvar)

                for j in range(numvar):
                    # Set the linear term c_j in the objective.
                    task.putcj(j, c[j])
                    # Set the bounds on variable j
                    # blx[j] <= x_j <= bux[j]
                    task.putbound(mosek.accmode.var, j, bkx[j], blx[j], bux[j])
                    # Input column j of A
                    task.putacol(j,  # Variable (column) index.
                                 # Row index of non-zeros in column j.
                                 asub[j],
                                 aval[j])  # Non-zero Values of column j.

                for i in range(numcon):
                    task.putbound(mosek.accmode.con, i, bkc[i], blc[i], buc[i])

                qsubi = np.zeros([1, int(nq * (nq + 1) / 2)], dtype='int16')[0]
                qsubj = np.zeros([1, int(nq * (nq + 1) / 2)], dtype='int16')[0]
                qval = np.zeros([1, int(nq * (nq + 1) / 2)], dtype='float32')[0]

                k = 0
                tmp = 0
                for i in range(nq):
                    for j in range(tmp, nq):
                        qsubi[k] = j
                        qsubj[k] = i
                        qval[k] = Q[i, j]
                        k += 1

                    tmp += 1

                task.putqobj(qsubi.tolist(), qsubj.tolist(), qval.tolist())

                task.putobjsense(mosek.objsense.minimize)

                task.optimize()

                task.solutionsummary(mosek.streamtype.msg)

                prosta = task.getprosta(mosek.soltype.itr)
                solsta = task.getsolsta(mosek.soltype.itr)

                xx = [0.] * numvar
                task.getxx(mosek.soltype.itr, xx)

                if solsta == mosek.solsta.optimal or solsta == mosek.solsta.near_optimal:
                    print("Optimal solution: %s" % xx)
                elif solsta == mosek.solsta.dual_infeas_cer:
                    print("Primal or dual infeasibility.\n")
                elif solsta == mosek.solsta.prim_infeas_cer:
                    print("Primal or dual infeasibility.\n")
                elif solsta == mosek.solsta.near_dual_infeas_cer:
                    print("Primal or dual infeasibility.\n")
                elif solsta == mosek.solsta.near_prim_infeas_cer:
                    print("Primal or dual infeasibility.\n")
                elif mosek.solsta.unknown:
                    print("Unknown solution status")
                else:
                    print("Other solution status")

        return np.array(xx)


def esvd(e, xc, Gm, C_u, d_ieq, u_lb, u_ub, Cc, Dc, Qe, Qu ,svd_V):

    C_ieq = np.dot(C_u, Dc)
    d_ieq = d_ieq - np.dot(C_u, np.dot(Cc, xc))
    d_ieq = d_ieq.reshape((16,))
    iDc = np.linalg.inv(Dc)
    lb = np.dot(iDc, (u_lb - np.dot(Cc, xc)))
    ub = np.dot(iDc, (u_ub - np.dot(Cc, xc)))

    DctV = np.dot(Dc.T, svd_V)
    Q1 = np.dot(Gm.T, Gm) + np.dot(np.dot(svd_V, Qe), svd_V.T) + np.dot(np.dot(DctV, Qu), DctV.T)

    CctV= np.dot(Cc.T, svd_V)
    Q2 = np.dot(np.dot(np.dot(xc.T, CctV), Qu), CctV.T) - np.dot(e, Gm)
    Q2 = Q2.reshape((9, ))

    # return quadprog_solve_qp(Q1, Q2, C_ieq, d_ieq)
    return mosek_solve_qo(Q1, Q2, C_ieq, d_ieq, lb, ub)

Qe = np.array([1.0e-7, 1.0e-7, 1.0e-7, 1.0e-7, 20, 6.3, 5, 0.1, 0.1])
Qu = np.array([0.0, 0.0, 0.0, 0.0, 1.0e-7, 1.0e-7, 1.5e-4, 0.26, 0.6])

Qe = np.diag(Qe)
Qu = np.diag(Qu)

for k in range(41):
    # yh = -np.dot(svd_Up.T, y.T)

    yh = esvd(-y, xc.T, Gm, C_u, constraint_d, u_lb, u_ub, Cc, Dc, Qe, Qu, svd_V).reshape([9, 1])
    tmp_xc = np.dot(Ac, xc.T) + np.dot(Bc, yh)
    tmp_uc = np.dot(Cc, xc.T) + np.dot(Dc, yh)
    xc = tmp_xc.T
    uc = tmp_uc.T

    # tmp_u = np.dot(V_S, uc.T)
    u = uc

    y, reward, done = env.step(u)

    traj_u.append(u)
    traj_yh.append(yh.T)
    traj_y.append(y)

traj_y = np.reshape(traj_y, [41, 38])
traj_u = np.reshape(traj_u, [41, 9])
traj_yh = np.reshape(traj_yh, [41, 9])

plt.figure(1)
plt.subplot(3, 1, 1)
plt.plot(traj_u)
plt.subplot(3, 1, 2)
plt.plot(traj_y)
plt.subplot(3, 1, 3)
plt.plot(traj_yh)
plt.show()