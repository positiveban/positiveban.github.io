import numpy as np
from scipy import io


class Env:
    def __init__(self):
        super(Env, self).__init__()

        mat_file = io.loadmat('ZRM_Model.mat')
        self.A = mat_file['A']
        self.B = mat_file['B']
        self.C = mat_file['C']
        self.u0 = mat_file['u0']
        self.u0 = mat_file['d']

        self.nx = len(self.A)
        self.ny = len(self.C)
        self.nu = len(self.B[0])

        self.action_space = np.zeros([1, self.nu], dtype='float32')
        self.n_actions = len(self.action_space)
        self.x = np.zeros([1, self.nx], dtype='float32')
        self.y = np.zeros([1, self.ny], dtype='float32')
        self.n_states = len(self.y)
        self.steps = 1

    def reset(self):
        self.x = np.zeros([1, self.nx], dtype='float32')  # 초기상태로 reset
        self.y = np.zeros([1, self.ny], dtype='float32')

        return self.y

    def step(self, action):
        x = self.x

        # action 에 따른 State Transition
        y = np.dot(self.C, x.T)
        tmp = np.dot(self.A, x.T) + np.dot(self.B, action.T)
        next_x = tmp.T

        # 보상함수
        if max(abs(y)) > 80:
            done = True
            reward = 0
            self.steps = 0
        elif max(abs(y)) < max(abs(self.y)):
            done = False
            reward = +1
        else:
            reward = 0
            done = False

        self.steps += 1

        if self.steps > 200:
            done = True
            self.steps = 0

        self.x = next_x
        self.y = y

        return y, reward, done
