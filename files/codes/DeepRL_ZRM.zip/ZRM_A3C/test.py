from environment_a3c_v2 import Env

env = Env()
state = env.reset()

y, b, c= env.step(0)


max(y[1:38])