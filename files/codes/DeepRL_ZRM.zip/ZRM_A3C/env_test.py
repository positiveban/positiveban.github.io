import numpy as np
from scipy import io

mat_file = io.loadmat('ZRM_Model.mat')
A = mat_file['A']
B = mat_file['B']
C = mat_file['C']
u0 = mat_file['u0']
d = mat_file['d']
svd_U = mat_file['U']
svd_S = mat_file['S']
svd_V = mat_file['V']


ta_mins = []
ta_mins.append(1.0)
ta_mins.append(2.0)
ta_mins.append(3.0)
ta_mins.append(4.0)