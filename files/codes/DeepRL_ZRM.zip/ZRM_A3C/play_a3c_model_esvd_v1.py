import numpy as np
from keras.models import Model
from keras.layers import Dense, Flatten, Input
from environment_a3c_v_esvd import Env
import quadprog
from scipy import io
import matplotlib.pyplot as plt

global episode
episode = 0
EPISODES = 2
env_name = "ZRM"
sv = 9*2 + 10

class TestAgent:
    def __init__(self, action_size):
        self.state_size = (sv, )
        self.action_size = action_size

        self.discount_factor = 0.99
        self.no_op_steps = 30

        self.actor, self.critic = self.build_model()

    def build_model(self):
        ins = Input(shape=self.state_size)
        fc_act = Dense(50, activation='relu')(ins)
        fc_act = Dense(50, activation='relu')(fc_act)

        fc_cri = Dense(50, activation='relu')(ins)
        fc_cri = Dense(20, activation='relu')(fc_cri)

        # policy = Dense(self.action_size, activation='softmax')(fc_act)
        policy = Dense(self.action_size, activation='sigmoid')(fc_act)
        value = Dense(1, activation='linear')(fc_cri)

        actor = Model(inputs=ins, outputs=policy)
        critic = Model(inputs=ins, outputs=value)

        actor.summary()
        critic.summary()

        return actor, critic

    def get_action(self, history):
        history = np.float32(history)
        policy = self.actor.predict(history)[0]

        return policy

    def load_model(self, name):
        self.actor.load_weights(name)


def quadprog_solve_qp(P, q, G=None, h=None, A=None, b=None):
    qp_G = .5 * (P + P.T)  # make sure P is symmetric
    qp_a = -q
    if A is not None:
        qp_C = -np.vstack([A, G]).T
        qp_b = -np.hstack([b, h])
        meq = A.shape[0]
    else:  # no equality constraint
        qp_C = -G.T
        qp_b = -h
        meq = 0
    return quadprog.solve_qp(qp_G, qp_a, qp_C, qp_b, meq)[0]


def esvd(e, xc, Gm, C_u, d_ieq, u_lb, u_ub, Cc, Dc, Qe, Qu, svd_V):
    C_ieq = np.dot(C_u, Dc)
    d_ieq = d_ieq - np.dot(C_u, np.dot(Cc, xc))
    d_ieq = d_ieq.reshape((16,))

    iDc = np.linalg.inv(Dc)
    lb = np.dot(iDc, (u_lb - np.dot(Cc, xc)))
    ub = np.dot(iDc, (u_ub - np.dot(Cc, xc)))

    DctV = np.dot(Dc.T, svd_V)
    Q1 = np.dot(Gm.T, Gm) + np.dot(np.dot(svd_V, Qe), svd_V.T) + np.dot(np.dot(DctV, Qu), DctV.T)

    CctV = np.dot(Cc.T, svd_V)
    Q2 = np.dot(np.dot(np.dot(xc.T, CctV), Qu), CctV.T) - np.dot(e, Gm)
    Q2 = Q2.reshape((9,))

    Iep = np.identity(len(lb))
    G = np.reshape(np.append(np.append(C_ieq, Iep), -Iep), [len(C_ieq) + len(lb) * 2, len(lb)])
    d = np.append(np.append(d_ieq, ub), -lb)

    return quadprog_solve_qp(Q1, Q2, G, d)


if __name__ == "__main__":

    mat_file2 = io.loadmat('ESVD_Control.mat')

    Ac, Bc, Cc, Dc = mat_file2['Ac'], mat_file2['Bc'], mat_file2['Cc'], mat_file2['Dc']
    Gm, all_PolyGm = mat_file2['Gm'], mat_file2['all_PolyGm']
    Gm = Gm[:, 0:9]

    svd_U, svd_S, svd_V = np.linalg.svd(Gm)
    svd_S = np.diag(svd_S)
    svd_V = svd_V.T
    svd_Up = svd_U[:, 0:9]

    constraint_d, u_lb, u_ub, C_u = mat_file2['constraint_d'], mat_file2['u_lb'], mat_file2['u_ub'], mat_file2['C_u']

    env = Env()
    agent = TestAgent(action_size=10)
    agent.load_model("save_model/zrm_a3c_esvd_v1_actor.h5")

    Qe0 = np.array([1.0e-7, 1.0e-7, 1.0e-7, 1.0e-7, 20, 6.3, 5, 0.1, 0.1])
    Qu0 = np.array([0.0, 0.0, 0.0, 0.0, 1.0e-7, 1.0e-7, 1.5e-4, 0.26, 0.6])

    step = 0

    xc = np.zeros([1, 9], dtype='float32')
    uc = np.zeros([1, 9], dtype='float32')

    done = False

    score = 0
    observe = env.reset()
    next_observe = observe

    traj_y, traj_yh, traj_u = [], [], []

    for k in range(41):
        step += 1
        observe = next_observe

        yh_svd = np.dot(svd_Up.T, observe.T)

        state = np.concatenate(
            (yh_svd.T / 20, uc, np.reshape(Qe0[4: 9], [1, 5]) / 10, np.reshape(Qu0[4: 9], [1, 5]) / 10), axis=1)

        policy = agent.get_action(state)

        dQe = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        dQu = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        dQe[4: 9] = (policy[0:5]-0.5)*.5
        dQu[4: 9] = (policy[5:10]-0.5)*.5

        Qe0 += dQe
        Qu0 += dQu

        for i in range(4, 9):
            if Qe0[i] <= 0:
                Qe0[i] = 0

            if Qu0[i] <= 0:
                Qu0[i] = 0

        Qe = np.diag(Qe0)
        Qu = np.diag(Qu0)

        # Qe = np.array([1.0e-7, 1.0e-7, 1.0e-7, 1.0e-7, 20, 6.3, 5, 0.1, 0.1])
        # Qu = np.array([0.0, 0.0, 0.0, 0.0, 1.0e-7, 1.0e-7, 1.5e-4, 0.26, 0.6])

        # Qe = np.diag(Qe)
        # Qu = np.diag(Qu)

        yh = esvd(-observe, xc.T, Gm, C_u, constraint_d, u_lb, u_ub, Cc, Dc, Qe, Qu, svd_V).reshape([9, 1])
        tmp_xc = np.dot(Ac, xc.T) + np.dot(Bc, yh)
        tmp_uc = np.dot(Cc, xc.T) + np.dot(Dc, yh)
        xc = tmp_xc.T
        uc = tmp_uc.T

        # tmp_u = np.dot(V_S, uc.T)

        # 선택한 행동으로 한 스텝을 실행
        next_observe, reward, done = env.step(uc)

        traj_u.append(uc)
        traj_yh.append(yh.T)
        traj_y.append(next_observe)

        score += reward

        # if done, plot the score over episodes
        if k > 200:
            episode += 1
            print("episode:", episode, "  score:", score, "  step:", step)
            step = 0
            xc = np.zeros([1, 9], dtype='float32')
            uc = np.zeros([1, 9], dtype='float32')

    traj_y = np.reshape(traj_y, [41, 38])
    traj_u = np.reshape(traj_u, [41, 9])
    traj_yh = np.reshape(traj_yh, [41, 9])

    plt.figure(1)
    plt.subplot(3, 1, 1)
    plt.plot(traj_u)
    plt.ylabel('Inputs')
    plt.subplot(3, 1, 2)
    plt.plot(traj_y)
    plt.ylabel('y')
    plt.subplot(3, 1, 3)
    plt.plot(traj_yh)
    plt.ylabel('\hat{y}')

    plt.figure(2)
    p1, = plt.plot(traj_y[0][6:32], label='Initial strip shape')
    p2, = plt.plot(traj_y[40][6:32], label='Final strip shape')
    plt.legend(handles=[p1, p2])

    plt.show()

