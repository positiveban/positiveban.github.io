from keras.layers import Dense, Input
#from keras.optimizers import RMSprop
from keras.optimizers import Adam
from keras import backend as K
from keras.models import Model
import tensorflow as tf
import numpy as np
import threading
import time
import pylab
from environment_a3c_v_esvd import Env
import matplotlib.pyplot as plt
import quadprog
from scipy import io

# 멀티쓰레딩을 위한 글로벌 변수
global episode
global episodes, y_mins, avg_ymins, avg_scores, scores


episode = 0
EPISODES = 50000
# 환경 생성
env_name = "ZRM"
sv = 9*2 + 10

# A3CAgent 클래스(글로벌신경망)
class A3CAgent:
    def __init__(self, action_size):
        # 상태크기와 행동크기를 갖고옴
        self.state_size = (sv, )
        self.action_size = action_size
        # A3C 하이퍼파라미터
        self.discount_factor = 0.99
        self.no_op_steps = 30
        self.actor_lr = 1e-4
        self.critic_lr = 1e-4
        # 쓰레드의 갯수
        self.threads = 8

        self.epsilon = 1.0
        self.epsilon_decay = 0.95
        self.epsilon_min = 0.01

        # 정책신경망과 가치신경망을 생성
        self.actor, self.critic = self.build_model()
        # 정책신경망과 가치신경망을 업데이트하는 함수 생성
        self.optimizer = [self.actor_optimizer(), self.critic_optimizer()]

        # 텐서보드 설정
        self.sess = tf.InteractiveSession()
        K.set_session(self.sess)
        self.sess.run(tf.global_variables_initializer())

        self.summary_placeholders, self.update_ops, self.summary_op = \
            self.setup_summary()
        self.summary_writer = \
            tf.summary.FileWriter('summary/zrm_a3c_esvd', self.sess.graph)

    # 쓰레드를 만들어 학습을 하는 함수
    def train(self):
        # 쓰레드 수만큼 Agent 클래스 생성
        agents = [Agent(self.action_size, self.state_size,
                        [self.actor, self.critic], self.sess,
                        self.optimizer, self.discount_factor,
                        [self.summary_op, self.summary_placeholders,
                         self.update_ops, self.summary_writer])
                  for _ in range(self.threads)]

        # 각 쓰레드 시작
        for agent in agents:
            time.sleep(1)
            agent.start()

        # 10분(600초)에 한번씩 모델을 저장
        while True:
            time.sleep(60 * 5)
            self.save_model("./save_model/zrm_a3c_esvd_v1")

    # 정책신경망과 가치신경망을 생성
    def build_model(self):
        ins = Input(shape=self.state_size)
        fc_act = Dense(50, activation='relu')(ins)
        fc_act = Dense(50, activation='relu')(fc_act)

        fc_cri = Dense(50, activation='relu')(ins)
        fc_cri = Dense(20, activation='relu')(fc_cri)

        # policy = Dense(self.action_size, activation='softmax')(fc_act)
        policy = Dense(self.action_size, activation='sigmoid')(fc_act)
        value = Dense(1, activation='linear')(fc_cri)

        actor = Model(inputs=ins, outputs=policy)
        critic = Model(inputs=ins, outputs=value)

        # 가치와 정책을 예측하는 함수를 만들어냄
        actor._make_predict_function()
        critic._make_predict_function()

        actor.summary()
        critic.summary()

        return actor, critic

    # 정책신경망을 업데이트하는 함수
    def actor_optimizer(self):
        action = K.placeholder(shape=[None, self.action_size])
        advantages = K.placeholder(shape=[None, ])

        policy = self.actor.output

        # 정책 크로스 엔트로피 오류함수
        action_prob = K.sum(action * policy, axis=1)
        cross_entropy = K.log(action_prob + 1e-10) * advantages
        cross_entropy = -K.sum(cross_entropy)

        # 탐색을 지속적으로 하기 위한 엔트로피 오류
        entropy = K.sum(policy * K.log(policy + 1e-10), axis=1)
        entropy = K.sum(entropy)

        # 두 오류함수를 더해 최종 오류함수를 만듬
        loss = cross_entropy + self.epsilon * entropy

        # optimizer = RMSprop(lr=self.actor_lr, rho=0.99, epsilon=0.01)
        optimizer = Adam(lr=self.actor_lr, beta_1=0.9, beta_2=0.999, epsilon=1e-08, decay=0.0)
        updates = optimizer.get_updates(self.actor.trainable_weights, [], loss)
        train = K.function([self.actor.input, action, advantages],
                           [loss], updates=updates)
        return train

    # 가치신경망을 업데이트하는 함수
    def critic_optimizer(self):
        discounted_prediction = K.placeholder(shape=(None,))

        value = self.critic.output

        # [반환값 - 가치]의 제곱을 오류함수로 함
        loss = K.mean(K.square(discounted_prediction - value))

        # optimizer = RMSprop(lr=self.critic_lr, rho=0.99, epsilon=0.01)
        optimizer = Adam(lr=self.critic_lr, beta_1=0.9, beta_2=0.999, epsilon=1e-08, decay=0.0)
        updates = optimizer.get_updates(self.critic.trainable_weights, [], loss)
        train = K.function([self.critic.input, discounted_prediction],
                           [loss], updates=updates)
        return train

    def load_model(self, name):
        self.actor.load_weights(name + "_actor.h5")
        self.critic.load_weights(name + "_critic.h5")

    def save_model(self, name):
        self.actor.save_weights(name + "_actor.h5")
        self.critic.save_weights(name + "_critic.h5")

    # 각 에피소드 당 학습 정보를 기록
    def setup_summary(self):
        episode_total_reward = tf.Variable(0.)
        episode_avg_max_q = tf.Variable(0.)
        episode_duration = tf.Variable(0.)

        tf.summary.scalar('Total Reward/Episode', episode_total_reward)
        tf.summary.scalar('Average Max Prob/Episode', episode_avg_max_q)
        tf.summary.scalar('Duration/Episode', episode_duration)

        summary_vars = [episode_total_reward,
                        episode_avg_max_q,
                        episode_duration]

        summary_placeholders = [tf.placeholder(tf.float32)
                                for _ in range(len(summary_vars))]
        update_ops = [summary_vars[i].assign(summary_placeholders[i])
                      for i in range(len(summary_vars))]
        summary_op = tf.summary.merge_all()
        return summary_placeholders, update_ops, summary_op

    def get_action(self, history):
        history = np.float32(history)
        policy = self.local_actor.predict(history)[0]
        action_index = np.random.choice(self.action_size, 1, p=policy)[0]

        return action_index, policy


# 액터러너 클래스(쓰레드)
class Agent(threading.Thread):
    def __init__(self, action_size, state_size, model, sess,
                 optimizer, discount_factor, summary_ops):
        threading.Thread.__init__(self)

        # A3CAgent 클래스에서 상속
        self.action_size = action_size
        self.state_size = state_size
        self.actor, self.critic = model
        self.sess = sess
        self.optimizer = optimizer
        self.discount_factor = discount_factor
        [self.summary_op, self.summary_placeholders,
         self.update_ops, self.summary_writer] = summary_ops

        self.epsilon = 1.0
        self.epsilon_decay = 0.9995
        self.epsilon_min = 0.01

        # 지정된 타임스텝동안 샘플을 저장할 리스트
        self.states, self.actions, self.rewards = [], [], []

        # 로컬 모델 생성
        self.local_actor, self.local_critic = self.build_local_model()

        self.avg_p_max = 0
        self.avg_loss = 0

        # 모델 업데이트 주기
        self.t_max = 20
        self.t = 0

    def run(self):
        global episode, episodes, y_mins, avg_ymins, avg_scores, scores
        global Ac, Bc, Cc, Dc, Gm, svd_U, svd_S, svd_V, svd_Up, constraint_d, u_lb, u_ub, C_u

        # env = gym.make(env_name)
        env = Env()
        step = 0
        xc = np.zeros([1, 9], dtype='float32')
        uc = np.zeros([1, 9], dtype='float32')

        while episode < EPISODES:
            done = False

            score = 0

            Qe0 = np.array([1.0e-7, 1.0e-7, 1.0e-7, 1.0e-7, 20, 6.3, 5, 0.1, 0.1])
            Qu0 = np.array([0.0, 0.0, 0.0, 0.0, 1.0e-7, 1.0e-7, 1.5e-4, 0.26, 0.6])

            observe = env.reset()

            next_observe = observe

            while not done:
                step += 1
                self.t += 1
                observe = next_observe

                yh_svd = np.dot(svd_Up.T, observe.T)

                state = np.concatenate(
                    (yh_svd.T/20, uc, np.reshape(Qe0[4: 9], [1, 5])/10, np.reshape(Qu0[4: 9], [1, 5])/10), axis=1)

                policy = self.get_action(state)

                dQe = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
                dQu = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
                dQe[4: 9] = (policy[0:5]-0.5)*.5
                dQu[4: 9] = (policy[5:10]-0.5)*.5

                Qe0 += dQe
                Qu0 += dQu

                for i in range(4, 9):
                    if Qe0[i] <= 0:
                        Qe0[i] = 0

                    if Qu0[i] <= 0:
                        Qu0[i] = 0

                Qe = np.diag(Qe0)
                Qu = np.diag(Qu0)

                yh = self.esvd(-observe, xc.T, Gm, C_u, constraint_d, u_lb, u_ub, Cc, Dc, Qe, Qu, svd_V).reshape([9, 1])
                tmp_xc = np.dot(Ac, xc.T) + np.dot(Bc, yh)
                tmp_uc = np.dot(Cc, xc.T) + np.dot(Dc, yh)
                xc = tmp_xc.T
                uc = tmp_uc.T

                # tmp_u = np.dot(V_S, uc.T)

                # 선택한 행동으로 한 스텝을 실행
                next_observe, reward, done = env.step(uc)

                score += reward
                # reward = np.clip(reward, -1., 1.)

                # 샘플을 저장
                self.append_sample(state, policy, reward)

                # 에피소드가 끝나거나 최대 타임스텝 수에 도달하면 학습을 진행
                if self.t >= self.t_max or done:
                    self.train_model(done)
                    self.update_local_model()
                    self.t = 0

                if done:
                    # 각 에피소드 당 학습 정보를 기록
                    episode += 1
                    xc = np.zeros([1, 9], dtype='float32')
                    uc = np.zeros([1, 9], dtype='float32')
                    # print("episode:", episode, "  score:", score, "  step:",
                    #      step, "epsilon", self.epsilon)
                    y_mins.append(env.min_y)
                    scores.append(score)

                    if episode % 20 == 0:
                        avg_ymins.append(np.mean(y_mins))
                        episodes.append(episode)
                        avg_scores.append(np.mean(scores))
                        y_mins = []
                        scores = []

                    if episode % 50 == 0:
                        pylab.figure(1)
                        pylab.plot(episodes, avg_ymins, 'b')
                        pylab.savefig("./save_graph/zrm_a3c_esvd_ymins.png")
                        pylab.figure(2)
                        pylab.plot(episodes, avg_scores, 'r')
                        pylab.savefig("./save_graph/zrm_a3c_esvd_scores.png")

                        print("episode:", episode, "  score:", score, "  step:", step, " y_min:", env.min_y,
                              " epsilon", self.epsilon)

                    step = 0

    # k-스텝 prediction 계산
    def discounted_prediction(self, rewards, done):
        discounted_prediction = np.zeros_like(rewards)
        running_add = 0

        if not done:
            running_add = self.critic.predict(np.reshape(
                self.states[-1], [1, sv]))[0]

        for t in reversed(range(0, len(rewards))):
            running_add = running_add * self.discount_factor + rewards[t]
            discounted_prediction[t] = running_add
        return discounted_prediction

    # 정책신경망과 가치신경망을 업데이트
    def train_model(self, done):
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

        discounted_prediction = self.discounted_prediction(self.rewards, done)

        states = np.zeros((len(self.states), sv))
        for i in range(len(self.states)):
            states[i] = self.states[i]

        states = np.float32(states)

        values = self.critic.predict(states)
        values = np.reshape(values, len(values))

        advantages = discounted_prediction - values

        self.optimizer[0]([states, self.actions, advantages])
        self.optimizer[1]([states, discounted_prediction])
        self.states, self.actions, self.rewards = [], [], []

    # 로컬신경망을 생성하는 함수
    def build_local_model(self):
        ins = Input(shape=self.state_size)

        fc_act = Dense(50, activation='relu')(ins)
        fc_act = Dense(50, activation='relu')(fc_act)

        fc_cri = Dense(50, activation='relu')(ins)
        fc_cri = Dense(20, activation='relu')(fc_cri)

        # policy = Dense(self.action_size, activation='softmax')(fc_act)
        policy = Dense(self.action_size, activation='sigmoid')(fc_act)
        value = Dense(1, activation='linear')(fc_cri)

        local_actor = Model(inputs=ins, outputs=policy)
        local_critic = Model(inputs=ins, outputs=value)

        local_actor._make_predict_function()
        local_critic._make_predict_function()

        local_actor.set_weights(self.actor.get_weights())
        local_critic.set_weights(self.critic.get_weights())

        local_actor.summary()
        local_critic.summary()

        return local_actor, local_critic

    # 로컬신경망을 글로벌신경망으로 업데이트
    def update_local_model(self):
        self.local_actor.set_weights(self.actor.get_weights())
        self.local_critic.set_weights(self.critic.get_weights())

    # 정책신경망의 출력을 받아서 확률적으로 행동을 선택
    def get_action(self, history):
        history = np.float32(history)
        policy = self.local_actor.predict(history)[0]
        # action_index = np.random.choice(self.action_size, 1, p=policy)[0]

        return policy

    # 샘플을 저장
    def append_sample(self, history, action, reward):
        self.states.append(history)
        self.actions.append(action)
        self.rewards.append(reward)

    def quadprog_solve_qp(self, P, q, G=None, h=None, A=None, b=None):
        qp_G = .5 * (P + P.T)  # make sure P is symmetric
        qp_a = -q
        if A is not None:
            qp_C = -np.vstack([A, G]).T
            qp_b = -np.hstack([b, h])
            meq = A.shape[0]
        else:  # no equality constraint
            qp_C = -G.T
            qp_b = -h
            meq = 0
        return quadprog.solve_qp(qp_G, qp_a, qp_C, qp_b, meq)[0]

    def esvd(self, e, xc, Gm, C_u, d_ieq, u_lb, u_ub, Cc, Dc, Qe, Qu, svd_V):
        C_ieq = np.dot(C_u, Dc)
        d_ieq = d_ieq - np.dot(C_u, np.dot(Cc, xc))
        d_ieq = d_ieq.reshape((16,))
        iDc = np.linalg.inv(Dc)
        lb = np.dot(iDc, (u_lb - np.dot(Cc, xc)))
        ub = np.dot(iDc, (u_ub - np.dot(Cc, xc)))

        DctV = np.dot(Dc.T, svd_V)
        Q1 = np.dot(Gm.T, Gm) + np.dot(np.dot(svd_V, Qe), svd_V.T) + np.dot(np.dot(DctV, Qu), DctV.T)

        CctV = np.dot(Cc.T, svd_V)
        Q2 = np.dot(np.dot(np.dot(xc.T, CctV), Qu), CctV.T) - np.dot(e, Gm)
        Q2 = Q2.reshape((9,))

        Iep = np.identity(len(lb))
        G = np.reshape(np.append(np.append(C_ieq, Iep), -Iep), [len(C_ieq) + len(lb) * 2, len(lb)])
        d = np.append(np.append(d_ieq, ub), -lb)

        return self.quadprog_solve_qp(Q1, Q2, G, d)


if __name__ == "__main__":
    global episodes, y_mins, avg_ymins, avg_scores, scores
    global Ac, Bc, Cc, Dc, Gm, svd_U, svd_S, svd_V, svd_Up, constraint_d, u_lb, u_ub, C_u
    episodes, y_mins, avg_ymins , avg_scores, scores = [], [], [], [], []

    mat_file2 = io.loadmat('ESVD_Control.mat')

    Ac, Bc, Cc, Dc = mat_file2['Ac'], mat_file2['Bc'], mat_file2['Cc'], mat_file2['Dc']
    Gm, all_PolyGm = mat_file2['Gm'], mat_file2['all_PolyGm']
    Gm = Gm[:, 0:9]

    svd_U, svd_S, svd_V = np.linalg.svd(Gm)
    svd_S = np.diag(svd_S)
    svd_V = svd_V.T
    svd_Up = svd_U[:, 0:9]

    constraint_d, u_lb, u_ub, C_u = mat_file2['constraint_d'], mat_file2['u_lb'], mat_file2['u_ub'], mat_file2['C_u']

    global_agent = A3CAgent(action_size=10)
    global_agent.train()