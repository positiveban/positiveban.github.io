from environment_a3c_v_esvd import Env
import matplotlib.pyplot as plt
import numpy as np

env = Env()
state = env.reset()
actions = np.zeros([1, 9], dtype='float32')
y = env.step(actions)

plt.plot(y[0][0])
plt.show()