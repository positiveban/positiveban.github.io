from environment_a3c_v_esvd import Env
import matplotlib.pyplot as plt
import numpy as np
from scipy import io
import quadprog

mat_file = io.loadmat('ZRM_Model.mat')
mat_file2 = io.loadmat('ESVD_Control.mat')

Ac, Bc, Cc, Dc = mat_file2['Ac'], mat_file2['Bc'], mat_file2['Cc'], mat_file2['Dc']

Gm, all_PolyGm = mat_file2['Gm'], mat_file2['all_PolyGm']
Gm = Gm[:, 0:9]

svd_U, svd_S, svd_V = np.linalg.svd(Gm)
svd_S = np.diag(svd_S)
svd_V = svd_V.T

constraint_d, u_lb, u_ub, C_u = mat_file2['constraint_d'], mat_file2['u_lb'], mat_file2['u_ub'], mat_file2['C_u']

env = Env()
y = env.reset()
actions = np.zeros([1, 9], dtype='float32')
xc = np.zeros([1, 9], dtype='float32')

svd_Up = svd_U[:, 0:9]

traj_y, traj_yh, traj_u = [], [], []
V_S = np.dot(svd_V[:, 0:9], np.linalg.inv(svd_S[0:9, 0:9]))


def quadprog_solve_qp(P, q, G=None, h=None, A=None, b=None):
    qp_G = .5 * (P + P.T)   # make sure P is symmetric
    qp_a = -q
    if A is not None:
        qp_C = -np.vstack([A, G]).T
        qp_b = -np.hstack([b, h])
        meq = A.shape[0]
    else:  # no equality constraint
        qp_C = -G.T
        qp_b = -h
        meq = 0
    return quadprog.solve_qp(qp_G, qp_a, qp_C, qp_b, meq)[0]


def esvd(e, xc, Gm, C_u, d_ieq, u_lb, u_ub, Cc, Dc, Qe, Qu ,svd_V):

    C_ieq = np.dot(C_u, Dc)
    d_ieq = d_ieq - np.dot(C_u, np.dot(Cc, xc))
    d_ieq = d_ieq.reshape((16,))
    iDc = np.linalg.inv(Dc)
    lb = np.dot(iDc, (u_lb - np.dot(Cc, xc)))
    ub = np.dot(iDc, (u_ub - np.dot(Cc, xc)))

    DctV = np.dot(Dc.T, svd_V)
    Q1 = np.dot(Gm.T, Gm) + np.dot(np.dot(svd_V, Qe), svd_V.T) + np.dot(np.dot(DctV, Qu), DctV.T)

    CctV= np.dot(Cc.T, svd_V)
    Q2 = np.dot(np.dot(np.dot(xc.T, CctV), Qu), CctV.T) - np.dot(e, Gm)
    Q2 = Q2.reshape((9, ))

    Iep = np.identity(len(lb))
    G = np.reshape(np.append(np.append(C_ieq, Iep), -Iep), [len(C_ieq) + len(lb)*2, len(lb)])
    d = np.append(np.append(d_ieq, ub), -lb)

    return quadprog_solve_qp(Q1, Q2, G, d)


Qe = np.array([1.0e-7, 1.0e-7, 1.0e-7, 1.0e-7, 20, 6.3, 5, 0.1, 0.1]) # needed to be tuned
Qu = np.array([0.0, 0.0, 0.0, 0.0, 1.0e-7, 1.0e-7, 1.5e-4, 0.26, 0.6]) # needed to be tuned

Qe = np.diag(Qe)
Qu = np.diag(Qu)

for k in range(41):
    # yh = -np.dot(svd_Up.T, y.T) # for SVD

    yh = esvd(-y, xc.T, Gm, C_u, constraint_d, u_lb, u_ub, Cc, Dc, Qe, Qu, svd_V).reshape([9, 1])
    tmp_xc = np.dot(Ac, xc.T) + np.dot(Bc, yh)
    tmp_uc = np.dot(Cc, xc.T) + np.dot(Dc, yh)
    xc = tmp_xc.T
    uc = tmp_uc.T

    # tmp_u = np.dot(V_S, uc.T) # for SVD
    u = uc

    y, reward, done = env.step(u)

    traj_u.append(u)
    traj_yh.append(yh.T)
    traj_y.append(y)

traj_y = np.reshape(traj_y, [41, 38])
traj_u = np.reshape(traj_u, [41, 9])
traj_yh = np.reshape(traj_yh, [41, 9])

plt.figure(1)
plt.subplot(3, 1, 1)
plt.plot(traj_u)
plt.subplot(3, 1, 2)
plt.plot(traj_y)
plt.subplot(3, 1, 3)
plt.plot(traj_yh)

plt.figure(2)
p1, = plt.plot(traj_y[0][6:32], label='Initial strip shape')
p2, = plt.plot(traj_y[40][6:32], label='Final strip shape')
plt.legend(handles=[p1, p2])
plt.show()