clear
% inverted pendulum example
global g m l M a

g=9.8;
m=2;
l=2;
M=3;
a=1/(m+M);

x0=[0.001 0];
tspan=[0 4];

[t1,x1]=ode45(@myode,tspan,x0); % fuzzy system
[t2,x2]=ode45(@myode2,tspan,x0); % nonlinear system

plot(t2,x2,'linewidth',2)
hold on
plot(t1,x1,'--','linewidth',2)