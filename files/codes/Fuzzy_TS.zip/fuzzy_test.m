clear

x=[1;2];u=0;

% model parameters
g=9.8;
m=2;
l=2;
M=3;
a=1/(m+M);
beta=cos(88*pi/180);

M1=trimf(x(1),[-pi/2 0 pi/2]);
M2=trimf(x(1),[0 pi/2 pi])+trimf(x(1),[-pi -pi/2 0]);
M3=trimf(x(1),[pi/2 pi pi])+trimf(x(1),[-pi -pi -pi/2]);

A1=[0 1;g/(4*l/3-a*m*l) 0];
B1=[0;-a/(4*l/3-a*m*l)];

A2=[0 1;2*g/pi/(4*l/3-a*m*l*beta*beta) 0];
B2=[0;-a*beta/(4*l/3-a*m*l*beta*beta)];

A3=[0 1;0 0]; B3=[0;-a/(4*l/3-a*m*l)];

dxdt_f=(M1*(A1*x+B1*u)+M2*(A2*x+B2*u)+M3*(A3*x+B3*u))/(M1+M2+M3)
