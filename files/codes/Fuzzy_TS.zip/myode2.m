function dxdt=myode2(t,x)
global g m l M a

u=0;
dxdt=[x(2);(g*sin(x(1))-a*m*l*x(2)*x(2)*sin(2*x(1))/2-a*cos(x(1))*u)/(4*l/3-a*m*l*cos(x(1))^2)];
end