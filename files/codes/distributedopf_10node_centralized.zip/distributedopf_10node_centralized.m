clear all
clc
baseMVA = 1; % 1MVA
basekV = 4.16;

Zbase = basekV^2/baseMVA;

to_real_form = @(M) [real(M + M.') imag(M.' - M);  imag(M - M.') real(M + M.')];
to_real_form2 = @(M) [imag(M + M.') real(M - M.');  real(M.' - M) imag(M + M.')];
to_real_form3 = @(M) [real(M) imag(M);  imag(M) real(M)];

% the number of buses
N = 10;
network_top = [1,2;2,3;2,4;3,6;3,8;4,5;6,7;8,9;9,10];

% spot loads
PL = [0 0.05 0 .13 .13 .11 .11 0 .09 .09]'/baseMVA; %kW
% PL = kron(PL,ones(3,1));
QL = [0 .02 0 .082 .082 .06 .06 0 .03 .03]'/baseMVA; %kVar
% QL = kron(QL,ones(3,1));

% Generator nodes
S=[5,7];

% Constraints on Active / Reactive Powers and Voltages
Pmin=zeros(N,1);
Pmax=zeros(N,1);
Qmin=zeros(N,1);
Qmax=zeros(N,1);

Pmin(S)=0;
Pmax(S)=.05/baseMVA;
Qmin(S)=0;
Qmax(S)=0;
Vmin=0.95*ones(N,1);
Vmax=1.05*ones(N,1);

% construct admittance matrix
% line impedances
% Z = [0.0693+1j*0.2036 0.0312+1j*0.1003 0.0316+1j*0.0847
%    0.0312+1j*0.1003 0.0675+1j*0.2096 0.0307+1j*0.077
%    0.0316+1j*0.0847 0.0307+1j*0.077 0.0683+1j*0.2070];
Z=(0.0693+1j*0.2036)/Zbase;
g=real(inv(Z));
b=-imag(inv(Z));
g/b
Mspa = sparse(network_top(:,1),network_top(:,2),ones(size(network_top,1),1),N,N);
Mspa = (Mspa+Mspa');

offdiagcomp = kron(Mspa,-inv(Z));
diagcomp = kron(diag(sum(Mspa)),inv(Z));
Y = diagcomp + offdiagcomp;

V = sdpvar(N*2,N*2, 'symmetric');
V(1,1)=1.00^2;
V(11,11)=0;

for n=1:N
    y=Y(n,:);
    e=zeros(length(y),1);
    e(n,1) = 1;
    Yk=sparse(e*y);
    Phi(n).P = to_real_form(Yk)*(1/2);
    Phi(n).Q = to_real_form2(Yk)*(-1/2);
    Phi(n).V = to_real_form3((e*e'));
end

% calc cost
c0=40;
c1=40;
c=[0 0 0 c1 0 c1 0 0 0];
cs=[c0 c];

cost=0;
for s=[1,S]
    tmp=trace(Phi(s).P*V);
    cost=cost+cs(s)*tmp;
end

% set sdp constraints
sdpconstr=[];
for n=S
    sdpconstr=[sdpconstr,...
        Pmin(n) - trace(Phi(n).P*V) - PL(n) <= 0,...
        trace(Phi(n).P*V) + PL(n) - Pmax(n) <= 0,...
        Qmin(n) - trace(Phi(n).Q*V) - QL(n) <= 0,...
        trace(Phi(n).Q*V) + QL(n) - Qmax(n) <= 0,...
        ];
end
for n=1:N
    sdpconstr=[sdpconstr,...
        Vmin(n)^2 - trace(Phi(n).V*V) <= 0,...
        trace(Phi(n).V*V) - Vmax(n)^2 <= 0
        ];
end
for n=setdiff(2:N,S)
    sdpconstr=[sdpconstr,...
%         trace(Phi(n).P*V) + PL(n) == 0,...
%         trace(Phi(n).Q*V) + QL(n) == 0
        [-1 trace(Phi(n).P*V) + PL(n);trace(Phi(n).P*V) + PL(n) -eps] <= 0,...
        [-1 trace(Phi(n).Q*V) + QL(n);trace(Phi(n).Q*V) + QL(n) -eps] <= 0
        ];
end
sdpconstr=[sdpconstr,V >= 0];

opt=sdpsettings('solver','mosek','verbose',1);
diagnosis=optimize(sdpconstr,cost,opt)
V=double(V);
[Uu,Ss,Vv] = svd(V);
figure(1),bar(sqrt(sum(Ss))),ylabel('$\sigma$ of V','interpreter','latex')
% Vc=double(to_complex_form(V));
% V=double(V);
% figure(1),bar(sqrt(Ss)),ylabel('$\sigma$ of V','interpreter','latex')
a=checkset(sdpconstr)';
% for n=S
%         [Pmin(n) - trace(Phi(n).P*V) - PL(n) <= 0,...
%         trace(Phi(n).P*V) + PL(n) - Pmax(n) <= 0,...
%         Qmin(n) - trace(Phi(n).Q*V) - QL(n) <= 0,...
%         trace(Phi(n).Q*V) + QL(n) - Qmax(n) <= 0,...
%         ]
% end
% for n=setdiff(1:N,S)
%     [
%         trace(Phi(n).P*V) + PL(n),...
%         trace(Phi(n).Q*V) + QL(n)
% %         [-1 trace(Phi(n).P*V) + PL(n);trace(Phi(n).P*V) + PL(n) -1E-11] <= 0,...
% %         [-1 trace(Phi(n).Q*V) + QL(n);trace(Phi(n).Q*V) + QL(n) -1E-11] <= 0
%         ]
% end

Vcc=Uu(:,1)*sqrt(Ss(1,1));
Vccc=-(Vcc(1:10)+1j*Vcc(11:20));
St=Vccc.*conj(Y*Vccc);
SL=(PL+1j*QL).';
Pg=real(St+SL.');
Qg=imag(St+SL.');
disp(['Voltage obtained (p.u.)'])
Vccc
disp(['Active Power Generations (MW)'])
Pg
disp(['Reactive Power Generations (MW)'])
Qg
disp('Active Power Losses(MW)')
sum(Pg)-sum(PL)
disp('Reactive Power Losses(MW)')
sum(Qg)-sum(QL)