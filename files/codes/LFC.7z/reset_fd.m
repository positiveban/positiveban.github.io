clear all
clc

data=xlsread('LFC2001_parameters.xlsx');

Rate=data(1,:);
D=data(2,:);
Tp=data(3,:);
Tt=data(4,:);
Th=data(5,:);
R=data(6,:);
B=data(7,:);
alp=data(8,:);
bta=[.5 .5 .5
    1 1 1
    500 500 500];

% sys(1).k=[-3.27E-4 -0.3334];
% sys(2).k=[-6.96E-4 -0.3435];
% sys(3).k=[-1.6E-4 -0.3398];
sys(1).k=[-3.27E-4 -0.3334];
sys(2).k=[-6.96E-4 -0.3435];
sys(3).k=[-1.6E-4 -0.3398];

Tij=[0    0.2   0.25
     0.2  0     0.12
     0.25 0.12  0];
 
 sumTij=sum(Tij);
 
for i=1:3
    sys(i).d=sum(D((i-1)*3+1:i*3));
    sys(i).tp=sum(Tp((i-1)*3+1:i*3));
    sys(i).bias=sum(B((i-1)*3+1:i*3));
    sys(i).area = [-sys(i).d/sys(i).tp  -1/sys(i).tp  0
                   2*pi*sumTij(i)          0             0
                   sys(i).bias           1            0];
    sys(i).mp=[];
    for j=1:3
        sys(i).mp=[sys(i).mp,[1/sys(i).tp 0;0 0;0 0]];
    end
    sys(i).droop=[];
    for j=1:3
        sys(i).droop=[sys(i).droop;[0 0 0;-1/R((i-1)*3+j)/Th((i-1)*3+j) 0 0]];
    end
    sys(i).tg=[];
    for j=1:3
        sys(i).tg=blkdiag(sys(i).tg,[-1/Tt((i-1)*3+j) 1/Tt((i-1)*3+j);0 -1/Th((i-1)*3+j)]);
    end
    sys(i).bus=[];
    for j=1:3
        sys(i).bus=[sys(i).bus;alp((i-1)*3+j)*[0;1/Th((i-1)*3+j)]];
    end
    sys(i).bws=[-1/sys(i).tp;0;0];
    for j=1:3
        sys(i).aij(:,:,j)=[0;-2*pi;0;zeros(6,1)]*[Tij(i,j), zeros(1,8)];
    end
       
    sys(i).a=[sys(i).area, sys(i).mp
              sys(i).droop,sys(i).tg];
    sys(i).bu=[zeros(3,1);sys(i).bus];
    sys(i).bw=[sys(i).bws;zeros(6,1)];
    sys(i).cs=[sys(i).bias 1  0
               0           0  1];
    sys(i).c=[sys(i).cs,zeros(2,6)];
    
    sys(i).cinfs=[bta(1,i) 0 0;0 0 bta(2,i);0 0 0];
    sys(i).cinf=[sys(i).cinfs,zeros(3,6)];
    
    sys(i).dinf=[0;0;bta(3,i)];
    
    sys(i).outs=[1 0 0;sys(i).bias 1 0];
    sys(i).out=[sys(i).outs,zeros(2,6)];
    
    sys(i).cps=[sys(i).bias 1 0];
    sys(i).cp=[sys(i).cps,zeros(1,6)];
    
    sys(i).acl=sys(i).a+sys(i).bu*sys(i).k*sys(i).c;
end
A=[sys(1).acl sys(1).aij(:,:,2) sys(1).aij(:,:,3)
   sys(2).aij(:,:,1) sys(2).acl sys(2).aij(:,:,3)
   sys(3).aij(:,:,1) sys(3).aij(:,:,2) sys(3).acl];
Bw=blkdiag(sys(1).bw,sys(2).bw,sys(3).bw);
B=blkdiag(sys(1).bu,sys(2).bu,sys(3).bu);
C=blkdiag(sys(1).c,sys(2).c,sys(3).c);
K=blkdiag(sys(1).k,sys(2).k,sys(3).k);
KC=blkdiag(sys(1).k*sys(1).c,sys(2).k*sys(2).c,sys(3).k*sys(3).c);
Cz=blkdiag(sys(1).out,sys(2).out,sys(3).out);
Cp=blkdiag(sys(1).cp,sys(2).cp,sys(3).cp);

w=logspace(-1,1,1000);
s=1j*w;

[n,nu]=size(B);
[~,nd]=size(Bw);
[ny,~]=size(C);
[npy,~]=size(Cp);
[nz,~]=size(Cz);
Tzw=zeros(size(w,2),min(nz,nd));
Tzw2=zeros(size(w,2),min(nz,nd));
Tzw3=zeros(size(w,2),min(nz,nd));

pre=zeros(1,3);
taui=zeros(1,3);
kp=[-143.27E-4,-176.96E-4,-161.6E-4];
ki=[-0.2534,-0.2435,-0.2698];
taui=[kp(1)/ki(1),kp(2)/ki(2),kp(3)/ki(3)];
tau=1023.0;

for i=1:3
    alpha=(1+sys(i).k(1))/(2*tau);
    beta=sqrt(abs(alpha^2-sys(i).k(1)/tau/taui(i)));
    pre(i)=exp(-alpha*pi/beta)/(1+exp(-alpha*pi/beta));
end
warning off
%{
for i=1:size(w,2)
    G11(i).sys = Cz*(s(i)*eye(27)-A)^(-1)*Bw;
    G12(i).sys = Cz*(s(i)*eye(27)-A)^(-1)*B;
    G21(i).sys = C*(s(i)*eye(27)-A)^(-1)*Bw;
    G22(i).sys = C*(s(i)*eye(27)-A)^(-1)*B;
%     Gs(i).sys = kp+ki/s(i);
    Tzw(i,:,:)=svd((G11(i).sys + (G12(i).sys*K)*(eye(ny) - G22(i).sys*K)^(-1)*G21(i).sys));
end
%}
for i=1:size(w,2)
    G11(i).sys = Cz*(s(i)*eye(27)-A)^(-1)*Bw;
    G12(i).sys = Cz*(s(i)*eye(27)-A)^(-1)*B;
    G21(i).sys = Cp*(s(i)*eye(27)-A)^(-1)*Bw;
    G22(i).sys = Cp*(s(i)*eye(27)-A)^(-1)*B;
%     Gs(i).sys = blkdiag(sys(1).k(1)+sys(1).k(2)/s(i),sys(2).k(1)+sys(2).k(2)/s(i),sys(3).k(1)+sys(3).k(2)/s(i));
    
    a=kp(1)*(1j*(w(i)*taui(1)+4/pi*pre(1))+1)/s(i)/taui(1);
    b=kp(2)*(1j*(w(i)*taui(2)+4/pi*pre(2))+1)/s(i)/taui(2);
    c=kp(3)*(1j*(w(i)*taui(3)+4/pi*pre(3))+1)/s(i)/taui(3);
    
    Csrst(i).sys=blkdiag(a,b,c);    
    Tzw(i,:,:)=svd((G11(i).sys + (G12(i).sys*Csrst(i).sys)*(eye(npy) - G22(i).sys*Csrst(i).sys)^(-1)*G21(i).sys));
end
for i=1:size(w,2)
    G11r(i).sys = Cz*(s(i)*eye(27)-A)^(-1)*Bw;
    G12r(i).sys = Cz*(s(i)*eye(27)-A)^(-1)*B;
    G21r(i).sys = Cp*(s(i)*eye(27)-A)^(-1)*Bw;
    G22r(i).sys = Cp*(s(i)*eye(27)-A)^(-1)*B;
    Gs(i).sys = blkdiag(sys(1).k(1)+sys(1).k(2)/s(i),sys(2).k(1)+sys(2).k(2)/s(i),sys(3).k(1)+sys(3).k(2)/s(i));
    Tzw2(i,:,:)=svd((G11r(i).sys + (G12r(i).sys*Gs(i).sys)*(eye(npy) - G22r(i).sys*Gs(i).sys)^(-1)*G21r(i).sys));
end
for i=1:size(w,2)
    G11p(i).sys = Cz*(s(i)*eye(27)-A)^(-1)*Bw;
    G12p(i).sys = Cz*(s(i)*eye(27)-A)^(-1)*B;
    G21p(i).sys = Cp*(s(i)*eye(27)-A)^(-1)*Bw;
    G22p(i).sys = Cp*(s(i)*eye(27)-A)^(-1)*B;
    Gs(i).sys = blkdiag(kp(1)+ki(1)/s(i),kp(2)+ki(2)/s(i),kp(3)+ki(3)/s(i));
    Tzw3(i,:,:)=svd((G11p(i).sys + (G12p(i).sys*Gs(i).sys)*(eye(npy) - G22p(i).sys*Gs(i).sys)^(-1)*G21p(i).sys));
end
% for i=1:size(w,2)
%     G11(i).sys = Czp*(s(i)*eye(4)-Ap)^(-1)*Fp;
%     G12(i).sys = Czp*(s(i)*eye(4)-Ap)^(-1)*Bp;
%     G21(i).sys = Cp2*(s(i)*eye(4)-Ap)^(-1)*Fp;
%     G22(i).sys = Cp2*(s(i)*eye(4)-Ap)^(-1)*Bp;
%     Csrst(i).sys=kp*(1j*(w(i)*taui2+4/pi*pre)+1)/s(i)/taui2;
%     Tzr2(i,:,:)=svd(W(i)*(G12(i).sys + (G12(i).sys*Csrst(i).sys)*(eye(nz) - G22(i).sys*Csrst(i).sys)^(-1)*G22(i).sys));
%     Tzw2(i,:,:)=svd(W(i)*(G11(i).sys + (G12(i).sys*Csrst(i).sys)*(eye(nz) - G22(i).sys*Csrst(i).sys)^(-1)*G21(i).sys));
% end
%{
for i=1:size(w,2)
    G11(i).sys = Czp*(s(i)*eye(4)-Ap)^(-1)*Fp;
    G12(i).sys = Czp*(s(i)*eye(4)-Ap)^(-1)*Bp;
    G21(i).sys = Cp*(s(i)*eye(4)-Ap)^(-1)*Fp;
    G22(i).sys = Cp*(s(i)*eye(4)-Ap)^(-1)*Bp;

    Tzw2(i,:,:)=svd(W(i)*(G11(i).sys + (G12(i).sys*K)*(eye(ny) - G22(i).sys*(K))^(-1)*G21(i).sys));
end
%}
figure(1232)
for i=1:3
    subplot(3,1,i)
    semilogx(w,Tzw(:,i))
    hold on
    semilogx(w,Tzw2(:,i),'--')
    semilogx(w,Tzw3(:,i),'g--')
    hold off
    legend('Reset','galmi','no reset')
%     ylim([0 10])
end
