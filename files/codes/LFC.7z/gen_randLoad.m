clear all
clc

t=(0:3000)';
dP1_=(rand(3001,1)-0.5)*0.00005+0.0001*(rand-.5)*sin(rand*0.1*t+rand)+0.0001*(rand-.5)*sin(rand*0.1*t+rand)+0.0005*(rand-.5)*cos(0.01*rand*t+rand)+0.0005*(rand-.5)*cos(0.01*rand*t+rand)...
    +(rand(3001,1)-0.5)*0.00005+0.0001*(rand-.5)*sin(rand*0.1*t+rand)+0.0001*(rand-.5)*sin(rand*0.1*t+rand)+0.0005*(rand-.5)*cos(0.01*rand*t+rand)+0.0005*(rand-.5)*cos(0.01*rand*t+rand);%+0.005*(randi(2,3001,1)-1.5);
dP2_=(rand(3001,1)-0.5)*0.00005+0.0001*(rand-.5)*sin(rand*0.1*t+rand)+0.0001*(rand-.5)*sin(rand*0.1*t+rand)+0.0005*(rand-.5)*cos(0.01*rand*t+rand)+0.0005*(rand-.5)*cos(0.01*rand*t+rand)...
    +(rand(3001,1)-0.5)*0.00005+0.0001*(rand-.5)*sin(rand*0.1*t+rand)+0.0001*(rand-.5)*sin(rand*0.1*t+rand)+0.0005*(rand-.5)*cos(0.01*rand*t+rand)+0.0005*(rand-.5)*cos(0.01*rand*t+rand);%+0.005*(randi(2,3001,1)-1.5);
dP3_=(rand(3001,1)-0.5)*0.00005+0.0001*(rand-.5)*sin(rand*0.1*t+rand)+0.0001*(rand-.5)*sin(rand*0.1*t+rand)+0.0005*(rand-.5)*cos(0.01*rand*t+rand)+0.0005*(rand-.5)*cos(0.01*rand*t+rand)...
    +(rand(3001,1)-0.5)*0.00005+0.0001*(rand-.5)*sin(rand*0.1*t+rand)+0.0001*(rand-.5)*sin(rand*0.1*t+rand)+0.0005*(rand-.5)*cos(0.01*rand*t+rand)+0.0005*(rand-.5)*cos(0.01*rand*t+rand);%+0.005*(randi(2,3001,1)-1.5);
dP1_=(dP1_-min(dP1_))./(max(dP1_)-min(dP1_))*0.02-0.01;
dP2_=(dP2_-min(dP2_))./(max(dP2_)-min(dP2_))*0.03-0.015;
dP3_=(dP3_-min(dP3_))./(max(dP3_)-min(dP3_))*0.03-0.015;

dP1_=dP1_-dP1_(1);
dP2_=dP2_-dP2_(1);
dP3_=dP3_-dP3_(1);

dP1=[t,dP1_];
dP2=[t,dP2_];
dP3=[t,dP3_];
save('disturbances','dP1','dP2','dP3')
tmax=300;
figure(1011)
subplot(311)
plot(t,dP1_)
xlim([0 tmax])
subplot(312)
plot(t,dP2_)
xlim([0 tmax])
subplot(313)
plot(t,dP3_)
xlim([0 tmax])