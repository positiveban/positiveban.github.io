clc
clear all

%% Model parameters
Tp=0.1667;
R=3;
beta=0.3483;
Tt=0.4;
Tg=0.08;
D=0.015;

Ap=[-D/Tp                1/Tp   0        0
    0                   -1/Tt  1/Tt     0
    -1/R/Tg             0      -1/Tg    0
    beta             0      0        0];
Bp=[0;0;1;0];
Fp=[-1/Tp;0;0;0];

Cp=[beta/Tg,0,0,0
    0,0,0,1/Tg];
Cp2=[beta/Tg,0,0,0];

Czp=[1,0,0,0];
Dzw=zeros(1,1);

tau=1/(2);

Aw1=Czp/tau;
Aw2=-1/tau;

A=[Ap, zeros(4,1);Aw1,Aw2];
B=[Bp;0];
C=[Cp,[0;0]];
Cz=[zeros(1,4),1];
F=[Fp;0];

w=logspace(-3,3,200);
s=1j*w;

[n,nu]=size(B);
[~,nd]=size(F);
[ny,~]=size(C);
[nz,~]=size(Cz);
Tzr=zeros(size(w,2),nz,nu);
Tzw=zeros(size(w,2),nz,nd);
Tzr2=zeros(size(w,2),nz,nu);
Tzw2=zeros(size(w,2),nz,nd);

G11s=zeros(size(w,2),nz,nd);
G12s=zeros(size(w,2),nz,nu);
G21s=zeros(size(w,2),ny,nd);
G22s=zeros(size(w,2),ny,nu);

tau_l=1/(.01);
tau_h=0/(1);

W=zeros(size(w,2),1);
for i=1:size(w,2)
    %W(i)=svd((tau_h*s(i)+1)/(tau_l*s(i)+1));
    % W(i)=svd((tau_h*s(i)+1)/(tau_l*s(i)+1));
    W(i)=1;
end


kp=-3.27E-4;
ki=-0.3334;
taui=kp/ki;
taui2=kp/-0.4334;
tau=2.5;
alpha=(1+kp)/(2*tau);
beta=sqrt(abs(alpha^2-kp/tau/taui));
pre=exp(-alpha*pi/beta)/(1+exp(-alpha*pi/beta));

warning off
for i=1:size(w,2)
    G11(i).sys = Czp*(s(i)*eye(4)-Ap)^(-1)*Fp;
    G12(i).sys = Czp*(s(i)*eye(4)-Ap)^(-1)*Bp;
    G21(i).sys = Cp2*(s(i)*eye(4)-Ap)^(-1)*Fp;
    G22(i).sys = Cp2*(s(i)*eye(4)-Ap)^(-1)*Bp;
    Gs(i).sys = kp+ki/s(i);
    Tzr(i,:,:)=svd(W(i)*(G12(i).sys + (G12(i).sys*Gs(i).sys)*(eye(nz) - G22(i).sys*Gs(i).sys)^(-1)*G22(i).sys));
    Tzw(i,:,:)=svd(W(i)*(G11(i).sys + (G12(i).sys*Gs(i).sys)*(eye(nz) - G22(i).sys*Gs(i).sys)^(-1)*G21(i).sys));
end
for i=1:size(w,2)
    G11(i).sys = Czp*(s(i)*eye(4)-Ap)^(-1)*Fp;
    G12(i).sys = Czp*(s(i)*eye(4)-Ap)^(-1)*Bp;
    G21(i).sys = Cp2*(s(i)*eye(4)-Ap)^(-1)*Fp;
    G22(i).sys = Cp2*(s(i)*eye(4)-Ap)^(-1)*Bp;
    Csrst(i).sys=kp*(1j*(w(i)*taui2+4/pi*pre)+1)/s(i)/taui2;
    Tzr2(i,:,:)=svd(W(i)*(G12(i).sys + (G12(i).sys*Csrst(i).sys)*(eye(nz) - G22(i).sys*Csrst(i).sys)^(-1)*G22(i).sys));
    Tzw2(i,:,:)=svd(W(i)*(G11(i).sys + (G12(i).sys*Csrst(i).sys)*(eye(nz) - G22(i).sys*Csrst(i).sys)^(-1)*G21(i).sys));
end
%{
for i=1:size(w,2)
    G11(i).sys = Czp*(s(i)*eye(4)-Ap)^(-1)*Fp;
    G12(i).sys = Czp*(s(i)*eye(4)-Ap)^(-1)*Bp;
    G21(i).sys = Cp*(s(i)*eye(4)-Ap)^(-1)*Fp;
    G22(i).sys = Cp*(s(i)*eye(4)-Ap)^(-1)*Bp;

    Tzw2(i,:,:)=svd(W(i)*(G11(i).sys + (G12(i).sys*K)*(eye(ny) - G22(i).sys*(K))^(-1)*G21(i).sys));
end
%}
figure(1232)
subplot(211)
semilogx(w,Tzw)
% plot(w,Tzw)
hold on
semilogx(w,Tzw2,'--')
% plot(w,Tzw2,'--')
hold off
ylim([0 6])
subplot(212)
semilogx(w,Tzr)
hold on
semilogx(w,Tzr2,'--')
hold off
ylim([0 .4])