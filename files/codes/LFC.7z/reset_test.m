clear all
clc

data=xlsread('LFC2001_parameters.xlsx');

Rate=data(1,:);
D=data(2,:);
Tp=data(3,:);
Tt=data(4,:);
Th=data(5,:);
R=data(6,:);
B=data(7,:);
alp=data(8,:);

tau1=Th(1);
tau2=Tt(1);
tau3=Tp(1);
D=D(1);

kp=-3.27E-4;
ki=-0.3334;
taui=kp/ki;
taui2=kp/-0.3334;
tau=1.1;

alpha=(1+kp)/(2*tau);
beta=sqrt(abs(alpha^2-kp/tau/taui));
pre=exp(-alpha*pi/beta)/(1+exp(-alpha*pi/beta));

N=200;
w=logspace(-3,3,N);
s=1j*w;
for i=1:N
    Gs(i)=1/(tau1*s(i)+1)/(tau2*s(i)+1)/(tau3*s(i)+D);
%     Cs(i)=kp*(1+1/taui/s(i));
    Cs(i)=kp+ki/s(i);
    sCs(i)=svd(Cs(i));
    Twz(i)=svd(1/(tau3*s(i)+D)/(1+Gs(i)*Cs(i)/3));
    
    Csrst(i)=kp*(1j*(w(i)*taui2+4/pi*pre)+1)/s(i)/taui2;
    sCsrst(i)=svd(Csrst(i));
    Twrst(i)=svd(1/(tau3*s(i)+D)/(1+Gs(i)*Csrst(i)/3));
end

figure(2331)
semilogx(w,Twz,'--');
hold on
semilogx(w,Twrst);
hold off