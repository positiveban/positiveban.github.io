clear all

data=xlsread('LFC2001_parameters.xlsx');

Rate=data(1,:);
D=data(2,:);
Tp=data(3,:);
Tt=data(4,:);
Th=data(5,:);
R=data(6,:);
B=data(7,:);
alp=data(8,:);
bta=[.5 .5 .5
    1 1 1
    500 500 500];
kp=[-133.27E-4,-36.96E-4,-131.6E-4];
ki=[-0.2334,-0.2435,-0.2398];

sys(1).k=[kp(1) ki(1) 0];
sys(2).k=[kp(2) ki(2) 0];
sys(3).k=[kp(3) ki(3) 0];
k_reset=zeros(3,3);
for i=1:3
    k_reset(i,:)=sys(i).k;
end
save('reset_gain','k_reset')

sys(1).k=sys(1).k(1:2);
sys(2).k=sys(2).k(1:2);
sys(3).k=sys(3).k(1:2);

Tij=[0    0.2   0.25
     0.2  0     0.12
     0.25 0.12  0];
 
 sumTij=sum(Tij);
 
for i=1:3
    sys(i).d=sum(D((i-1)*3+1:i*3));
    sys(i).tp=sum(Tp((i-1)*3+1:i*3));
    sys(i).bias=sum(B((i-1)*3+1:i*3));
    sys(i).area = [-sys(i).d/sys(i).tp  -1/sys(i).tp  0
                   2*pi*sumTij(i)          0             0
                   sys(i).bias           1            0];
    sys(i).mp=[];
    for j=1:3
        sys(i).mp=[sys(i).mp,[1/sys(i).tp 0;0 0;0 0]];
    end
    sys(i).droop=[];
    for j=1:3
        sys(i).droop=[sys(i).droop;[0 0 0;-1/R((i-1)*3+j)/Th((i-1)*3+j) 0 0]];
    end
    sys(i).tg=[];
    for j=1:3
        sys(i).tg=blkdiag(sys(i).tg,[-1/Tt((i-1)*3+j) 1/Tt((i-1)*3+j);0 -1/Th((i-1)*3+j)]);
    end
    sys(i).bus=[];
    for j=1:3
        sys(i).bus=[sys(i).bus;alp((i-1)*3+j)*[0;1/Th((i-1)*3+j)]];
    end
    sys(i).bws=[-1/sys(i).tp;0;0];
    for j=1:3
        sys(i).aij(:,:,j)=[0;-2*pi;0;zeros(6,1)]*[Tij(i,j), zeros(1,8)];
    end
       
    sys(i).a=[sys(i).area, sys(i).mp
              sys(i).droop,sys(i).tg];
    sys(i).bu=[zeros(3,1);sys(i).bus];
    sys(i).bw=[sys(i).bws;zeros(6,1)];
    sys(i).cs=[sys(i).bias 1  0
               0           0  1];
    sys(i).c=[sys(i).cs,zeros(2,6)];
    
    sys(i).cinfs=[bta(1,i) 0 0;0 0 bta(2,i);0 0 0];
    sys(i).cinf=[sys(i).cinfs,zeros(3,6)];
    
    sys(i).dinf=[0;0;bta(3,i)];
    
    sys(i).outs=[1 0 0;sys(i).bias 1 0];
    sys(i).out=[sys(i).outs,zeros(2,6)];
    
    sys(i).acl=sys(i).a+sys(i).bu*sys(i).k*sys(i).c;
end
A=[sys(1).acl sys(1).aij(:,:,2) sys(1).aij(:,:,3)
   sys(2).aij(:,:,1) sys(2).acl sys(2).aij(:,:,3)
   sys(3).aij(:,:,1) sys(3).aij(:,:,2) sys(3).acl];
Bw=blkdiag(sys(1).bw,sys(2).bw,sys(3).bw);
KC=blkdiag(sys(1).k*sys(1).c,sys(2).k*sys(2).c,sys(3).k*sys(3).c);
output_mat=blkdiag(sys(1).out,sys(2).out,sys(3).out);

%% Simulation
load('disturbances')
Tf=20;
sim('LFC2001_sim')
f=y(:,[1,3,5]);
ACE=y(:,[2,4,6]);
for i=1:3
    figure(i)
    subplot(411)
    hold on
    plot(tout,ACE(:,i),'--')
    hold off
    ylabel('ACE(pu)')
    subplot(412)
    hold on
    plot(tout,f(:,i),'--')
    hold off
    ylabel('df(Hz)')
    subplot(413)
    hold on
    plot(tout,dPc(:,i),'--')
    hold off
    ylabel('dPc(pu)')
    xlabel('Time (sec)')
end