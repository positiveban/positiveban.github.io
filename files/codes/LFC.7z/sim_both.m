clear all
run LFC_2001
run LFC_2001_diffgain
run LFC_2001_reset
%{
for i=1:3
    figure(i)
    subplot(311)
    ylim([-.14 .02])
    subplot(312)
    ylim([-.1 .02])
    subplot(313)
    ylim([-.01 .11])
end
%}